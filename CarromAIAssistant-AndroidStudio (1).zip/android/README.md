# Carrom AI Assistant (Android 15 Native Project)

## Target Device:
- Model: OnePlus Nord CE 3 Lite 5G
- Chipset: Qualcomm Snapdragon 695 5G
- Architecture: arm64-v8a
- OS: Android 15 (compileSdk 35, targetSdk 35, minSdk 26)

## How to build in Android Studio:
1. Open Android Studio (Ladybug or newer).
2. Click "Open" and select the root 'android' folder.
3. Wait for Gradle Sync to complete.
4. Plug in your OnePlus Nord CE 3 Lite 5G via USB with Developer Mode & USB Debugging enabled.
5. Click 'Run' (Shift + F10).
