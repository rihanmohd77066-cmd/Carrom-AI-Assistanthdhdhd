# Carrom AI Assistant (Native Android Studio Project)

Target Hardware: **OnePlus Nord CE 3 Lite 5G**
Processor: **Qualcomm Snapdragon 695 5G** (2x 2.2 GHz Kryo 660 Gold + 6x 1.7 GHz Kryo 660 Silver, Adreno 619 GPU)
Display: **1080 x 2400 FHD+, 120Hz Refresh Rate**
Operating System: **Android 15 (API 35)** / OxygenOS 15
RAM: **8GB LPDDR4X**

---

## Architecture Overview

```
com.carrom.aiassistant
├── CarromApp.kt                 # Application class initializing OpenCV native libs and notification channels
├── MainActivity.kt              # Modern dark Home Screen (Permissions, Launcher, Settings)
├── model/
│   └── Models.kt                # Data definitions (Coins, Pockets, Trajectories, Settings)
├── cv/
│   ├── BoardDetector.kt         # Square detection, corner pockets, baseline mapping
│   ├── CoinDetector.kt          # Circular Hough Transform & HSV segmentation (Queen/White/Black)
│   └── CarromVisionEngine.kt    # Frame coordinator, Mat pooling, temporal position smoothing
├── physics/
│   ├── Vector2D.kt              # 2D mathematical vector utilities
│   ├── CarromPhysicsEngine.kt   # Elastic collision, cut angles, ghost ball, bank reflections
├── service/
│   ├── ScreenCaptureService.kt  # Android 15 MediaProjection Foreground Service
│   └── FloatingOverlayService.kt# WindowManager TYPE_APPLICATION_OVERLAY with touch pass-through
├── overlay/
│   └── TrajectoryCanvasView.kt  # Hardware-accelerated Canvas for trajectories and ghost striker
└── util/
    ├── PermissionHelper.kt      # Overlay, MediaProjection, and Notification permission gates
    └── SnapdragonProfiler.kt    # Kryo 660 CPU & Adreno 619 real-time latency profiler
```

---

## How to Import & Build in Android Studio

1. Open Android Studio (Ladybug / Koala / Hedgehog or newer).
2. Click **File -> Open...** and select this directory (`android/`).
3. Allow Gradle to sync dependencies automatically.
4. Connect your **OnePlus Nord CE 3 Lite 5G** via USB with **USB Debugging** enabled in Developer Options.
5. In Android Studio, select the `app` configuration and hit **Run (Shift + F10)**.

### Permissions Flow (Android 15):
1. **Appear on Top (Overlay)**: Granted via `Settings.ACTION_MANAGE_OVERLAY_PERMISSION`.
2. **Screen Capture (MediaProjection)**: Granted via the system popup dialog.
3. **Notification**: Required for foreground service persistence.

### Privacy Policy:
- 100% Offline execution. Zero internet permission is requested in `AndroidManifest.xml`.
- Screen bitmaps are processed in volatile RAM buffers and recycled immediately.
