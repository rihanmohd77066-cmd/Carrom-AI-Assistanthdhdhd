package com.carrom.aiassistant.cv

import android.util.Log
import com.carrom.aiassistant.model.CarromCoin
import com.carrom.aiassistant.model.CoinType
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import kotlin.math.hypot

/**
 * Phase 5: Coin Detection Engine.
 *
 * Implements circular Hough transform object detection, multi-range HSV color classification,
 * shadow rejection, overlapping coin resolution, and inter-frame temporal tracking.
 */
class CoinDetector {

    companion object {
        const val TAG = "CoinDetector"
        const val MAX_TRACKING_DISTANCE_PX = 32f
        const val SMOOTHING_FACTOR = 0.68f // 68% current frame, 32% previous frame
    }

    // Pre-allocated Mats to prevent GC pauses on Snapdragon 695
    private val grayMat = Mat()
    private val blurredMat = Mat()
    private val hsvMat = Mat()
    private val rgbMat = Mat()
    private val circlesMat = Mat()

    // Persistent tracked coins across frames for temporal stabilization
    private var trackedCoins: MutableList<CarromCoin> = mutableListOf()
    private var frameCounter = 0L

    /**
     * Detects, classifies, and tracks all coins inside the carrom board ROI.
     */
    fun detectCoins(
        boardRoiMat: Mat,
        offsetX: Float,
        offsetY: Float,
        baselineY: Float = 0f
    ): List<CarromCoin> {
        val detectedRaw = mutableListOf<CarromCoin>()
        if (boardRoiMat.empty()) return trackedCoins

        frameCounter++

        try {
            val roiCols = boardRoiMat.cols()
            val roiRows = boardRoiMat.rows()

            // 1. Grayscale & Gaussian blur for circular Hough Transform
            Imgproc.cvtColor(boardRoiMat, grayMat, Imgproc.COLOR_RGBA2GRAY)
            Imgproc.GaussianBlur(grayMat, blurredMat, Size(7.0, 7.0), 2.0, 2.0)

            // 2. HSV color space conversion for coin classification
            Imgproc.cvtColor(boardRoiMat, rgbMat, Imgproc.COLOR_RGBA2RGB)
            Imgproc.cvtColor(rgbMat, hsvMat, Imgproc.COLOR_RGB2HSV)

            // Dynamic radius expectations based on board dimensions:
            // Standard carrom coin diameter is ~31.8mm on 740mm board (4.3% of width)
            val expectedCoinRadius = (roiCols * 0.0215).toInt().coerceIn(12, 35)
            val minRadius = (expectedCoinRadius * 0.75).toInt().coerceAtLeast(10)
            val maxRadius = (expectedCoinRadius * 1.55).toInt().coerceAtLeast(minRadius + 6)

            // 3. Hough Gradient circle detection
            Imgproc.HoughCircles(
                blurredMat,
                circlesMat,
                Imgproc.HOUGH_GRADIENT,
                1.2,                                    // Inverse ratio of accumulator resolution
                minRadius * 1.35,                      // Min distance between detected centers
                75.0,                                  // Canny upper threshold
                30.0,                                  // Accumulator threshold for center detection
                minRadius,
                maxRadius
            )

            val totalCircles = circlesMat.cols()
            for (i in 0 until totalCircles) {
                val circleData = circlesMat.get(0, i) ?: continue
                val cx = circleData[0].toFloat()
                val cy = circleData[1].toFloat()
                val radius = circleData[2].toFloat()

                // Map relative ROI coordinate back to full screen space
                val screenX = cx + offsetX
                val screenY = cy + offsetY

                // 4. Multi-range HSV & Radius classification
                val type = classifyCoin(
                    hsv = hsvMat,
                    cx = cx.toInt(),
                    cy = cy.toInt(),
                    radius = radius,
                    expectedCoinRadius = expectedCoinRadius.toFloat(),
                    screenY = screenY,
                    baselineY = baselineY
                )

                detectedRaw.add(
                    CarromCoin(
                        id = "temp_${type.name}_$i",
                        type = type,
                        x = screenX,
                        y = screenY,
                        radius = radius
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in coin detection pipeline", e)
        }

        // 5. Resolve overlapping detections (deduplicate false positives)
        val filteredCoins = removeOverlappingCircles(detectedRaw)

        // 6. Temporal tracking & inter-frame smoothing
        trackedCoins = trackAndSmoothCoins(trackedCoins, filteredCoins)

        return trackedCoins
    }

    /**
     * Classifies a detected circle into Queen, White, Black, or Striker.
     */
    private fun classifyCoin(
        hsv: Mat,
        cx: Int,
        cy: Int,
        radius: Float,
        expectedCoinRadius: Float,
        screenY: Float,
        baselineY: Float
    ): CoinType {
        // A. Striker check: Striker has ~30% larger radius than standard coins,
        // or is positioned directly on the player's baseline
        if (radius >= expectedCoinRadius * 1.25f || (baselineY > 0 && abs(screenY - baselineY) < 18f)) {
            return CoinType.STRIKER
        }

        // B. Sample 7x7 color patch around circle centroid (rejecting border edge shadow)
        val patchSize = 7
        val x0 = (cx - patchSize / 2).coerceIn(0, hsv.cols() - patchSize)
        val y0 = (cy - patchSize / 2).coerceIn(0, hsv.rows() - patchSize)

        val sampleBox = hsv.submat(
            Range(y0, (y0 + patchSize).coerceAtMost(hsv.rows())),
            Range(x0, (x0 + patchSize).coerceAtMost(hsv.cols()))
        )

        val meanScalar = Core.mean(sampleBox)
        val h = meanScalar.`val`[0]
        val s = meanScalar.`val`[1]
        val v = meanScalar.`val`[2]

        sampleBox.release()

        // Queen (Red/Pink): High saturation, Hue wraps around 0/180
        if (s > 80 && (h < 15 || h > 165)) {
            return CoinType.QUEEN
        }

        // Black Coin: Low brightness value
        if (v < 75) {
            return CoinType.BLACK
        }

        // White Coin: High brightness value with low-to-moderate saturation
        if (v > 160 && s < 65) {
            return CoinType.WHITE
        }

        // Mid-tone balance fallback
        return if (v < 115) CoinType.BLACK else CoinType.WHITE
    }

    /**
     * Removes duplicate or overlapping circle detections (e.g. concentric edge artifacts).
     */
    private fun removeOverlappingCircles(coins: List<CarromCoin>): List<CarromCoin> {
        val result = mutableListOf<CarromCoin>()

        for (candidate in coins) {
            val overlapping = result.any { existing ->
                val dist = hypot(candidate.x - existing.x, candidate.y - existing.y)
                dist < (candidate.radius + existing.radius) * 0.55f
            }
            if (!overlapping) {
                result.add(candidate)
            }
        }
        return result
    }

    /**
     * Matches coins between consecutive frames to maintain persistent IDs and smooth jitter.
     */
    private fun trackAndSmoothCoins(
        previous: List<CarromCoin>,
        current: List<CarromCoin>
    ): MutableList<CarromCoin> {
        if (previous.isEmpty()) {
            return current.mapIndexed { idx, c ->
                c.copy(id = "coin_${c.type.name}_$idx")
            }.toMutableList()
        }

        val result = mutableListOf<CarromCoin>()
        val matchedPrevIds = mutableSetOf<String>()

        for ((index, curr) in current.withIndex()) {
            // Find closest coin of same type from previous frame
            val bestMatch = previous
                .filter { it.type == curr.type && it.id !in matchedPrevIds }
                .minByOrNull { hypot(it.x - curr.x, it.y - curr.y) }

            if (bestMatch != null && hypot(bestMatch.x - curr.x, bestMatch.y - curr.y) <= MAX_TRACKING_DISTANCE_PX) {
                matchedPrevIds.add(bestMatch.id)
                // Apply Exponential Moving Average (EMA) smoothing
                val smoothedX = bestMatch.x * (1f - SMOOTHING_FACTOR) + curr.x * SMOOTHING_FACTOR
                val smoothedY = bestMatch.y * (1f - SMOOTHING_FACTOR) + curr.y * SMOOTHING_FACTOR
                result.add(
                    curr.copy(
                        id = bestMatch.id,
                        x = smoothedX,
                        y = smoothedY
                    )
                )
            } else {
                result.add(curr.copy(id = "coin_${curr.type.name}_${frameCounter}_$index"))
            }
        }

        return result
    }

    fun release() {
        grayMat.release()
        blurredMat.release()
        hsvMat.release()
        rgbMat.release()
        circlesMat.release()
        trackedCoins.clear()
    }
}
