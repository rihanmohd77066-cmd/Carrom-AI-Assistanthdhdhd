package com.carrom.aiassistant.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Point
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.util.Log
import android.view.*
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.NotificationCompat
import com.carrom.aiassistant.CarromApp
import com.carrom.aiassistant.MainActivity
import com.carrom.aiassistant.R
import com.carrom.aiassistant.model.TrajectoryResult
import com.carrom.aiassistant.overlay.TrajectoryCanvasView
import com.carrom.aiassistant.util.PermissionHelper
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import kotlin.math.abs

class FloatingOverlayService : Service() {

    companion object {
        const val TAG = "FloatingOverlayService"
        const val ACTION_START = "ACTION_START_OVERLAY"
        const val ACTION_STOP = "ACTION_STOP_OVERLAY"
        const val NOTIFICATION_ID = 2002

        // Single instance guard to prevent duplicate overlay instances (Requirement 11)
        var isServiceRunning = false
            private set

        // State callbacks for UI sync
        var isAnalysisActive = true
            private set
    }

    private lateinit var windowManager: WindowManager
    private val mainHandler = Handler(Looper.getMainLooper())

    // 1. Fullscreen transparent overlay for trajectory canvas
    // Configured with FLAG_NOT_TOUCHABLE so all touches pass through to the game!
    private var trajectoryCanvasView: TrajectoryCanvasView? = null
    private var canvasLayoutParams: WindowManager.LayoutParams? = null

    // 2. Interactive Floating Widget (Bubble + Expandable Control Panel)
    private var overlayContainerView: View? = null
    private var widgetLayoutParams: WindowManager.LayoutParams? = null

    // View references inside overlay_floating_control_panel
    private var llFloatingBubble: View? = null
    private var cardControlPanel: MaterialCardView? = null
    private var tvBubbleStatus: TextView? = null
    private var tvBubbleConfidence: TextView? = null
    private var tvPanelStatus: TextView? = null
    private var tvTrajectoryIndicator: TextView? = null
    private var viewStatusDot: View? = null

    // Phase 8 & 9: Detection and shot recommendation views
    private var tvBoardStatus: TextView? = null
    private var tvCoinStatus: TextView? = null
    private var tvSelectedShotInfo: TextView? = null
    private var btnPrevShot: ImageButton? = null
    private var btnNextShot: ImageButton? = null
    private var currentShotIndex = 0
    private var availableShotsList = mutableListOf<com.carrom.aiassistant.model.ShotCandidate>()

    private var btnStartCapture: MaterialButton? = null
    private var btnStopCapture: MaterialButton? = null
    private var btnStartAnalysis: MaterialButton? = null
    private var btnStopAnalysis: MaterialButton? = null
    private var btnShowTrajectory: MaterialButton? = null
    private var btnHideTrajectory: MaterialButton? = null
    private var btnActionMinimize: MaterialButton? = null
    private var btnCloseAssistant: MaterialButton? = null

    // Screen geometry for snapping
    private val screenSize = Point()
    private var isExpanded = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()

        // 1. Graceful Permission Denial Handling (Requirements 3 & 12)
        if (!PermissionHelper.hasOverlayPermission(this)) {
            Log.e(TAG, "SYSTEM_ALERT_WINDOW permission denied. Cannot start overlay service.")
            Toast.makeText(this, "Overlay permission not granted. Please enable in Settings.", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }

        // Prevent duplicate instances (Requirement 11)
        if (isServiceRunning) {
            Log.w(TAG, "FloatingOverlayService already running. Skipping duplicate init.")
            return
        }

        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        updateScreenDimensions()

        // 2. Android 15 Foreground Service Lifecycle & Notification (Requirements 8, 9 & 10)
        startForegroundNotification()

        // 3. Initialize WindowManager Overlays (Requirement 2)
        initTrajectoryOverlay()
        initInteractiveFloatingWidget()

        // 4. Connect Event Listener from ScreenCaptureService
        listenToCaptureEvents()

        isServiceRunning = true
        Log.i(TAG, "FloatingOverlayService successfully created and attached to WindowManager.")
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> {
                Log.i(TAG, "Received ACTION_STOP via notification action. Stopping assistant.")
                stopAssistant()
                return START_NOT_STICKY
            }
        }
        return START_STICKY
    }

    private fun updateScreenDimensions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowMetrics = windowManager.currentWindowMetrics
            val insets = windowMetrics.windowInsets.getInsetsIgnoringVisibility(
                WindowInsets.Type.systemBars()
            )
            screenSize.x = windowMetrics.bounds.width()
            screenSize.y = windowMetrics.bounds.height()
        } else {
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getSize(screenSize)
        }
    }

    /**
     * Requirement 9 & 10: Android 15 compliant notification with action button to stop overlay
     */
    private fun startForegroundNotification() {
        val stopIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val openAppIntent = Intent(this, MainActivity::class.java)
        val openAppPendingIntent = PendingIntent.getActivity(
            this, 0, openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CarromApp.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Carrom AI Floating Assistant")
            .setContentText("Overlay active • Tap to open controls")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(openAppPendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Stop Assistant",
                stopPendingIntent
            )
            .build()

        startForeground(NOTIFICATION_ID, notification)
    }

    /**
     * Requirement 7: The trajectory canvas is fullscreen but has FLAG_NOT_TOUCHABLE
     * so that player finger taps pass directly through to Carrom Pool without blockage!
     */
    private fun initTrajectoryOverlay() {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        canvasLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.MATCH_PARENT,
            WindowManager.LayoutParams.MATCH_PARENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or
                    WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        )

        trajectoryCanvasView = TrajectoryCanvasView(this)
        windowManager.addView(trajectoryCanvasView, canvasLayoutParams)
    }

    /**
     * Requirements 4, 5, 6, 7:
     * Draggable movable floating AI button that expands to compact dark control panel on click.
     */
    private fun initInteractiveFloatingWidget() {
        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        widgetLayoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 30
            y = 280
        }

        val inflater = LayoutInflater.from(this)
        overlayContainerView = inflater.inflate(R.layout.overlay_floating_control_panel, null)

        bindViews()
        setupDragAndClickListeners()
        setupControlPanelActions()

        windowManager.addView(overlayContainerView, widgetLayoutParams)
    }

    private fun bindViews() {
        overlayContainerView?.let { root ->
            llFloatingBubble = root.findViewById(R.id.llFloatingBubble)
            cardControlPanel = root.findViewById(R.id.cardControlPanel)
            tvBubbleStatus = root.findViewById(R.id.tvBubbleStatus)
            tvBubbleConfidence = root.findViewById(R.id.tvBubbleConfidence)
            tvPanelStatus = root.findViewById(R.id.tvPanelStatus)
            tvTrajectoryIndicator = root.findViewById(R.id.tvTrajectoryIndicator)
            viewStatusDot = root.findViewById(R.id.viewStatusDot)

            btnStartCapture = root.findViewById(R.id.btnStartCapture)
            btnStopCapture = root.findViewById(R.id.btnStopCapture)
            btnStartAnalysis = root.findViewById(R.id.btnStartAnalysis)
            btnStopAnalysis = root.findViewById(R.id.btnStopAnalysis)
            btnShowTrajectory = root.findViewById(R.id.btnShowTrajectory)
            btnHideTrajectory = root.findViewById(R.id.btnHideTrajectory)
            btnActionMinimize = root.findViewById(R.id.btnActionMinimize)
            btnCloseAssistant = root.findViewById(R.id.btnCloseAssistant)

            // Phase 8 & 9 Views
            tvBoardStatus = root.findViewById(R.id.tvBoardStatus)
            tvCoinStatus = root.findViewById(R.id.tvCoinStatus)
            tvSelectedShotInfo = root.findViewById(R.id.tvSelectedShotInfo)
            btnPrevShot = root.findViewById(R.id.btnPrevShot)
            btnNextShot = root.findViewById(R.id.btnNextShot)

            root.findViewById<ImageButton>(R.id.btnMinimizePanel)?.setOnClickListener {
                minimizeControlPanel()
            }
        }
    }

    /**
     * Requirement 4 & 6: Draggable floating widget with tap-to-expand detection and edge snapping
     */
    private fun setupDragAndClickListeners() {
        val bubbleIcon = overlayContainerView?.findViewById<ImageView>(R.id.ivBubbleIcon)
        val panelHeader = overlayContainerView?.findViewById<View>(R.id.llPanelHeader)

        val dragTouchListener = object : View.OnTouchListener {
            private var initialX = 0
            private var initialY = 0
            private var initialTouchX = 0f
            private var initialTouchY = 0f
            private var hasMoved = false

            override fun onTouch(v: View, event: MotionEvent): Boolean {
                when (event.action) {
                    MotionEvent.ACTION_DOWN -> {
                        initialX = widgetLayoutParams?.x ?: 0
                        initialY = widgetLayoutParams?.y ?: 0
                        initialTouchX = event.rawX
                        initialTouchY = event.rawY
                        hasMoved = false
                        return true
                    }
                    MotionEvent.ACTION_MOVE -> {
                        val dx = (event.rawX - initialTouchX).toInt()
                        val dy = (event.rawY - initialTouchY).toInt()

                        if (abs(dx) > 12 || abs(dy) > 12) {
                            hasMoved = true
                        }

                        if (hasMoved) {
                            widgetLayoutParams?.x = initialX + dx
                            widgetLayoutParams?.y = (initialY + dy).coerceIn(80, screenSize.y - 180)
                            windowManager.updateViewLayout(overlayContainerView, widgetLayoutParams)
                        }
                        return true
                    }
                    MotionEvent.ACTION_UP -> {
                        if (!hasMoved) {
                            // Tap detected! Toggle expand/collapse (Requirement 5)
                            toggleControlPanel()
                        } else {
                            // Snap to closest edge to keep playing field clear (Requirement 13)
                            snapToNearestEdge()
                        }
                        return true
                    }
                }
                return false
            }
        }

        bubbleIcon?.setOnTouchListener(dragTouchListener)
        panelHeader?.setOnTouchListener(dragTouchListener)
    }

    private fun snapToNearestEdge() {
        val currentX = widgetLayoutParams?.x ?: 0
        val midScreen = screenSize.x / 2
        val targetX = if (currentX < midScreen) 20 else (screenSize.x - (overlayContainerView?.width ?: 180) - 20)

        widgetLayoutParams?.x = targetX
        try {
            windowManager.updateViewLayout(overlayContainerView, widgetLayoutParams)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating snapped position", e)
        }
    }

    /**
     * Requirements 5 & 9: Control Panel Actions Implementation with Start/Stop Capture
     */
    private fun setupControlPanelActions() {
        // Requirement 9: Start Capture Control
        btnStartCapture?.setOnClickListener {
            val resumeIntent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_RESUME
            }
            startService(resumeIntent)
            tvPanelStatus?.text = "Capture: Streaming (${ScreenCaptureService.adaptiveTargetFps} FPS)"
            viewStatusDot?.setBackgroundColor(Color.parseColor("#10B981"))
            tvBubbleConfidence?.text = "CAPTURE ON"
            Toast.makeText(this, "Screen Capture resumed", Toast.LENGTH_SHORT).show()
        }

        // Requirement 9: Stop Capture Control
        btnStopCapture?.setOnClickListener {
            val pauseIntent = Intent(this, ScreenCaptureService::class.java).apply {
                action = ScreenCaptureService.ACTION_PAUSE
            }
            startService(pauseIntent)
            tvPanelStatus?.text = "Capture: PAUSED"
            viewStatusDot?.setBackgroundColor(Color.parseColor("#EF4444"))
            tvBubbleConfidence?.text = "CAPTURE OFF"
            Toast.makeText(this, "Screen Capture paused", Toast.LENGTH_SHORT).show()
        }

        // 1. Start Analysis
        btnStartAnalysis?.setOnClickListener {
            isAnalysisActive = true
            tvPanelStatus?.text = "Analysis: Active (Snapdragon 695)"
            viewStatusDot?.setBackgroundColor(Color.parseColor("#10B981"))
            tvBubbleConfidence?.text = "ACTIVE • 25 FPS"
            Toast.makeText(this, "Screen Vision Analysis resumed", Toast.LENGTH_SHORT).show()
        }

        // 2. Stop Analysis
        btnStopAnalysis?.setOnClickListener {
            isAnalysisActive = false
            tvPanelStatus?.text = "Analysis: PAUSED (Conserving Battery)"
            viewStatusDot?.setBackgroundColor(Color.parseColor("#EF4444"))
            tvBubbleConfidence?.text = "PAUSED"
            Toast.makeText(this, "Screen Vision Analysis paused", Toast.LENGTH_SHORT).show()
        }

        // 3. Show Trajectory
        btnShowTrajectory?.setOnClickListener {
            trajectoryCanvasView?.isTrajectoryVisible = true
            trajectoryCanvasView?.invalidate()
            tvTrajectoryIndicator?.text = "LINES ON"
            tvTrajectoryIndicator?.setTextColor(Color.parseColor("#06B6D4"))
        }

        // 4. Hide Trajectory
        btnHideTrajectory?.setOnClickListener {
            trajectoryCanvasView?.isTrajectoryVisible = false
            trajectoryCanvasView?.invalidate()
            tvTrajectoryIndicator?.text = "LINES OFF"
            tvTrajectoryIndicator?.setTextColor(Color.parseColor("#94A3B8"))
        }

        // 5. Minimize Panel
        btnActionMinimize?.setOnClickListener {
            minimizeControlPanel()
        }

        // 6. Close Assistant
        btnCloseAssistant?.setOnClickListener {
            stopAssistant()
        }

        // Phase 8: AI Shot Cycler Controls
        btnPrevShot?.setOnClickListener {
            if (availableShotsList.isNotEmpty()) {
                currentShotIndex = (currentShotIndex - 1 + availableShotsList.size) % availableShotsList.size
                trajectoryCanvasView?.selectedShotIndex = currentShotIndex
                trajectoryCanvasView?.invalidate()
                updateSelectedShotDisplay()
            }
        }

        btnNextShot?.setOnClickListener {
            if (availableShotsList.isNotEmpty()) {
                currentShotIndex = (currentShotIndex + 1) % availableShotsList.size
                trajectoryCanvasView?.selectedShotIndex = currentShotIndex
                trajectoryCanvasView?.invalidate()
                updateSelectedShotDisplay()
            }
        }
    }

    private fun toggleControlPanel() {
        if (isExpanded) {
            minimizeControlPanel()
        } else {
            expandControlPanel()
        }
    }

    private fun expandControlPanel() {
        isExpanded = true
        llFloatingBubble?.visibility = View.GONE
        cardControlPanel?.visibility = View.VISIBLE
    }

    private fun minimizeControlPanel() {
        isExpanded = false
        cardControlPanel?.visibility = View.GONE
        llFloatingBubble?.visibility = View.VISIBLE
        snapToNearestEdge()
    }

    private fun listenToCaptureEvents() {
        ScreenCaptureService.onTrajectoryCalculated = { result ->
            if (isAnalysisActive) {
                updateOverlayHud(result)
            }
        }
    }

    private fun updateOverlayHud(result: TrajectoryResult) {
        trajectoryCanvasView?.updateTrajectory(result)

        // Update available shots cache for cycling
        availableShotsList.clear()
        result.topShot?.let { availableShotsList.add(it) }
        availableShotsList.addAll(result.alternativeShots)

        // Update Board Status
        val bounds = result.boardBounds
        if (bounds != null) {
            tvBoardStatus?.text = "Board: Locked (${bounds.rect.width().toInt()}px)"
            tvBoardStatus?.setTextColor(Color.parseColor("#38BDF8"))
        } else {
            tvBoardStatus?.text = "Board: Searching"
            tvBoardStatus?.setTextColor(Color.parseColor("#F59E0B"))
        }

        // Update Coin Detection Status
        val coins = result.detectedCoins
        val qCount = coins.count { it.type == com.carrom.aiassistant.model.CoinType.QUEEN }
        val wCount = coins.count { it.type == com.carrom.aiassistant.model.CoinType.WHITE }
        val bCount = coins.count { it.type == com.carrom.aiassistant.model.CoinType.BLACK }
        tvCoinStatus?.text = "Coins: ${coins.size} ($qCount Q, $wCount W, $bCount B)"

        // Update Shot Recommendation Info
        updateSelectedShotDisplay()

        val top = result.topShot
        if (top != null) {
            tvBubbleStatus?.text = "${top.targetCoin.type.name} → ${top.targetPocket.id}"
            tvBubbleConfidence?.text = "${top.confidence}% CONF • ${top.estimatedPower}% PWR"
        } else {
            tvBubbleStatus?.text = "CALCULATING..."
            tvBubbleConfidence?.text = "SCANNING BOARD"
        }
    }

    private fun updateSelectedShotDisplay() {
        if (availableShotsList.isEmpty()) {
            tvSelectedShotInfo?.text = "No direct shots found"
            return
        }
        val safeIndex = currentShotIndex.coerceIn(0, availableShotsList.size - 1)
        val shot = availableShotsList[safeIndex]
        val bankTag = if (shot.isBankShot) "[BANK] " else ""
        val prefix = if (safeIndex == 0) "Top: " else "Alt ${safeIndex}: "
        tvSelectedShotInfo?.text = "$prefix$bankTag${shot.targetCoin.type.name} → ${shot.targetPocket.id} (${shot.confidence}%)"
    }

    private fun stopAssistant() {
        // Also stop ScreenCaptureService if running
        val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        startService(captureIntent)

        stopSelf()
    }

    /**
     * Requirement 8 & 13: Proper lifecycle cleanup and unbinding
     */
    override fun onDestroy() {
        Log.i(TAG, "FloatingOverlayService onDestroy triggered. Cleaning up WindowManager views.")
        isServiceRunning = false
        ScreenCaptureService.onTrajectoryCalculated = null

        try {
            trajectoryCanvasView?.let { windowManager.removeView(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Error removing trajectoryCanvasView", e)
        } finally {
            trajectoryCanvasView = null
        }

        try {
            overlayContainerView?.let { windowManager.removeView(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Error removing overlayContainerView", e)
        } finally {
            overlayContainerView = null
        }

        mainHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
