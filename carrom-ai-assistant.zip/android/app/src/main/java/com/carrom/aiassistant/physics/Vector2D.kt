package com.carrom.aiassistant.physics

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

data class Vector2D(val x: Float, val y: Float) {

    fun plus(v: Vector2D) = Vector2D(x + v.x, y + v.y)
    fun minus(v: Vector2D) = Vector2D(x - v.x, y - v.y)
    fun times(scalar: Float) = Vector2D(x * scalar, y * scalar)
    fun div(scalar: Float) = if (scalar == 0f) Vector2D(0f, 0f) else Vector2D(x / scalar, y / scalar)

    fun mag(): Float = hypot(x, y)
    fun magSq(): Float = x * x + y * y

    fun normalize(): Vector2D {
        val m = mag()
        return if (m == 0f) Vector2D(0f, 0f) else div(m)
    }

    fun dot(v: Vector2D): Float = x * v.x + y * v.y

    fun dist(v: Vector2D): Float = hypot(x - v.x, y - v.y)

    fun heading(): Float = atan2(y, x)

    companion object {
        fun fromAngle(angleRad: Float, length: Float = 1f): Vector2D {
            return Vector2D(cos(angleRad) * length, sin(angleRad) * length)
        }
    }
}
