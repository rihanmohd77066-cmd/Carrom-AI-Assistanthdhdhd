package com.carrom.aiassistant.util

import android.content.Context
import android.content.SharedPreferences

class PreferencesManager(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

    companion object {
        private const val PREFS_NAME = "carrom_ai_assistant_prefs"

        const val KEY_ENABLE_BANK_SHOTS = "enable_bank_shots"
        const val KEY_BANK_BOUNCE_COUNT = "bank_bounce_count"
        const val KEY_PRIORITIZE_QUEEN = "prioritize_queen"
        const val KEY_MIN_CONFIDENCE = "min_confidence"
        const val KEY_TARGET_FPS = "target_fps"
        const val KEY_GUIDE_THICKNESS = "guide_thickness"
        const val KEY_ENABLE_GLOW = "enable_glow"
        const val KEY_SHOW_GHOST_STRIKER = "show_ghost_striker"
        const val KEY_TARGET_COIN_FILTER = "target_coin_filter"

        // Default Values
        const val DEFAULT_ENABLE_BANK_SHOTS = true
        const val DEFAULT_BANK_BOUNCE_COUNT = 1
        const val DEFAULT_PRIORITIZE_QUEEN = true
        const val DEFAULT_MIN_CONFIDENCE = 35
        const val DEFAULT_TARGET_FPS = 45 // 45 FPS balanced for Snapdragon 695
        const val DEFAULT_GUIDE_THICKNESS = 4.0f
        const val DEFAULT_ENABLE_GLOW = true
        const val DEFAULT_SHOW_GHOST_STRIKER = true
        const val DEFAULT_TARGET_COIN_FILTER = "ALL"
    }

    var enableBankShots: Boolean
        get() = prefs.getBoolean(KEY_ENABLE_BANK_SHOTS, DEFAULT_ENABLE_BANK_SHOTS)
        set(value) = prefs.edit().putBoolean(KEY_ENABLE_BANK_SHOTS, value).apply()

    var bankBounceCount: Int
        get() = prefs.getInt(KEY_BANK_BOUNCE_COUNT, DEFAULT_BANK_BOUNCE_COUNT)
        set(value) = prefs.edit().putInt(KEY_BANK_BOUNCE_COUNT, value).apply()

    var prioritizeQueen: Boolean
        get() = prefs.getBoolean(KEY_PRIORITIZE_QUEEN, DEFAULT_PRIORITIZE_QUEEN)
        set(value) = prefs.edit().putBoolean(KEY_PRIORITIZE_QUEEN, value).apply()

    var minConfidence: Int
        get() = prefs.getInt(KEY_MIN_CONFIDENCE, DEFAULT_MIN_CONFIDENCE)
        set(value) = prefs.edit().putInt(KEY_MIN_CONFIDENCE, value).apply()

    var targetFps: Int
        get() = prefs.getInt(KEY_TARGET_FPS, DEFAULT_TARGET_FPS)
        set(value) = prefs.edit().putInt(KEY_TARGET_FPS, value).apply()

    var guideThickness: Float
        get() = prefs.getFloat(KEY_GUIDE_THICKNESS, DEFAULT_GUIDE_THICKNESS)
        set(value) = prefs.edit().putFloat(KEY_GUIDE_THICKNESS, value).apply()

    var enableGlow: Boolean
        get() = prefs.getBoolean(KEY_ENABLE_GLOW, DEFAULT_ENABLE_GLOW)
        set(value) = prefs.edit().putBoolean(KEY_ENABLE_GLOW, value).apply()

    var showGhostStriker: Boolean
        get() = prefs.getBoolean(KEY_SHOW_GHOST_STRIKER, DEFAULT_SHOW_GHOST_STRIKER)
        set(value) = prefs.edit().putBoolean(KEY_SHOW_GHOST_STRIKER, value).apply()

    var targetCoinFilter: String
        get() = prefs.getString(KEY_TARGET_COIN_FILTER, DEFAULT_TARGET_COIN_FILTER) ?: DEFAULT_TARGET_COIN_FILTER
        set(value) = prefs.edit().putString(KEY_TARGET_COIN_FILTER, value).apply()

    fun resetToDefaults() {
        prefs.edit()
            .putBoolean(KEY_ENABLE_BANK_SHOTS, DEFAULT_ENABLE_BANK_SHOTS)
            .putInt(KEY_BANK_BOUNCE_COUNT, DEFAULT_BANK_BOUNCE_COUNT)
            .putBoolean(KEY_PRIORITIZE_QUEEN, DEFAULT_PRIORITIZE_QUEEN)
            .putInt(KEY_MIN_CONFIDENCE, DEFAULT_MIN_CONFIDENCE)
            .putInt(KEY_TARGET_FPS, DEFAULT_TARGET_FPS)
            .putFloat(KEY_GUIDE_THICKNESS, DEFAULT_GUIDE_THICKNESS)
            .putBoolean(KEY_ENABLE_GLOW, DEFAULT_ENABLE_GLOW)
            .putBoolean(KEY_SHOW_GHOST_STRIKER, DEFAULT_SHOW_GHOST_STRIKER)
            .putString(KEY_TARGET_COIN_FILTER, DEFAULT_TARGET_COIN_FILTER)
            .apply()
    }
}
