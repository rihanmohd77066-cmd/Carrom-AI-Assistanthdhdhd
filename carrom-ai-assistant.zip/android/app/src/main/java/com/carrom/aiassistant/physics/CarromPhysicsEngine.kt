package com.carrom.aiassistant.physics

import com.carrom.aiassistant.model.*
import kotlin.math.*

/**
 * Phase 6 & Phase 8: Physics Engine & AI Shot Recommendation.
 *
 * Implements 2D elastic/inelastic collision calculations, ghost striker positioning,
 * single-cushion bank rebound simulations, obstruction raycasting, rolling friction dissipation,
 * and AI shot ranking with Queen prioritization.
 */
class CarromPhysicsEngine {

    companion object {
        const val STRIKER_RADIUS_PX_DEFAULT = 24f
        const val COIN_RADIUS_PX_DEFAULT = 17f
        const val MAX_CUT_ANGLE_DEG = 76.0f
        const val RESTITUTION_COIN = 0.92f        // Elasticity coefficient of carrom coin collision
        const val RESTITUTION_CUSHION = 0.85f     // Elasticity coefficient of wooden cushion rebound
        const val ROLLING_FRICTION_COEFF = 0.08f  // Kinetic friction on polished wood ply
        const val GRAVITY_ACCEL = 9800f           // mm/s^2 for physical speed estimation
    }

    /**
     * Finds the exact position where the striker center must be at impact to propel the coin
     * directly into the specified pocket center along the line of centers.
     */
    fun calculateGhostStrikerPosition(
        coinX: Float,
        coinY: Float,
        pocketX: Float,
        pocketY: Float,
        strikerRadius: Float = STRIKER_RADIUS_PX_DEFAULT,
        coinRadius: Float = COIN_RADIUS_PX_DEFAULT
    ): Pair<Float, Float> {
        val dx = pocketX - coinX
        val dy = pocketY - coinY
        val dist = hypot(dx, dy)
        if (dist == 0f) return Pair(coinX, coinY)

        val dirX = dx / dist
        val dirY = dy / dist

        val impactDistance = strikerRadius + coinRadius
        val ghostX = coinX - dirX * impactDistance
        val ghostY = coinY - dirY * impactDistance

        return Pair(ghostX, ghostY)
    }

    /**
     * Calculates the cut angle in degrees [0..90].
     * 0 deg is a head-on central impact; angles beyond 75 deg become unplayable thin cuts.
     */
    fun calculateCutAngle(
        strikerX: Float,
        strikerY: Float,
        ghostX: Float,
        ghostY: Float,
        coinX: Float,
        coinY: Float,
        pocketX: Float,
        pocketY: Float
    ): Float {
        val sDx = ghostX - strikerX
        val sDy = ghostY - strikerY
        val sMag = hypot(sDx, sDy)
        if (sMag == 0f) return 0f

        val cDx = pocketX - coinX
        val cDy = pocketY - coinY
        val cMag = hypot(cDx, cDy)
        if (cMag == 0f) return 0f

        val dot = (sDx * cDx + sDy * cDy) / (sMag * cMag)
        val clampedDot = dot.coerceIn(-1f, 1f)
        val angleRad = acos(clampedDot)
        return (angleRad * 180f / Math.PI.toFloat())
    }

    /**
     * Computes the geometric aiming angle in degrees relative to the positive horizontal axis.
     */
    fun calculateAimAngleDeg(fromX: Float, fromY: Float, toX: Float, toY: Float): Float {
        val dx = toX - fromX
        val dy = toY - fromY
        var angle = atan2(-dy, dx) * 180f / Math.PI.toFloat()
        if (angle < 0f) angle += 360f
        return round(angle * 10f) / 10f
    }

    /**
     * Verifies if any other coin obstructs the line of travel between (x1, y1) and (x2, y2).
     */
    fun isSegmentObstructed(
        x1: Float,
        y1: Float,
        x2: Float,
        y2: Float,
        obstacles: List<CarromCoin>,
        clearanceRadius: Float,
        ignoreCoinId: String? = null
    ): Boolean {
        val dx = x2 - x1
        val dy = y2 - y1
        val lineLen = hypot(dx, dy)
        if (lineLen == 0f) return false

        val ux = dx / lineLen
        val uy = dy / lineLen

        for (obs in obstacles) {
            if (ignoreCoinId != null && obs.id == ignoreCoinId) continue

            val toObsX = obs.x - x1
            val toObsY = obs.y - y1
            val proj = toObsX * ux + toObsY * uy

            // Check if closest point on segment lies between segment endpoints
            if (proj < 0f || proj > lineLen) continue

            val projX = x1 + ux * proj
            val projY = y1 + uy * proj
            val distToLine = hypot(obs.x - projX, obs.y - projY)

            if (distToLine < clearanceRadius + obs.radius) {
                return true
            }
        }
        return false
    }

    /**
     * Evaluates and ranks all direct and cushion bank shots for all target coins.
     */
    fun solveShots(
        strikerPos: Pair<Float, Float>,
        coins: List<CarromCoin>,
        bounds: BoardBounds,
        settings: AssistantSettings
    ): List<ShotCandidate> {
        val candidates = mutableListOf<ShotCandidate>()
        val (sx, sy) = strikerPos
        val maxDist = hypot(bounds.rect.width(), bounds.rect.height())

        for (coin in coins) {
            if (coin.type == CoinType.STRIKER) continue

            // Filter coins if user selected WHITE or BLACK in settings
            if (settings.targetCoinFilter != "ALL") {
                if (settings.targetCoinFilter == "WHITE" && coin.type != CoinType.WHITE && coin.type != CoinType.QUEEN) continue
                if (settings.targetCoinFilter == "BLACK" && coin.type != CoinType.BLACK && coin.type != CoinType.QUEEN) continue
            }

            for (pocket in bounds.pockets) {
                // 1. Calculate Ghost Striker Position for direct shot
                val (gx, gy) = calculateGhostStrikerPosition(
                    coin.x, coin.y,
                    pocket.x, pocket.y,
                    STRIKER_RADIUS_PX_DEFAULT, coin.radius
                )

                // Must be within active board playing bounds
                if (bounds.rect.contains(gx, gy)) {
                    val cutAngle = calculateCutAngle(
                        sx, sy, gx, gy, coin.x, coin.y, pocket.x, pocket.y
                    )

                    if (cutAngle <= MAX_CUT_ANGLE_DEG) {
                        val strikerBlocked = isSegmentObstructed(
                            sx, sy, gx, gy, coins, STRIKER_RADIUS_PX_DEFAULT, coin.id
                        )
                        val coinBlocked = isSegmentObstructed(
                            coin.x, coin.y, pocket.x, pocket.y, coins, coin.radius, coin.id
                        )

                        // Confidence calculation
                        val angleScore = ((MAX_CUT_ANGLE_DEG - cutAngle) / MAX_CUT_ANGLE_DEG) * 58f
                        val distStriker = hypot(gx - sx, gy - sy)
                        val distCoin = hypot(pocket.x - coin.x, pocket.y - coin.y)
                        val totalDist = distStriker + distCoin
                        val distScore = ((maxDist - totalDist) / maxDist).coerceAtLeast(0f) * 26f

                        var penalty = 0f
                        if (strikerBlocked) penalty += 50f
                        if (coinBlocked) penalty += 45f

                        val queenBonus = if (settings.prioritizeQueen && coin.type == CoinType.QUEEN) 20f else 0f
                        val rawConfidence = (angleScore + distScore + queenBonus - penalty).roundToInt()
                        val confidence = rawConfidence.coerceIn(5, 100)

                        if (confidence >= settings.minConfidenceThreshold) {
                            val aimAngle = calculateAimAngleDeg(sx, sy, gx, gy)
                            val powerFactor = (totalDist / maxDist) * 55f + (cutAngle / MAX_CUT_ANGLE_DEG) * 25f
                            val power = powerFactor.roundToInt().coerceIn(30, 100)

                            candidates.add(
                                ShotCandidate(
                                    targetCoin = coin,
                                    targetPocket = pocket,
                                    ghostStrikerX = gx,
                                    ghostStrikerY = gy,
                                    cutAngleDeg = round(cutAngle * 10f) / 10f,
                                    confidence = confidence,
                                    estimatedPower = power,
                                    aimAngleDeg = aimAngle,
                                    isBankShot = false
                                )
                            )
                        }
                    }
                }

                // 2. Cushion Bank Shot Calculation (Phase 6 Rebound Simulation)
                if (settings.enableBankShots) {
                    val bankShots = calculateBankShots(
                        sx, sy, coin, pocket, gx, gy, bounds, coins, maxDist, settings
                    )
                    candidates.addAll(bankShots)
                }
            }
        }

        // Rank shots by confidence descending
        candidates.sortByDescending { it.confidence }
        return candidates
    }

    /**
     * Simulates cushion rebounds off Top, Left, and Right cushions.
     */
    private fun calculateBankShots(
        sx: Float,
        sy: Float,
        coin: CarromCoin,
        pocket: Pocket,
        gx: Float,
        gy: Float,
        bounds: BoardBounds,
        coins: List<CarromCoin>,
        maxDist: Float,
        settings: AssistantSettings
    ): List<ShotCandidate> {
        val results = mutableListOf<ShotCandidate>()
        val cushionPadding = 18f

        // Cushions: Top, Left, Right
        val cushions = listOf(
            Triple("TOP", bounds.rect.top + cushionPadding, true),
            Triple("LEFT", bounds.rect.left + cushionPadding, false),
            Triple("RIGHT", bounds.rect.right - cushionPadding, false)
        )

        for ((side, cushionCoord, isHorizontal) in cushions) {
            val (bounceX, bounceY) = if (isHorizontal) {
                // Top cushion: mirror gy across top wall
                val mirrorGy = 2 * cushionCoord - gy
                if (mirrorGy == sy) continue
                val t = (cushionCoord - sy) / (mirrorGy - sy)
                if (t <= 0f || t >= 1f) continue
                Pair(sx + t * (gx - sx), cushionCoord)
            } else {
                // Left or Right cushion: mirror gx across wall
                val mirrorGx = 2 * cushionCoord - gx
                if (mirrorGx == sx) continue
                val t = (cushionCoord - sx) / (mirrorGx - sx)
                if (t <= 0f || t >= 1f) continue
                Pair(cushionCoord, sy + t * (gy - sy))
            }

            // Bounce point must be within playing surface
            if (!bounds.rect.contains(bounceX, bounceY)) continue

            // Angle of incidence vs angle of reflection cut angle
            val cutAngle = calculateCutAngle(
                bounceX, bounceY, gx, gy, coin.x, coin.y, pocket.x, pocket.y
            )
            if (cutAngle > MAX_CUT_ANGLE_DEG * 0.85f) continue

            // Check obstruction on segment 1 (striker -> cushion) and segment 2 (cushion -> coin)
            val path1Blocked = isSegmentObstructed(
                sx, sy, bounceX, bounceY, coins, STRIKER_RADIUS_PX_DEFAULT, coin.id
            )
            val path2Blocked = isSegmentObstructed(
                bounceX, bounceY, gx, gy, coins, STRIKER_RADIUS_PX_DEFAULT, coin.id
            )
            val coinBlocked = isSegmentObstructed(
                coin.x, coin.y, pocket.x, pocket.y, coins, coin.radius, coin.id
            )

            val dist1 = hypot(bounceX - sx, bounceY - sy)
            val dist2 = hypot(gx - bounceX, gy - bounceY)
            val distCoin = hypot(pocket.x - coin.x, pocket.y - coin.y)
            val totalDist = dist1 + dist2 + distCoin

            val angleScore = ((MAX_CUT_ANGLE_DEG - cutAngle) / MAX_CUT_ANGLE_DEG) * 50f
            val distScore = ((maxDist - totalDist) / maxDist).coerceAtLeast(0f) * 20f

            var penalty = 18f // Cushion bank execution penalty
            if (path1Blocked) penalty += 40f
            if (path2Blocked) penalty += 40f
            if (coinBlocked) penalty += 35f

            val queenBonus = if (settings.prioritizeQueen && coin.type == CoinType.QUEEN) 15f else 0f
            val rawConfidence = (angleScore + distScore + queenBonus - penalty).roundToInt()
            val confidence = rawConfidence.coerceIn(5, 95)

            if (confidence >= settings.minConfidenceThreshold) {
                val aimAngle = calculateAimAngleDeg(sx, sy, bounceX, bounceY)
                val powerFactor = (totalDist / maxDist) * 65f + 15f // Cushion dampening requires extra power
                val power = powerFactor.roundToInt().coerceIn(40, 100)

                results.add(
                    ShotCandidate(
                        targetCoin = coin,
                        targetPocket = pocket,
                        ghostStrikerX = gx,
                        ghostStrikerY = gy,
                        cutAngleDeg = round(cutAngle * 10f) / 10f,
                        confidence = confidence,
                        estimatedPower = power,
                        aimAngleDeg = aimAngle,
                        isBankShot = true,
                        bankBounceX = bounceX,
                        bankBounceY = bounceY
                    )
                )
            }
        }

        return results
    }
}
