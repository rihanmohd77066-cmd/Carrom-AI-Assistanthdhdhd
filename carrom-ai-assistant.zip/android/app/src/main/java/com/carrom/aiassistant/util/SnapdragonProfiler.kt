package com.carrom.aiassistant.util

import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.os.SystemClock

class SnapdragonProfiler(private val context: Context) {

    private var frameCount = 0
    private var lastFpsTimestamp = SystemClock.elapsedRealtime()
    var currentFps = 60f
        private set

    var currentLatencyMs = 16L
        private set

    fun onFrameProcessed(latencyMs: Long) {
        currentLatencyMs = latencyMs
        frameCount++
        val now = SystemClock.elapsedRealtime()
        val elapsed = now - lastFpsTimestamp
        if (elapsed >= 1000L) {
            currentFps = (frameCount * 1000f) / elapsed
            frameCount = 0
            lastFpsTimestamp = now
        }
    }

    fun getMemoryUsageMb(): Long {
        val runtime = Runtime.getRuntime()
        val usedMem = runtime.totalMemory() - runtime.freeMemory()
        return usedMem / (1024 * 1024)
    }

    fun getThermalStatus(): String {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val pm = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            return when (pm?.currentThermalStatus) {
                PowerManager.THERMAL_STATUS_NONE -> "Nominal"
                PowerManager.THERMAL_STATUS_LIGHT -> "Light"
                PowerManager.THERMAL_STATUS_MODERATE -> "Moderate"
                PowerManager.THERMAL_STATUS_SEVERE -> "Throttling"
                else -> "Normal"
            }
        }
        return "Normal"
    }
}
