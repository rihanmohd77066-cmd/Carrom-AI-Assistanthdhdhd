package com.carrom.aiassistant.cv

import android.graphics.RectF
import android.util.Log
import com.carrom.aiassistant.model.BoardBounds
import com.carrom.aiassistant.model.Pocket
import org.opencv.core.*
import org.opencv.imgproc.Imgproc
import kotlin.math.abs

/**
 * Phase 4: Board Detection Engine.
 *
 * Implements computer vision detection of the square carrom board boundaries
 * and four corner pockets using OpenCV contour approximation, edge analysis,
 * and adaptive fallback calibration for the OnePlus Nord CE 3 Lite 5G.
 */
class BoardDetector {

    companion object {
        const val TAG = "BoardDetector"
        const val STANDARD_CARROM_BOARD_MM = 740f // Standard Indian Carrom Board: 740mm x 740mm ply
    }

    // Pre-allocated Mats to eliminate GC churn on Snapdragon 695 Kryo cores
    private val grayMat = Mat()
    private val blurMat = Mat()
    private val edgesMat = Mat()
    private val hierarchyMat = Mat()

    // Cached bounds with confidence tracking
    private var cachedBounds: BoardBounds? = null
    private var consecutiveDetectionCount = 0

    /**
     * Detects carrom board boundaries and extracts the 4 corner pockets.
     * Supports various board sizes, scaling, and screen resolutions.
     */
    fun detectBoard(frame: Mat): BoardBounds {
        val width = frame.cols().toFloat()
        val height = frame.rows().toFloat()

        if (width <= 0 || height <= 0 || frame.empty()) {
            return getFallbackBoardBounds(width, height)
        }

        try {
            // 1. Grayscale conversion
            Imgproc.cvtColor(frame, grayMat, Imgproc.COLOR_RGBA2GRAY)

            // 2. Gaussian blur to suppress ply wood grain and reflection noise
            Imgproc.GaussianBlur(grayMat, blurMat, Size(7.0, 7.0), 1.5, 1.5)

            // 3. Canny edge detection for high-contrast cushion borders
            Imgproc.Canny(blurMat, edgesMat, 50.0, 150.0)

            // 4. Find external contours of playing field
            val contours = mutableListOf<MatOfPoint>()
            Imgproc.findContours(
                edgesMat,
                contours,
                hierarchyMat,
                Imgproc.RETR_EXTERNAL,
                Imgproc.CHAIN_APPROX_SIMPLE
            )

            var bestBoardRect: RectF? = null
            var maxValidArea = 0.0
            val totalFrameArea = width * height

            val approxCurve = MatOfPoint2f()

            for (contour in contours) {
                val contour2f = MatOfPoint2f(*contour.toArray())
                val perimeter = Imgproc.arcLength(contour2f, true)

                // Approximate polygonal curve with 2.5% epsilon
                Imgproc.approxPolyDP(contour2f, approxCurve, 0.025 * perimeter, true)

                val points = approxCurve.toArray()
                // Carrom boards are quadrilaterals (4 vertices)
                if (points.size in 4..6) {
                    val boundingRect = Imgproc.boundingRect(contour)
                    val bWidth = boundingRect.width.toFloat()
                    val bHeight = boundingRect.height.toFloat()
                    val area = (bWidth * bHeight).toDouble()

                    // Must occupy between 25% and 85% of screen area
                    val areaRatio = area / totalFrameArea
                    if (areaRatio in 0.20..0.88) {
                        // Square check: Aspect ratio should be approximately 1.0 (between 0.85 and 1.15)
                        val aspectRatio = bWidth / bHeight
                        if (aspectRatio in 0.85f..1.15f) {
                            if (area > maxValidArea) {
                                maxValidArea = area
                                bestBoardRect = RectF(
                                    boundingRect.x.toFloat(),
                                    boundingRect.y.toFloat(),
                                    (boundingRect.x + boundingRect.width).toFloat(),
                                    (boundingRect.y + boundingRect.height).toFloat()
                                )
                            }
                        }
                    }
                }
            }

            if (bestBoardRect != null) {
                consecutiveDetectionCount++
                val bounds = computePocketsAndBaseline(bestBoardRect)
                cachedBounds = bounds
                return bounds
            }
        } catch (e: Exception) {
            Log.e(TAG, "Exception during OpenCV board detection", e)
        }

        // If no polygon detected in current frame, use cached bounds or calibrated device default
        return cachedBounds ?: getFallbackBoardBounds(width, height)
    }

    /**
     * Computes the 4 corner pockets, player baseline, and scale factor from detected board rect.
     */
    private fun computePocketsAndBaseline(rect: RectF): BoardBounds {
        val boardWidth = rect.width()
        val boardHeight = rect.height()
        val boardSize = minOf(boardWidth, boardHeight)

        // Pocket geometry standards:
        // Pockets are set inward by ~5.5% of board size from outer corner
        val cornerOffset = boardSize * 0.055f
        val pocketRadius = boardSize * 0.046f

        val pockets = listOf(
            Pocket("TL", "Top-Left", rect.left + cornerOffset, rect.top + cornerOffset, pocketRadius),
            Pocket("TR", "Top-Right", rect.right - cornerOffset, rect.top + cornerOffset, pocketRadius),
            Pocket("BL", "Bottom-Left", rect.left + cornerOffset, rect.bottom - cornerOffset, pocketRadius),
            Pocket("BR", "Bottom-Right", rect.right - cornerOffset, rect.bottom - cornerOffset, pocketRadius)
        )

        // Player's bottom striker baseline is 16.5% above the bottom cushion
        val baselineY = rect.bottom - boardSize * 0.165f

        // Normalization scale factor relative to standard 740mm board ply
        val scaleFactor = boardSize / STANDARD_CARROM_BOARD_MM

        return BoardBounds(
            rect = rect,
            pockets = pockets,
            baselineY = baselineY,
            scaleFactor = scaleFactor
        )
    }

    /**
     * Fallback geometry calibrated for Carrom Pool on 20:9 displays (OnePlus Nord CE 3 Lite 5G, 1080x2400).
     */
    fun getFallbackBoardBounds(screenWidth: Float, screenHeight: Float): BoardBounds {
        val effectiveWidth = if (screenWidth > 0) screenWidth else 1080f
        val effectiveHeight = if (screenHeight > 0) screenHeight else 2400f

        val boardSize = minOf(effectiveWidth * 0.94f, effectiveHeight * 0.52f)
        val left = (effectiveWidth - boardSize) / 2f
        val top = (effectiveHeight - boardSize) / 2f
        val right = left + boardSize
        val bottom = top + boardSize

        val cornerOffset = boardSize * 0.055f
        val pocketRadius = boardSize * 0.046f

        val pockets = listOf(
            Pocket("TL", "Top-Left", left + cornerOffset, top + cornerOffset, pocketRadius),
            Pocket("TR", "Top-Right", right - cornerOffset, top + cornerOffset, pocketRadius),
            Pocket("BL", "Bottom-Left", left + cornerOffset, bottom - cornerOffset, pocketRadius),
            Pocket("BR", "Bottom-Right", right - cornerOffset, bottom - cornerOffset, pocketRadius)
        )

        val baselineY = bottom - boardSize * 0.165f

        return BoardBounds(
            rect = RectF(left, top, right, bottom),
            pockets = pockets,
            baselineY = baselineY,
            scaleFactor = boardSize / STANDARD_CARROM_BOARD_MM
        )
    }

    fun release() {
        grayMat.release()
        blurMat.release()
        edgesMat.release()
        hierarchyMat.release()
        cachedBounds = null
    }
}
