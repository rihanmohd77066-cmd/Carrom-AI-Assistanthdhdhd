package com.carrom.aiassistant

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.carrom.aiassistant.databinding.ActivitySettingsBinding
import com.carrom.aiassistant.util.PermissionHelper
import com.carrom.aiassistant.util.PreferencesManager

class SettingsActivity : AppCompatActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private lateinit var prefsManager: PreferencesManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        prefsManager = PreferencesManager(this)

        setupWindowInsets()
        setupToolbar()
        loadPreferencesIntoUi()
        setupListeners()
    }

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.coordinatorSettings) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun setupToolbar() {
        binding.toolbarSettings.setNavigationOnClickListener {
            finish()
        }
    }

    private fun loadPreferencesIntoUi() {
        // Trajectory Switches
        binding.switchBankShots.isChecked = prefsManager.enableBankShots
        binding.switchTrajectoryGlow.isChecked = prefsManager.enableGlow
        binding.switchGhostStriker.isChecked = prefsManager.showGhostStriker

        // Guide Thickness Slider
        val thickness = prefsManager.guideThickness
        binding.sliderThickness.value = thickness
        binding.tvThicknessLabel.text = "Guide Line Thickness: ${String.format("%.1f", thickness)} dp"

        // Shot Priorities
        binding.switchPrioritizeQueen.isChecked = prefsManager.prioritizeQueen

        // Confidence Slider
        val conf = prefsManager.minConfidence
        binding.sliderConfidence.value = conf.toFloat()
        binding.tvConfidenceLabel.text = "Minimum Shot Confidence Filter: $conf%"

        // Coin Filter Segment
        when (prefsManager.targetCoinFilter) {
            "WHITE" -> binding.toggleTargetCoins.check(R.id.btnTargetWhite)
            "BLACK" -> binding.toggleTargetCoins.check(R.id.btnTargetBlack)
            else -> binding.toggleTargetCoins.check(R.id.btnTargetAll)
        }

        // FPS Segment
        when (prefsManager.targetFps) {
            30 -> binding.toggleFps.check(R.id.btnFps30)
            60 -> binding.toggleFps.check(R.id.btnFps60)
            else -> binding.toggleFps.check(R.id.btnFps45)
        }
    }

    private fun setupListeners() {
        // Trajectory options
        binding.switchBankShots.setOnCheckedChangeListener { _, isChecked ->
            prefsManager.enableBankShots = isChecked
        }

        binding.switchTrajectoryGlow.setOnCheckedChangeListener { _, isChecked ->
            prefsManager.enableGlow = isChecked
        }

        binding.switchGhostStriker.setOnCheckedChangeListener { _, isChecked ->
            prefsManager.showGhostStriker = isChecked
        }

        binding.sliderThickness.addOnChangeListener { _, value, _ ->
            prefsManager.guideThickness = value
            binding.tvThicknessLabel.text = "Guide Line Thickness: ${String.format("%.1f", value)} dp"
        }

        // Priorities
        binding.switchPrioritizeQueen.setOnCheckedChangeListener { _, isChecked ->
            prefsManager.prioritizeQueen = isChecked
        }

        binding.sliderConfidence.addOnChangeListener { _, value, _ ->
            val intVal = value.toInt()
            prefsManager.minConfidence = intVal
            binding.tvConfidenceLabel.text = "Minimum Shot Confidence Filter: $intVal%"
        }

        // Target Coins
        binding.toggleTargetCoins.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                val filter = when (checkedId) {
                    R.id.btnTargetWhite -> "WHITE"
                    R.id.btnTargetBlack -> "BLACK"
                    else -> "ALL"
                }
                prefsManager.targetCoinFilter = filter
            }
        }

        // FPS Selection
        binding.toggleFps.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                val fps = when (checkedId) {
                    R.id.btnFps30 -> 30
                    R.id.btnFps60 -> 60
                    else -> 45
                }
                prefsManager.targetFps = fps
            }
        }

        // Battery Optimization
        binding.btnBatteryOptimization.setOnClickListener {
            if (PermissionHelper.isIgnoringBatteryOptimizations(this)) {
                Toast.makeText(this, "Already exempt from battery optimizations", Toast.LENGTH_SHORT).show()
            } else {
                PermissionHelper.requestIgnoreBatteryOptimizations(this)
            }
        }

        // Reset to Defaults
        binding.btnResetDefaults.setOnClickListener {
            prefsManager.resetToDefaults()
            loadPreferencesIntoUi()
            Toast.makeText(this, "Settings restored to recommended defaults", Toast.LENGTH_SHORT).show()
        }
    }
}
