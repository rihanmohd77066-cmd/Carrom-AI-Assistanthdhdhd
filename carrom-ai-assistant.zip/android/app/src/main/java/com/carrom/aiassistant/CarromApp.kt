package com.carrom.aiassistant

import android.app.Application
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import android.util.Log
import org.opencv.android.OpenCVLoader

class CarromApp : Application() {

    companion object {
        const val TAG = "CarromAIAssistant"
        const val NOTIFICATION_CHANNEL_ID = "carrom_assistant_channel"
        var isOpenCvInitialized: Boolean = false
            private set
    }

    override fun onCreate() {
        super.onCreate()
        initOpenCv()
        createNotificationChannel()
    }

    private fun initOpenCv() {
        isOpenCvInitialized = try {
            if (OpenCVLoader.initDebug()) {
                Log.d(TAG, "OpenCV native libraries loaded successfully.")
                true
            } else {
                Log.e(TAG, "OpenCVLoader.initDebug() failed.")
                false
            }
        } catch (e: Throwable) {
            Log.e(TAG, "Failed to initialize OpenCV", e)
            false
        }
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                NOTIFICATION_CHANNEL_ID,
                getString(R.string.notification_channel_name),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.notification_channel_desc)
                setShowBadge(false)
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }
    }
}
