package com.carrom.aiassistant.overlay

import android.content.Context
import android.graphics.*
import android.util.AttributeSet
import android.view.View
import androidx.core.content.ContextCompat
import com.carrom.aiassistant.R
import com.carrom.aiassistant.model.CarromCoin
import com.carrom.aiassistant.model.CoinType
import com.carrom.aiassistant.model.ShotCandidate
import com.carrom.aiassistant.model.TrajectoryResult

/**
 * Phase 7: Trajectory Visualization Canvas.
 *
 * Custom Surface/Canvas renderer with hardware acceleration, drawing:
 * 1. Striker trajectory vectors (solid cyan line).
 * 2. Cushion bank rebound vectors with bounce normal indicator.
 * 3. Ghost striker circular impact envelope at collision coordinates.
 * 4. Predicted coin flight paths (dashed colored line) into destination pocket.
 * 5. Destination pocket glowing highlight rings.
 * 6. Visual tracking markers on all detected board coins.
 * 7. HUD metric badges (Confidence %, Cut Angle, Power %, Aiming Angle).
 */
class TrajectoryCanvasView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private var currentTrajectory: TrajectoryResult? = null
    var isTrajectoryVisible: Boolean = true
    var showCoinMarkers: Boolean = true
    var selectedShotIndex: Int = 0

    // Reusable Paints for zero-allocation 120Hz display refresh
    private val strikerPathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#06B6D4") // Cyan glow
        strokeWidth = 4.5f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }

    private val bankPathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#F59E0B") // Amber bank path
        strokeWidth = 4.5f
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        pathEffect = DashPathEffect(floatArrayOf(16f, 10f), 0f)
    }

    private val coinPathPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        strokeWidth = 5.5f
        style = Paint.Style.STROKE
        pathEffect = DashPathEffect(floatArrayOf(18f, 10f), 0f)
        strokeCap = Paint.Cap.ROUND
    }

    private val ghostStrikerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(160, 6, 182, 212)
        style = Paint.Style.STROKE
        strokeWidth = 3f
        pathEffect = DashPathEffect(floatArrayOf(8f, 6f), 0f)
    }

    private val ghostFillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.argb(45, 6, 182, 212)
        style = Paint.Style.FILL
    }

    private val impactPointPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }

    private val pocketHighlightPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
    }

    private val coinMarkerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 2.5f
    }

    private val badgeBgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#E60B0F19")
        style = Paint.Style.FILL
    }

    private val badgeBorderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 1.8f
    }

    private val badgeTextPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        textSize = 26f
        typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
        setShadowLayer(3f, 1f, 1f, Color.BLACK)
    }

    fun updateTrajectory(result: TrajectoryResult) {
        this.currentTrajectory = result
        postInvalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (!isTrajectoryVisible) return

        val result = currentTrajectory ?: return

        // 1. Draw Visual Markers for all detected coins on board
        if (showCoinMarkers) {
            drawCoinMarkers(canvas, result.detectedCoins)
        }

        // 2. Select Shot Candidate (Top shot or manually selected alternative)
        val allShots = mutableListOf<ShotCandidate>()
        result.topShot?.let { allShots.add(it) }
        allShots.addAll(result.alternativeShots)

        if (allShots.isEmpty()) return

        val activeIndex = selectedShotIndex.coerceIn(0, allShots.size - 1)
        val activeShot = allShots[activeIndex]

        // Confidence Color: Green (High >=70%), Yellow (Medium >=45%), Red (Low <45%)
        val confidenceColor = when {
            activeShot.confidence >= 70 -> Color.parseColor("#10B981") // Emerald
            activeShot.confidence >= 45 -> Color.parseColor("#F59E0B") // Amber
            else -> Color.parseColor("#EF4444")                         // Rose
        }
        coinPathPaint.color = confidenceColor
        pocketHighlightPaint.color = confidenceColor
        badgeBorderPaint.color = confidenceColor

        // 3. Draw Striker Trajectory Line(s)
        if (activeShot.isBankShot) {
            // Segment 1: Striker -> Cushion Bounce Point
            canvas.drawLine(
                result.strikerOriginX, result.strikerOriginY,
                activeShot.bankBounceX, activeShot.bankBounceY,
                strikerPathPaint
            )

            // Cushion Rebound Point Indicator
            canvas.drawCircle(activeShot.bankBounceX, activeShot.bankBounceY, 7f, impactPointPaint)

            // Segment 2: Cushion Bounce Point -> Ghost Striker
            canvas.drawLine(
                activeShot.bankBounceX, activeShot.bankBounceY,
                activeShot.ghostStrikerX, activeShot.ghostStrikerY,
                bankPathPaint
            )
        } else {
            // Direct Shot: Striker -> Ghost Striker
            canvas.drawLine(
                result.strikerOriginX, result.strikerOriginY,
                activeShot.ghostStrikerX, activeShot.ghostStrikerY,
                strikerPathPaint
            )
        }

        // 4. Draw Ghost Striker Circle at impact coordinate
        val strikerRadius = 24f
        canvas.drawCircle(activeShot.ghostStrikerX, activeShot.ghostStrikerY, strikerRadius, ghostFillPaint)
        canvas.drawCircle(activeShot.ghostStrikerX, activeShot.ghostStrikerY, strikerRadius, ghostStrikerPaint)

        // Impact center dot
        canvas.drawCircle(activeShot.ghostStrikerX, activeShot.ghostStrikerY, 4f, impactPointPaint)

        // 5. Draw Target Coin Line of Flight into Destination Pocket
        canvas.drawLine(
            activeShot.targetCoin.x, activeShot.targetCoin.y,
            activeShot.targetPocket.x, activeShot.targetPocket.y,
            coinPathPaint
        )

        // 6. Draw Destination Pocket Highlight Rings
        canvas.drawCircle(
            activeShot.targetPocket.x,
            activeShot.targetPocket.y,
            activeShot.targetPocket.radius + 4f,
            pocketHighlightPaint
        )

        // 7. Draw HUD Badge with Confidence, Cut Angle, Power, and Aim
        drawHudBadge(canvas, activeShot, strikerRadius)
    }

    /**
     * Draws identifying visual markers and colored halos around detected coins.
     */
    private fun drawCoinMarkers(canvas: Canvas, coins: List<CarromCoin>) {
        for (coin in coins) {
            when (coin.type) {
                CoinType.QUEEN -> {
                    coinMarkerPaint.color = Color.parseColor("#EF4444")
                    canvas.drawCircle(coin.x, coin.y, coin.radius + 3f, coinMarkerPaint)
                }
                CoinType.WHITE -> {
                    coinMarkerPaint.color = Color.parseColor("#E2E8F0")
                    canvas.drawCircle(coin.x, coin.y, coin.radius + 2f, coinMarkerPaint)
                }
                CoinType.BLACK -> {
                    coinMarkerPaint.color = Color.parseColor("#475569")
                    canvas.drawCircle(coin.x, coin.y, coin.radius + 2f, coinMarkerPaint)
                }
                CoinType.STRIKER -> {
                    coinMarkerPaint.color = Color.parseColor("#06B6D4")
                    canvas.drawCircle(coin.x, coin.y, coin.radius + 4f, coinMarkerPaint)
                }
            }
        }
    }

    /**
     * Draws floating HUD badge with confidence, cut angle, and estimated power.
     */
    private fun drawHudBadge(canvas: Canvas, shot: ShotCandidate, strikerRadius: Float) {
        val shotTypePrefix = if (shot.isBankShot) "BANK " else ""
        val line1 = "${shotTypePrefix}${shot.confidence}% CONF • ${shot.cutAngleDeg}° CUT"
        val line2 = "AIM: ${shot.aimAngleDeg}° • PWR: ${shot.estimatedPower}%"

        val textWidth1 = badgeTextPaint.measureText(line1)
        val textWidth2 = badgeTextPaint.measureText(line2)
        val maxWidth = maxOf(textWidth1, textWidth2)

        val badgeX = shot.ghostStrikerX
        val badgeY = shot.ghostStrikerY - strikerRadius - 38f

        val paddingH = 14f
        val rectLeft = badgeX - maxWidth / 2f - paddingH
        val rectRight = badgeX + maxWidth / 2f + paddingH
        val rectTop = badgeY - 24f
        val rectBottom = badgeY + 44f

        val badgeRect = RectF(rectLeft, rectTop, rectRight, rectBottom)
        canvas.drawRoundRect(badgeRect, 12f, 12f, badgeBgPaint)
        canvas.drawRoundRect(badgeRect, 12f, 12f, badgeBorderPaint)

        canvas.drawText(line1, badgeX - textWidth1 / 2f, badgeY + 2f, badgeTextPaint)
        canvas.drawText(line2, badgeX - textWidth2 / 2f, badgeY + 32f, badgeTextPaint)
    }
}
