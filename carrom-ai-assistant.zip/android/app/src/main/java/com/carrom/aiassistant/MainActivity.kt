package com.carrom.aiassistant

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.carrom.aiassistant.databinding.ActivityMainBinding
import com.carrom.aiassistant.service.FloatingOverlayService
import com.carrom.aiassistant.service.ScreenCaptureService
import com.carrom.aiassistant.util.PermissionHelper

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val mediaProjectionLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            startAssistantServices(result.resultCode, result.data!!)
        } else {
            Toast.makeText(this, "Screen capture authorization is required for assistant analysis", Toast.LENGTH_SHORT).show()
            updatePermissionStatuses()
        }
    }

    private val notificationPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (!isGranted) {
            Toast.makeText(this, "Notifications required for persistent service status", Toast.LENGTH_SHORT).show()
        }
        updatePermissionStatuses()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupWindowInsets()
        setupListeners()
        updatePermissionStatuses()
    }

    override fun onResume() {
        super.onResume()
        updatePermissionStatuses()
        attachCapturePreviewListeners()
    }

    override fun onPause() {
        detachCapturePreviewListeners()
        super.onPause()
    }

    private fun attachCapturePreviewListeners() {
        ScreenCaptureService.onFramePreview = { previewBitmap, fps, latencyMs, coinCount ->
            binding.ivLivePreview.setImageBitmap(previewBitmap)
            binding.llPreviewPlaceholder.visibility = android.view.View.GONE
            binding.tvPreviewFps.text = String.format("%.1f FPS • %d ms", fps, latencyMs)
            binding.tvPreviewCoinsDetected.text = "Objects: $coinCount coins • OpenCV Mat"
            binding.tvCaptureEngineStatus.text = if (ScreenCaptureService.isPaused) "PAUSED" else "STREAMING"
            binding.tvCaptureEngineStatus.setTextColor(
                ContextCompat.getColor(
                    this,
                    if (ScreenCaptureService.isPaused) R.color.accent_warning else R.color.accent_secondary
                )
            )
            binding.btnToggleCapturePause.isEnabled = true
            binding.btnToggleCapturePause.text = if (ScreenCaptureService.isPaused) "Resume Stream" else "Pause Stream"
        }

        ScreenCaptureService.onCaptureStateChanged = { isCapturing, isPaused ->
            updateCapturePreviewState(isCapturing, isPaused)
        }

        updateCapturePreviewState(ScreenCaptureService.isCapturing, ScreenCaptureService.isPaused)
    }

    private fun detachCapturePreviewListeners() {
        ScreenCaptureService.onFramePreview = null
        ScreenCaptureService.onCaptureStateChanged = null
    }

    private fun updateCapturePreviewState(isCapturing: Boolean, isPaused: Boolean) {
        if (!isCapturing) {
            binding.tvCaptureEngineStatus.text = "STANDBY"
            binding.tvCaptureEngineStatus.setTextColor(ContextCompat.getColor(this, R.color.text_muted))
            binding.btnToggleCapturePause.isEnabled = false
            binding.btnToggleCapturePause.text = "Pause Stream"
            binding.llPreviewPlaceholder.visibility = android.view.View.VISIBLE
            binding.ivLivePreview.setImageDrawable(null)
            binding.tvPreviewFps.text = "0.0 FPS • 0 ms"
            binding.tvPreviewCoinsDetected.text = "Offline OpenCV Mat Pipeline: Ready"
        } else if (isPaused) {
            binding.tvCaptureEngineStatus.text = "PAUSED"
            binding.tvCaptureEngineStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_warning))
            binding.btnToggleCapturePause.isEnabled = true
            binding.btnToggleCapturePause.text = "Resume Stream"
        } else {
            binding.tvCaptureEngineStatus.text = "STREAMING"
            binding.tvCaptureEngineStatus.setTextColor(ContextCompat.getColor(this, R.color.accent_secondary))
            binding.btnToggleCapturePause.isEnabled = true
            binding.btnToggleCapturePause.text = "Pause Stream"
            binding.llPreviewPlaceholder.visibility = android.view.View.GONE
        }
    }

    private fun setupWindowInsets() {
        ViewCompat.setOnApplyWindowInsetsListener(binding.coordinatorMain) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
    }

    private fun setupListeners() {
        // Overlay Permission Button
        binding.btnGrantOverlay.setOnClickListener {
            PermissionHelper.requestOverlayPermission(this)
        }

        // Screen Capture Authorization Button
        binding.btnAuthorizeCapture.setOnClickListener {
            requestScreenCapture()
        }

        // Live Preview Pause / Resume Stream Toggle
        binding.btnToggleCapturePause.setOnClickListener {
            if (ScreenCaptureService.isPaused) {
                val resumeIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_RESUME
                }
                startService(resumeIntent)
            } else {
                val pauseIntent = Intent(this, ScreenCaptureService::class.java).apply {
                    action = ScreenCaptureService.ACTION_PAUSE
                }
                startService(pauseIntent)
            }
        }

        // Notification Permission Button
        binding.btnGrantNotification.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
            }
        }

        // Battery Optimization Whitelist Button
        binding.btnWhitelistBattery.setOnClickListener {
            PermissionHelper.requestIgnoreBatteryOptimizations(this)
        }

        // Assistant Toggle (Start / Stop)
        binding.btnToggleAssistant.setOnClickListener {
            if (FloatingOverlayService.isServiceRunning) {
                stopAssistantServices()
            } else {
                checkPermissionsAndStart()
            }
        }

        // Carrom Pool Game Launcher
        binding.btnLaunchGame.setOnClickListener {
            val launched = PermissionHelper.launchCarromPool(this)
            if (!launched) {
                Toast.makeText(this, getString(R.string.carrom_pool_not_installed), Toast.LENGTH_LONG).show()
            }
        }

        // Open Settings Activity
        binding.btnOpenSettings.setOnClickListener {
            val intent = Intent(this, SettingsActivity::class.java)
            startActivity(intent)
        }
    }

    private fun updatePermissionStatuses() {
        // 1. System Overlay Permission
        val hasOverlay = PermissionHelper.hasOverlayPermission(this)
        if (hasOverlay) {
            binding.ivOverlayStatus.setColorFilter(ContextCompat.getColor(this, R.color.accent_secondary))
            binding.btnGrantOverlay.text = "Granted"
            binding.btnGrantOverlay.isEnabled = false
        } else {
            binding.ivOverlayStatus.setColorFilter(ContextCompat.getColor(this, R.color.accent_danger))
            binding.btnGrantOverlay.text = "Grant"
            binding.btnGrantOverlay.isEnabled = true
        }

        // 2. Notification Permission (Android 13+)
        val hasNotification = PermissionHelper.hasNotificationPermission(this)
        if (hasNotification) {
            binding.ivNotificationStatus.setColorFilter(ContextCompat.getColor(this, R.color.accent_secondary))
            binding.btnGrantNotification.text = "Allowed"
            binding.btnGrantNotification.isEnabled = false
        } else {
            binding.ivNotificationStatus.setColorFilter(ContextCompat.getColor(this, R.color.accent_warning))
            binding.btnGrantNotification.text = "Allow"
            binding.btnGrantNotification.isEnabled = true
        }

        // 3. Battery Optimization Exemption
        val isExempt = PermissionHelper.isIgnoringBatteryOptimizations(this)
        if (isExempt) {
            binding.ivBatteryStatus.setColorFilter(ContextCompat.getColor(this, R.color.accent_secondary))
            binding.btnWhitelistBattery.text = "Exempt"
            binding.btnWhitelistBattery.isEnabled = false
        } else {
            binding.ivBatteryStatus.setColorFilter(ContextCompat.getColor(this, R.color.accent_warning))
            binding.btnWhitelistBattery.text = "Whitelist"
            binding.btnWhitelistBattery.isEnabled = true
        }

        // 4. Update Game Launcher Button text based on installation
        val isGameInstalled = PermissionHelper.isCarromPoolInstalled(this)
        if (isGameInstalled) {
            binding.btnLaunchGame.text = "Launch Carrom Pool (Installed)"
            binding.btnLaunchGame.setTextColor(ContextCompat.getColor(this, R.color.accent_secondary))
        } else {
            binding.btnLaunchGame.text = "Get Carrom Pool from Google Play"
            binding.btnLaunchGame.setTextColor(ContextCompat.getColor(this, R.color.text_primary))
        }

        // 5. Update Assistant Running State
        val isRunning = FloatingOverlayService.isServiceRunning
        if (isRunning) {
            binding.btnToggleAssistant.text = getString(R.string.stop_assistant)
            binding.btnToggleAssistant.setBackgroundColor(ContextCompat.getColor(this, R.color.accent_danger))
            binding.ivCaptureStatus.setColorFilter(ContextCompat.getColor(this, R.color.accent_secondary))
            binding.btnAuthorizeCapture.text = "Active"
            binding.btnAuthorizeCapture.isEnabled = false
        } else {
            binding.btnToggleAssistant.text = getString(R.string.start_assistant)
            binding.btnToggleAssistant.setBackgroundColor(ContextCompat.getColor(this, R.color.accent_primary))
            binding.ivCaptureStatus.setColorFilter(ContextCompat.getColor(this, R.color.accent_warning))
            binding.btnAuthorizeCapture.text = "Authorize"
            binding.btnAuthorizeCapture.isEnabled = true
        }
    }

    private fun checkPermissionsAndStart() {
        if (!PermissionHelper.hasOverlayPermission(this)) {
            Toast.makeText(this, "Please grant Floating Overlay permission first", Toast.LENGTH_SHORT).show()
            PermissionHelper.requestOverlayPermission(this)
            return
        }

        requestScreenCapture()
    }

    private fun requestScreenCapture() {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(mpManager.createScreenCaptureIntent())
    }

    private fun startAssistantServices(resultCode: Int, data: Intent) {
        // 1. Start Floating Overlay Service as Foreground Service
        val overlayIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = FloatingOverlayService.ACTION_START
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(overlayIntent)
        } else {
            startService(overlayIntent)
        }

        // 2. Start Screen Capture Foreground Service
        val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, resultCode)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(captureIntent)
        } else {
            startService(captureIntent)
        }

        updatePermissionStatuses()
        Toast.makeText(this, "Carrom AI Assistant started in background", Toast.LENGTH_SHORT).show()
    }

    private fun stopAssistantServices() {
        val overlayIntent = Intent(this, FloatingOverlayService::class.java).apply {
            action = FloatingOverlayService.ACTION_STOP
        }
        startService(overlayIntent)

        val captureIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_STOP
        }
        startService(captureIntent)

        updatePermissionStatuses()
        Toast.makeText(this, "Carrom AI Assistant stopped", Toast.LENGTH_SHORT).show()
    }
}
