package com.carrom.aiassistant.service

import android.app.Notification
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.carrom.aiassistant.CarromApp
import com.carrom.aiassistant.MainActivity
import com.carrom.aiassistant.R
import com.carrom.aiassistant.cv.CarromVisionEngine
import com.carrom.aiassistant.model.AssistantSettings
import com.carrom.aiassistant.model.TrajectoryResult
import kotlinx.coroutines.*
import java.nio.ByteBuffer
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Phase 3: Screen Capture Engine for Carrom AI Assistant.
 *
 * Implements Android MediaProjection API with ImageReader (RGBA_8888),
 * OpenCV Mat conversion, zero-memory-leak frame buffering, adaptive 15-30 FPS regulation,
 * dynamic screen rotation/resolution tracking, and live thumbnail preview dispatch.
 * Fully compliant with Android 15 foreground service requirements.
 */
class ScreenCaptureService : Service() {

    companion object {
        const val TAG = "ScreenCaptureService"
        const val ACTION_START = "ACTION_START_CAPTURE"
        const val ACTION_STOP = "ACTION_STOP_CAPTURE"
        const val ACTION_PAUSE = "ACTION_PAUSE_CAPTURE"
        const val ACTION_RESUME = "ACTION_RESUME_CAPTURE"
        const val EXTRA_RESULT_CODE = "EXTRA_RESULT_CODE"
        const val EXTRA_RESULT_DATA = "EXTRA_RESULT_DATA"
        const val NOTIFICATION_ID = 1001

        // Real-time telemetry & state
        var isCapturing = false
            private set
        var isPaused = false
            private set
        var currentFps = 0f
            private set
        var currentLatencyMs = 0L
            private set
        var adaptiveTargetFps = 25
            private set

        // Static listeners for zero-overhead event dispatch
        var onTrajectoryCalculated: ((TrajectoryResult) -> Unit)? = null
        var onFramePreview: ((previewBitmap: Bitmap, fps: Float, latencyMs: Long, coinCount: Int) -> Unit)? = null
        var onCaptureStateChanged: ((isCapturing: Boolean, isPaused: Boolean) -> Unit)? = null
    }

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null
    private var mediaProjectionCallback: MediaProjection.Callback? = null
    private var displayListener: DisplayManager.DisplayListener? = null

    private val visionEngine = CarromVisionEngine()
    private val settings = AssistantSettings()

    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(Dispatchers.Default + SupervisorJob())

    // Frame processing synchronization & leak prevention
    private val isProcessingFrame = AtomicBoolean(false)
    private var lastFrameTimestampNs = 0L
    private var frameCountForFps = 0
    private var lastFpsCalculationTimeMs = 0L

    // Adaptive Frame Processing (Target 15-30 FPS)
    // 30 FPS = ~33ms, 25 FPS = 40ms, 20 FPS = 50ms, 15 FPS = ~66ms
    private var targetFrameIntervalMs = 40L // Starts at 25 FPS
    private val latencyHistory = LongArray(8) { 20L }
    private var latencyIndex = 0

    // Reusable buffers to avoid Android GC churn on Snapdragon 695
    private var reusableCaptureBitmap: Bitmap? = null
    private var reusablePreviewBitmap: Bitmap? = null
    private var previewDispatchCounter = 0

    // Screen dimensions
    private var screenWidth = 1080
    private var screenHeight = 2400
    private var screenDensity = 400

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, 0)
                val resultData = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
                } else {
                    @Suppress("DEPRECATION")
                    intent.getParcelableExtra(EXTRA_RESULT_DATA)
                }

                if (resultCode != 0 && resultData != null) {
                    Log.i(TAG, "Starting ScreenCaptureService with authorized MediaProjection intent")
                    startForegroundWithNotification()
                    initMediaProjection(resultCode, resultData)
                } else {
                    Log.e(TAG, "Missing MediaProjection authorization result code or intent data")
                    stopSelf()
                }
            }
            ACTION_STOP -> {
                Log.i(TAG, "Stopping ScreenCaptureService via ACTION_STOP")
                stopCapture()
                stopSelf()
            }
            ACTION_PAUSE -> {
                Log.i(TAG, "Pausing screen capture processing")
                isPaused = true
                onCaptureStateChanged?.invoke(isCapturing, isPaused)
            }
            ACTION_RESUME -> {
                Log.i(TAG, "Resuming screen capture processing")
                isPaused = false
                onCaptureStateChanged?.invoke(isCapturing, isPaused)
            }
        }
        return START_NOT_STICKY
    }

    /**
     * Requirement 12: Android 15 foreground service compliance with FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION.
     */
    private fun startForegroundWithNotification() {
        val stopIntent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 10, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val launchIntent = Intent(this, MainActivity::class.java)
        val pendingIntent = PendingIntent.getActivity(
            this, 0, launchIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, CarromApp.NOTIFICATION_CHANNEL_ID)
            .setContentTitle("Carrom Screen Capture Active")
            .setContentText("Capturing display for offline trajectory analysis")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .addAction(
                android.R.drawable.ic_menu_close_clear_cancel,
                "Stop Capture",
                stopPendingIntent
            )
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    /**
     * Requirement 1 & 2 & 3: Initialize MediaProjection with official Android API.
     */
    private fun initMediaProjection(resultCode: Int, data: Intent) {
        val mpManager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = mpManager.getMediaProjection(resultCode, data)

        if (mediaProjection == null) {
            Log.e(TAG, "Failed to acquire MediaProjection from MediaProjectionManager")
            stopSelf()
            return
        }

        // Android 14/15 Requirement: Register MediaProjection.Callback before creating VirtualDisplay
        mediaProjectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                super.onStop()
                Log.w(TAG, "MediaProjection was revoked or stopped by user in system UI")
                mainHandler.post {
                    stopCapture()
                    stopSelf()
                }
            }
        }
        mediaProjection?.registerCallback(mediaProjectionCallback!!, mainHandler)

        // Read display metrics
        queryDisplayMetrics()

        // Requirement 11: Setup DisplayListener for screen rotation & resolution shifts
        setupDisplayListener()

        // Create VirtualDisplay and ImageReader
        createVirtualDisplayAndReader()

        isCapturing = true
        isPaused = false
        lastFpsCalculationTimeMs = System.currentTimeMillis()
        onCaptureStateChanged?.invoke(isCapturing, isPaused)
    }

    private fun queryDisplayMetrics() {
        val windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            val windowMetrics = windowManager.currentWindowMetrics
            val bounds = windowMetrics.bounds
            screenWidth = bounds.width()
            screenHeight = bounds.height()
            screenDensity = resources.configuration.densityDpi
        } else {
            val displayMetrics = DisplayMetrics()
            @Suppress("DEPRECATION")
            windowManager.defaultDisplay.getRealMetrics(displayMetrics)
            screenWidth = displayMetrics.widthPixels
            screenHeight = displayMetrics.heightPixels
            screenDensity = displayMetrics.densityDpi
        }
        Log.i(TAG, "Display metrics acquired: ${screenWidth}x${screenHeight} @ ${screenDensity}dpi")
    }

    /**
     * Requirement 11: Dynamically handle screen rotation and resolution changes.
     */
    private fun setupDisplayListener() {
        val displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
        displayListener = object : DisplayManager.DisplayListener {
            override fun onDisplayAdded(displayId: Int) {}
            override fun onDisplayRemoved(displayId: Int) {}
            override fun onDisplayChanged(displayId: Int) {
                if (displayId == Display.DEFAULT_DISPLAY && isCapturing) {
                    Log.i(TAG, "Screen orientation or resolution changed. Recreating VirtualDisplay.")
                    handleScreenMetricsChange()
                }
            }
        }
        displayManager.registerDisplayListener(displayListener, mainHandler)
    }

    private fun handleScreenMetricsChange() {
        queryDisplayMetrics()
        // Safely recreate virtual display and reader with new dimensions
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null

        // Recycle old buffers to ensure clean reallocation
        reusableCaptureBitmap?.recycle()
        reusableCaptureBitmap = null
        reusablePreviewBitmap?.recycle()
        reusablePreviewBitmap = null

        createVirtualDisplayAndReader()
    }

    /**
     * Requirement 4 & 6: ImageReader with RGBA_8888, maxImages=2, zero buffer accumulation.
     */
    private fun createVirtualDisplayAndReader() {
        if (screenWidth <= 0 || screenHeight <= 0) return

        imageReader = ImageReader.newInstance(
            screenWidth,
            screenHeight,
            PixelFormat.RGBA_8888,
            2 // Double buffering only; strictly prevents frame queue bloat
        )

        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "CarromPoolProjection",
            screenWidth,
            screenHeight,
            screenDensity,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null,
            null
        )

        startFrameProcessing()
    }

    /**
     * Requirements 6, 7 & 8: Frame rate throttling, adaptive processing (15-30 FPS),
     * and immediate resource cleanup in finally blocks.
     */
    private fun startFrameProcessing() {
        imageReader?.setOnImageAvailableListener({ reader ->
            val nowMs = System.currentTimeMillis()

            // 1. If capture is paused or analysis inactive, acquire & drop immediately
            if (isPaused || !FloatingOverlayService.isAnalysisActive) {
                val dropped = reader.acquireLatestImage()
                dropped?.close()
                return@setOnImageAvailableListener
            }

            // 2. Throttle to adaptive target FPS to prevent Snapdragon 695 thermal throttling
            val elapsedSinceLastFrame = nowMs - (lastFrameTimestampNs / 1_000_000L)
            if (elapsedSinceLastFrame < targetFrameIntervalMs) {
                val dropped = reader.acquireLatestImage()
                dropped?.close()
                return@setOnImageAvailableListener
            }

            // 3. Concurrency check: If previous frame analysis is still running, drop this frame
            if (!isProcessingFrame.compareAndSet(false, true)) {
                val dropped = reader.acquireLatestImage()
                dropped?.close()
                return@setOnImageAvailableListener
            }

            val image: Image? = try {
                reader.acquireLatestImage()
            } catch (e: Exception) {
                Log.w(TAG, "Error acquiring latest image from reader", e)
                isProcessingFrame.set(false)
                null
            }

            if (image == null) {
                isProcessingFrame.set(false)
                return@setOnImageAvailableListener
            }

            lastFrameTimestampNs = System.nanoTime()

            // 4. Offload heavy conversion and OpenCV CV analysis to Coroutines Default dispatcher
            serviceScope.launch {
                val startTime = System.currentTimeMillis()
                try {
                    processImageFrame(image, screenWidth, screenHeight)
                } catch (e: Throwable) {
                    Log.e(TAG, "Unhandled exception during frame processing", e)
                } finally {
                    // Requirement 13: ALWAYS close Image in finally block!
                    image.close()
                    isProcessingFrame.set(false)

                    val latency = System.currentTimeMillis() - startTime
                    currentLatencyMs = latency
                    recordLatencyAndAdaptFps(latency)
                    trackFps()
                }
            }
        }, null)
    }

    /**
     * Requirements 5 & 6: Convert Image planes to OpenCV Mat via reusable Bitmap buffer.
     */
    private fun processImageFrame(image: Image, width: Int, height: Int) {
        val planes = image.planes
        if (planes.isEmpty()) return

        val buffer: ByteBuffer = planes[0].buffer
        val pixelStride = planes[0].pixelStride
        val rowStride = planes[0].rowStride
        val rowPadding = rowStride - pixelStride * width

        val bitmapWidth = width + rowPadding / pixelStride
        if (reusableCaptureBitmap == null ||
            reusableCaptureBitmap?.width != bitmapWidth ||
            reusableCaptureBitmap?.height != height ||
            reusableCaptureBitmap?.isRecycled == true
        ) {
            reusableCaptureBitmap?.recycle()
            reusableCaptureBitmap = Bitmap.createBitmap(
                bitmapWidth,
                height,
                Bitmap.Config.ARGB_8888
            )
        }

        buffer.rewind()
        reusableCaptureBitmap?.copyPixelsFromBuffer(buffer)

        // Process through local OpenCV Computer Vision engine (Requirement 5)
        reusableCaptureBitmap?.let { bmp ->
            val result = visionEngine.processFrame(bmp, settings)

            // Dispatch trajectory to overlay
            mainHandler.post {
                onTrajectoryCalculated?.invoke(result)
            }

            // Requirement 10: Dispatch scaled live preview to MainActivity (~8-10 FPS)
            previewDispatchCounter++
            if (previewDispatchCounter % 3 == 0) {
                dispatchLivePreview(bmp, result.detectedCoins.size)
            }
        }
    }

    /**
     * Requirement 10: Create and dispatch downscaled preview Bitmap for MainActivity.
     */
    private fun dispatchLivePreview(sourceBmp: Bitmap, coinCount: Int) {
        if (onFramePreview == null) return

        // Downscale to 270x600 for lightweight, zero-lag preview in MainActivity
        val previewW = 270
        val previewH = (previewW * (sourceBmp.height.toFloat() / sourceBmp.width)).toInt()

        if (reusablePreviewBitmap == null ||
            reusablePreviewBitmap?.width != previewW ||
            reusablePreviewBitmap?.height != previewH ||
            reusablePreviewBitmap?.isRecycled == true
        ) {
            reusablePreviewBitmap?.recycle()
            reusablePreviewBitmap = Bitmap.createScaledBitmap(sourceBmp, previewW, previewH, true)
        } else {
            // Re-scale into existing preview bitmap
            reusablePreviewBitmap = Bitmap.createScaledBitmap(sourceBmp, previewW, previewH, false)
        }

        reusablePreviewBitmap?.let { preview ->
            mainHandler.post {
                onFramePreview?.invoke(preview, currentFps, currentLatencyMs, coinCount)
            }
        }
    }

    /**
     * Requirements 7 & 8: Adaptive Frame Processing Engine.
     * Evaluates rolling latency:
     * - If latency > 40ms: step down target FPS (towards 15 FPS) to conserve thermals.
     * - If latency < 20ms: step up target FPS (towards 30 FPS) for smoother prediction.
     */
    private fun recordLatencyAndAdaptFps(latency: Long) {
        latencyHistory[latencyIndex] = latency
        latencyIndex = (latencyIndex + 1) % latencyHistory.size

        val avgLatency = latencyHistory.average()

        if (avgLatency > 42.0) {
            // Processing taking too long: Throttle back to 15-20 FPS
            targetFrameIntervalMs = (targetFrameIntervalMs + 3L).coerceAtMost(66L) // min 15 FPS
            adaptiveTargetFps = (1000L / targetFrameIntervalMs).toInt()
        } else if (avgLatency < 22.0) {
            // Processing fast and cool: Accelerate towards 30 FPS
            targetFrameIntervalMs = (targetFrameIntervalMs - 2L).coerceAtLeast(33L) // max 30 FPS
            adaptiveTargetFps = (1000L / targetFrameIntervalMs).toInt()
        }
    }

    private fun trackFps() {
        frameCountForFps++
        val now = System.currentTimeMillis()
        val delta = now - lastFpsCalculationTimeMs
        if (delta >= 1000L) {
            currentFps = (frameCountForFps * 1000f) / delta
            frameCountForFps = 0
            lastFpsCalculationTimeMs = now
        }
    }

    /**
     * Requirement 13: Clean release of all ImageReader, VirtualDisplay, Surface, and Mat resources.
     */
    private fun stopCapture() {
        isCapturing = false
        isPaused = false
        onCaptureStateChanged?.invoke(false, false)

        try {
            displayListener?.let {
                val displayManager = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
                displayManager.unregisterDisplayListener(it)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error unregistering displayListener", e)
        } finally {
            displayListener = null
        }

        try {
            virtualDisplay?.release()
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing virtualDisplay", e)
        } finally {
            virtualDisplay = null
        }

        try {
            imageReader?.close()
        } catch (e: Exception) {
            Log.e(TAG, "Error closing imageReader", e)
        } finally {
            imageReader = null
        }

        try {
            mediaProjectionCallback?.let { mediaProjection?.unregisterCallback(it) }
            mediaProjection?.stop()
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping mediaProjection", e)
        } finally {
            mediaProjection = null
            mediaProjectionCallback = null
        }

        visionEngine.release()
        serviceScope.cancel()

        reusableCaptureBitmap?.recycle()
        reusableCaptureBitmap = null

        reusablePreviewBitmap?.recycle()
        reusablePreviewBitmap = null

        mainHandler.removeCallbacksAndMessages(null)
        Log.i(TAG, "ScreenCaptureService completely stopped and all resources freed.")
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }
}
