package com.carrom.aiassistant.cv

import android.graphics.Bitmap
import com.carrom.aiassistant.model.*
import com.carrom.aiassistant.physics.CarromPhysicsEngine
import org.opencv.android.Utils
import org.opencv.core.Mat
import org.opencv.core.Range
import kotlin.math.hypot

class CarromVisionEngine {

    private val boardDetector = BoardDetector()
    private val coinDetector = CoinDetector()
    private val physicsEngine = CarromPhysicsEngine()

    // Reusable Mat buffers
    private val fullMat = Mat()
    private var lastBoardBounds: BoardBounds? = null
    private var trackedCoins: MutableList<CarromCoin> = mutableListOf()
    private var strikerPos: Pair<Float, Float>? = null

    /**
     * Processes incoming MediaProjection screen frame Bitmap locally on Snapdragon 695.
     * No network calls, completely offline and zero-allocation pipeline.
     */
    fun processFrame(bitmap: Bitmap, settings: AssistantSettings): TrajectoryResult {
        val startTime = System.currentTimeMillis()

        // 1. Convert Android Bitmap to OpenCV Mat
        Utils.bitmapToMat(bitmap, fullMat)

        // Reset cached bounds if frame orientation or resolution changed
        if (lastBoardBounds != null && (fullMat.cols() != bitmap.width || fullMat.rows() != bitmap.height)) {
            lastBoardBounds = null
        }

        // 2. Detect board bounds (cached across frames with periodic re-check)
        val bounds = lastBoardBounds ?: boardDetector.detectBoard(fullMat).also {
            lastBoardBounds = it
        }

        // 3. Crop ROI to board area to reduce computation by 70% on Adreno 619
        val rect = bounds.rect
        val roiMat = fullMat.submat(
            Range(rect.top.toInt().coerceAtLeast(0), rect.bottom.toInt().coerceAtMost(fullMat.rows())),
            Range(rect.left.toInt().coerceAtLeast(0), rect.right.toInt().coerceAtMost(fullMat.cols()))
        )

        // 4. Detect coins in ROI with baseline context
        val currentCoins = coinDetector.detectCoins(roiMat, rect.left, rect.top, bounds.baselineY)
        roiMat.release()

        // 5. Separate striker from standard coins
        var detectedStriker = currentCoins.firstOrNull { it.type == CoinType.STRIKER }
        if (detectedStriker == null) {
            // If striker is not distinctly recognized, infer position from player's bottom baseline
            val defaultSx = bounds.rect.centerX()
            val defaultSy = bounds.baselineY
            detectedStriker = CarromCoin("striker_inferred", CoinType.STRIKER, defaultSx, defaultSy, 24f)
        }
        strikerPos = Pair(detectedStriker.x, detectedStriker.y)

        // Filter out striker from target coin list
        val targetCoins = currentCoins.filter { it.type != CoinType.STRIKER }

        // 6. Temporal smoothing / tracker update
        trackedCoins = smoothCoinPositions(trackedCoins, targetCoins)

        // 7. Solve physics trajectories
        val shotCandidates = physicsEngine.solveShots(
            strikerPos = strikerPos!!,
            coins = trackedCoins,
            bounds = bounds,
            settings = settings
        )

        val topShot = shotCandidates.firstOrNull()
        val alternativeShots = shotCandidates.drop(1).take(2)

        val latencyMs = System.currentTimeMillis() - startTime
        val instantaneousFps = if (latencyMs > 0) 1000f / latencyMs else 60f

        return TrajectoryResult(
            strikerOriginX = strikerPos!!.first,
            strikerOriginY = strikerPos!!.second,
            topShot = topShot,
            alternativeShots = alternativeShots,
            detectedCoins = trackedCoins,
            boardBounds = bounds,
            fps = instantaneousFps.coerceIn(10f, 120f),
            cvLatencyMs = latencyMs
        )
    }

    /**
     * Temporal smoothing between consecutive frames to prevent jitter.
     */
    private fun smoothCoinPositions(
        previous: List<CarromCoin>,
        current: List<CarromCoin>,
        smoothingFactor: Float = 0.65f
    ): MutableList<CarromCoin> {
        val result = mutableListOf<CarromCoin>()

        for (curr in current) {
            val prevMatch = previous.minByOrNull { hypot(it.x - curr.x, it.y - curr.y) }
            if (prevMatch != null && hypot(prevMatch.x - curr.x, prevMatch.y - curr.y) < 25f) {
                // Smooth coordinates
                val smoothedX = prevMatch.x * (1f - smoothingFactor) + curr.x * smoothingFactor
                val smoothedY = prevMatch.y * (1f - smoothingFactor) + curr.y * smoothingFactor
                result.add(curr.copy(x = smoothedX, y = smoothedY))
            } else {
                result.add(curr)
            }
        }
        return result
    }

    fun release() {
        fullMat.release()
        boardDetector.release()
        coinDetector.release()
    }
}
