package com.carrom.aiassistant.model

import android.graphics.RectF

enum class CoinType {
    WHITE,
    BLACK,
    QUEEN,
    STRIKER
}

data class CarromCoin(
    val id: String,
    val type: CoinType,
    var x: Float, // Pixel coordinate on board
    var y: Float,
    val radius: Float,
    var velocityX: Float = 0f,
    var velocityY: Float = 0f,
    var confidence: Float = 1.0f
)

data class Pocket(
    val id: String,
    val name: String,
    val x: Float,
    val y: Float,
    val radius: Float
)

data class BoardBounds(
    val rect: RectF,
    val pockets: List<Pocket>,
    val baselineY: Float = 0f,
    val scaleFactor: Float = 1.0f
)

data class ShotCandidate(
    val targetCoin: CarromCoin,
    val targetPocket: Pocket,
    val ghostStrikerX: Float,
    val ghostStrikerY: Float,
    val cutAngleDeg: Float,
    val confidence: Int,      // 0 - 100%
    val estimatedPower: Int,  // 0 - 100%
    val aimAngleDeg: Float = 0f,
    val isBankShot: Boolean = false,
    val bankBounceX: Float = 0f,
    val bankBounceY: Float = 0f
)

data class TrajectoryResult(
    val strikerOriginX: Float,
    val strikerOriginY: Float,
    val topShot: ShotCandidate?,
    val alternativeShots: List<ShotCandidate> = emptyList(),
    val detectedCoins: List<CarromCoin> = emptyList(),
    val boardBounds: BoardBounds?,
    val fps: Float = 60f,
    val cvLatencyMs: Long = 16L
)

data class AssistantSettings(
    var enableBankShots: Boolean = true,
    var prioritizeQueen: Boolean = true,
    var minConfidenceThreshold: Int = 35,
    var targetFps: Int = 60,
    var showGhostStriker: Boolean = true,
    var showCollisionNormal: Boolean = true,
    var guideLineThickness: Float = 4f
)
