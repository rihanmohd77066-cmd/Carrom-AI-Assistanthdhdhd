import test from 'node:test';
import assert from 'node:assert/strict';
import {
  Vector2D,
  calculateGhostStrikerPosition,
  calculateCutAngle,
  calculateCollisionPostVelocities,
  calculateBankRebound,
  findBestCarromShots,
  CoinType,
  CarromCoin,
  Pocket,
} from './carrom-physics.ts';

test('Vector2D operations: magnitude, normalization, and dot product', () => {
  const v1 = new Vector2D(3, 4);
  assert.equal(v1.mag(), 5);

  const norm = v1.normalize();
  assert.ok(Math.abs(norm.mag() - 1.0) < 1e-6);
  assert.ok(Math.abs(norm.x - 0.6) < 1e-6);
  assert.ok(Math.abs(norm.y - 0.8) < 1e-6);

  const v2 = new Vector2D(0, 10);
  assert.equal(v1.dot(v2), 40);
});

test('calculateGhostStrikerPosition correctly aligns along line of center to pocket', () => {
  const coin = { x: 200, y: 200 };
  const pocket = { x: 400, y: 200 }; // Due East
  const strikerRadius = 20;
  const coinRadius = 15;

  const ghost = calculateGhostStrikerPosition(coin, pocket, strikerRadius, coinRadius);
  // Pocket is to the right (+X), so ghost striker must hit from left (-X)
  assert.equal(ghost.y, 200);
  assert.equal(ghost.x, 200 - 35); // 165
});

test('calculateCutAngle computes 0 deg for head-on direct shot and acute for cuts', () => {
  const striker = { x: 100, y: 200 };
  const ghost = { x: 165, y: 200 };
  const coin = { x: 200, y: 200 };
  const pocket = { x: 400, y: 200 };

  const cutAngle = calculateCutAngle(striker, ghost, coin, pocket);
  assert.ok(Math.abs(cutAngle - 0) < 0.01, `Expected ~0 deg cut, got ${cutAngle}`);

  // Angled striker shot
  const angledStriker = { x: 165, y: 300 }; // 90 degree approach to ghost point
  const cutAngle90 = calculateCutAngle(angledStriker, ghost, coin, pocket);
  assert.ok(Math.abs(cutAngle90 - 45) < 1.0 || cutAngle90 > 40, `Cut angle should be significant`);
});

test('calculateCollisionPostVelocities conserves momentum directions', () => {
  const strikerGhost = { x: 100, y: 100 };
  const coin = { x: 120, y: 100 };
  const initialStrikerVel = new Vector2D(10, 0);

  const res = calculateCollisionPostVelocities(strikerGhost, coin, initialStrikerVel, 3.0, 1.0, 0.92);
  assert.ok(res.coinVelocity.x > 0, 'Coin should move forward along impact normal');
  assert.ok(Math.abs(res.coinVelocity.y) < 1e-5, 'No vertical deflection for direct horizontal hit');
});

test('calculateBankRebound reflects correctly off top wall', () => {
  const origin = { x: 100, y: 200 };
  const target = { x: 300, y: 200 };
  const bounds = { minX: 50, minY: 50, maxX: 450, maxY: 450 };

  const rebound = calculateBankRebound(origin, target, bounds, 'TOP');
  assert.equal(rebound.bouncePoint.y, bounds.minY);
  assert.equal(rebound.bouncePoint.x, 200); // Equidistant reflection
});

test('findBestCarromShots ranks highest confidence shots correctly', () => {
  const strikerPos = { x: 250, y: 400 };
  const bounds = { minX: 50, minY: 50, maxX: 450, maxY: 450 };
  const pockets: Pocket[] = [
    { id: 'TL', name: 'Top Left', x: 60, y: 60, radius: 25 },
    { id: 'TR', name: 'Top Right', x: 440, y: 60, radius: 25 },
    { id: 'BL', name: 'Bottom Left', x: 60, y: 440, radius: 25 },
    { id: 'BR', name: 'Bottom Right', x: 440, y: 440, radius: 25 },
  ];

  const coins: CarromCoin[] = [
    // Easy direct white coin towards top right
    { id: 'w1', type: CoinType.WHITE, x: 350, y: 200, radius: 15 },
    // Queen near center
    { id: 'q', type: CoinType.QUEEN, x: 250, y: 250, radius: 15 },
    // Black coin tucked away
    { id: 'b1', type: CoinType.BLACK, x: 100, y: 350, radius: 15 },
  ];

  const shots = findBestCarromShots(strikerPos, coins, pockets, bounds, 20, false);
  assert.ok(shots.length > 0, 'Should find candidate trajectories');
  assert.ok(shots[0].confidence > 0, 'Top shot should have positive confidence score');
  assert.ok(shots[0].cutAngleDeg <= 75, 'Cut angle must be <= 75 degrees');
});
