/**
 * Carrom 2D Physics Vector & Collision Math
 * Pure mathematical implementation matching the Android Kotlin physics engine.
 */

export interface Point2D {
  x: number;
  y: number;
}

export class Vector2D {
  constructor(public x: number, public y: number) {}

  add(v: Vector2D | Point2D): Vector2D {
    return new Vector2D(this.x + v.x, this.y + v.y);
  }

  sub(v: Vector2D | Point2D): Vector2D {
    return new Vector2D(this.x - v.x, this.y - v.y);
  }

  mult(n: number): Vector2D {
    return new Vector2D(this.x * n, this.y * n);
  }

  div(n: number): Vector2D {
    if (n === 0) return new Vector2D(0, 0);
    return new Vector2D(this.x / n, this.y / n);
  }

  mag(): number {
    return Math.hypot(this.x, this.y);
  }

  magSq(): number {
    return this.x * this.x + this.y * this.y;
  }

  normalize(): Vector2D {
    const m = this.mag();
    if (m === 0) return new Vector2D(0, 0);
    return this.div(m);
  }

  dot(v: Vector2D): number {
    return this.x * v.x + this.y * v.y;
  }

  dist(v: Vector2D | Point2D): number {
    return Math.hypot(this.x - v.x, this.y - v.y);
  }

  heading(): number {
    return Math.atan2(this.y, this.x);
  }

  static fromAngle(angleRad: number, length: number = 1): Vector2D {
    return new Vector2D(Math.cos(angleRad) * length, Math.sin(angleRad) * length);
  }
}

export enum CoinType {
  WHITE = 'WHITE',
  BLACK = 'BLACK',
  QUEEN = 'QUEEN',
  STRIKER = 'STRIKER'
}

export interface CarromCoin {
  id: string;
  type: CoinType;
  x: number; // 0..1 normalized board space or pixel space
  y: number;
  radius: number;
}

export interface Pocket {
  id: string;
  name: string;
  x: number;
  y: number;
  radius: number;
}

export interface TrajectoryPath {
  strikerOrigin: Point2D;
  strikerImpactPoint: Point2D;
  targetCoin: CarromCoin;
  targetPocket: Pocket;
  strikerReboundVector: Vector2D;
  coinTrajectoryVector: Vector2D;
  cutAngleDeg: number;
  estimatedPower: number; // 0..100%
  confidence: number; // 0..100%
  isBankShot: boolean;
  bankBouncePoint?: Point2D;
}

export const CARROM_CONSTANTS = {
  STRIKER_RADIUS_MM: 20.6,
  COIN_RADIUS_MM: 15.9,
  BOARD_SIZE_MM: 740,
  POCKET_RADIUS_MM: 22.2,
  COEFFICIENT_RESTITUTION_COIN: 0.92,
  COEFFICIENT_RESTITUTION_CUSHION: 0.85,
  FRICTION_COEFFICIENT: 0.12,
  MAX_CUT_ANGLE_DEG: 75.0,
};

/**
 * Calculates ghost striker position to pocket target coin.
 * To send target coin into pocket along line (Coin -> Pocket),
 * striker center at collision must be exactly (strikerRadius + coinRadius)
 * away from coin center in opposite direction of (Coin -> Pocket).
 */
export function calculateGhostStrikerPosition(
  coin: Point2D,
  pocket: Point2D,
  strikerRadius: number,
  coinRadius: number
): Point2D {
  const pocketVec = new Vector2D(pocket.x - coin.x, pocket.y - coin.y);
  const dirToPocket = pocketVec.normalize();
  
  // Ghost position is opposite the pocket vector
  const offsetDistance = strikerRadius + coinRadius;
  return {
    x: coin.x - dirToPocket.x * offsetDistance,
    y: coin.y - dirToPocket.y * offsetDistance,
  };
}

/**
 * Calculates the cut angle between striker line of flight and coin line to pocket.
 * Returns angle in degrees [0..90]. 0 deg is head-on direct shot, 75+ is extreme thin cut.
 */
export function calculateCutAngle(
  strikerPos: Point2D,
  ghostPos: Point2D,
  coinPos: Point2D,
  pocketPos: Point2D
): number {
  const strikerDir = new Vector2D(ghostPos.x - strikerPos.x, ghostPos.y - strikerPos.y).normalize();
  const coinDir = new Vector2D(pocketPos.x - coinPos.x, pocketPos.y - coinPos.y).normalize();

  const dot = Math.max(-1, Math.min(1, strikerDir.dot(coinDir)));
  const angleRad = Math.acos(dot);
  return (angleRad * 180) / Math.PI;
}

/**
 * Computes post-collision velocities for elastic collision between striker and coin.
 */
export function calculateCollisionPostVelocities(
  strikerPos: Point2D,
  coinPos: Point2D,
  strikerInitialVelocity: Vector2D,
  strikerMass: number = 3.0,
  coinMass: number = 1.0,
  restitution: number = CARROM_CONSTANTS.COEFFICIENT_RESTITUTION_COIN
): { strikerVelocity: Vector2D; coinVelocity: Vector2D } {
  const normal = new Vector2D(coinPos.x - strikerPos.x, coinPos.y - strikerPos.y).normalize();
  const tangent = new Vector2D(-normal.y, normal.x);

  const v1n = strikerInitialVelocity.dot(normal);
  const v1t = strikerInitialVelocity.dot(tangent);

  // Coin initially at rest
  const v2n = 0;

  // 1D elastic collision along normal line
  const v1nPrime =
    (v1n * (strikerMass - restitution * coinMass) + (1 + restitution) * coinMass * v2n) /
    (strikerMass + coinMass);
  const v2nPrime =
    (v1n * (1 + restitution) * strikerMass + v2n * (coinMass - restitution * strikerMass)) /
    (strikerMass + coinMass);

  const strikerVel = normal.mult(v1nPrime).add(tangent.mult(v1t));
  const coinVel = normal.mult(v2nPrime);

  return { strikerVelocity: strikerVel, coinVelocity: coinVel };
}

/**
 * Calculates cushion reflection point and post-reflection angle.
 */
export function calculateBankRebound(
  origin: Point2D,
  target: Point2D,
  boardBounds: { minX: number; minY: number; maxX: number; maxY: number },
  wall: 'LEFT' | 'RIGHT' | 'TOP' | 'BOTTOM'
): { bouncePoint: Point2D; reflectionVector: Vector2D } {
  let bounceX = origin.x;
  let bounceY = origin.y;
  let reflectedX = 0;
  let reflectedY = 0;

  switch (wall) {
    case 'TOP': {
      const wallY = boardBounds.minY;
      // Mirror target across top wall
      const mirroredTargetY = 2 * wallY - target.y;
      const t = (wallY - origin.y) / (mirroredTargetY - origin.y);
      bounceX = origin.x + t * (target.x - origin.x);
      bounceY = wallY;
      reflectedX = target.x - bounceX;
      reflectedY = target.y - bounceY;
      break;
    }
    case 'BOTTOM': {
      const wallY = boardBounds.maxY;
      const mirroredTargetY = 2 * wallY - target.y;
      const t = (wallY - origin.y) / (mirroredTargetY - origin.y);
      bounceX = origin.x + t * (target.x - origin.x);
      bounceY = wallY;
      reflectedX = target.x - bounceX;
      reflectedY = target.y - bounceY;
      break;
    }
    case 'LEFT': {
      const wallX = boardBounds.minX;
      const mirroredTargetX = 2 * wallX - target.x;
      const t = (wallX - origin.x) / (mirroredTargetX - origin.x);
      bounceX = wallX;
      bounceY = origin.y + t * (target.y - origin.y);
      reflectedX = target.x - bounceX;
      reflectedY = target.y - bounceY;
      break;
    }
    case 'RIGHT': {
      const wallX = boardBounds.maxX;
      const mirroredTargetX = 2 * wallX - target.x;
      const t = (wallX - origin.x) / (mirroredTargetX - origin.x);
      bounceX = wallX;
      bounceY = origin.y + t * (target.y - origin.y);
      reflectedX = target.x - bounceX;
      reflectedY = target.y - bounceY;
      break;
    }
  }

  return {
    bouncePoint: { x: bounceX, y: bounceY },
    reflectionVector: new Vector2D(reflectedX, reflectedY).normalize(),
  };
}

/**
 * Checks if a segment (A -> B) is obstructed by any obstacle coins.
 */
export function isLineObstructed(
  a: Point2D,
  b: Point2D,
  obstacles: CarromCoin[],
  clearanceRadius: number,
  ignoreCoinId?: string
): boolean {
  const lineVec = new Vector2D(b.x - a.x, b.y - a.y);
  const lineLen = lineVec.mag();
  if (lineLen === 0) return false;
  const lineDir = lineVec.div(lineLen);

  for (const obs of obstacles) {
    if (ignoreCoinId && obs.id === ignoreCoinId) continue;

    const toObs = new Vector2D(obs.x - a.x, obs.y - a.y);
    const projection = toObs.dot(lineDir);

    // Obstacle is behind A or beyond B
    if (projection < 0 || projection > lineLen) continue;

    const projPoint = new Vector2D(a.x + lineDir.x * projection, a.y + lineDir.y * projection);
    const distToLine = projPoint.dist(obs);

    if (distToLine < clearanceRadius + obs.radius) {
      return true; // Collision along path!
    }
  }
  return false;
}

/**
 * Evaluates best shot options across all detected coins and pockets.
 */
export function findBestCarromShots(
  strikerPos: Point2D,
  coins: CarromCoin[],
  pockets: Pocket[],
  boardBounds: { minX: number; minY: number; maxX: number; maxY: number },
  strikerRadius: number = 20,
  maxBankShots: boolean = true
): TrajectoryPath[] {
  const paths: TrajectoryPath[] = [];

  for (const coin of coins) {
    if (coin.type === CoinType.STRIKER) continue;

    for (const pocket of pockets) {
      // 1. Direct shot calculation
      const ghost = calculateGhostStrikerPosition(coin, pocket, strikerRadius, coin.radius);

      // Check if ghost position is inside board boundaries
      if (
        ghost.x < boardBounds.minX + strikerRadius ||
        ghost.x > boardBounds.maxX - strikerRadius ||
        ghost.y < boardBounds.minY + strikerRadius ||
        ghost.y > boardBounds.maxY - strikerRadius
      ) {
        continue;
      }

      const cutAngle = calculateCutAngle(strikerPos, ghost, coin, pocket);

      // Reject cut angles greater than maximum allowable threshold
      if (cutAngle > CARROM_CONSTANTS.MAX_CUT_ANGLE_DEG) {
        continue;
      }

      // Check obstruction: striker path to ghost, coin path to pocket
      const strikerBlocked = isLineObstructed(
        strikerPos,
        ghost,
        coins,
        strikerRadius,
        coin.id
      );
      const coinBlocked = isLineObstructed(
        coin,
        pocket,
        coins,
        coin.radius,
        coin.id
      );

      // Calculate confidence
      // Cut angle penalty: 0 deg = 100%, 75 deg = 10%
      const angleScore = Math.max(0, (75 - cutAngle) / 75) * 60;
      const distStrikerToCoin = Math.hypot(ghost.x - strikerPos.x, ghost.y - strikerPos.y);
      const distCoinToPocket = Math.hypot(pocket.x - coin.x, pocket.y - coin.y);
      const totalDist = distStrikerToCoin + distCoinToPocket;
      const boardDiagonal = Math.hypot(
        boardBounds.maxX - boardBounds.minX,
        boardBounds.maxY - boardBounds.minY
      );
      const distanceScore = Math.max(0, (boardDiagonal - totalDist) / boardDiagonal) * 25;
      
      let penalty = 0;
      if (strikerBlocked) penalty += 50;
      if (coinBlocked) penalty += 40;

      // Bonus for Queen
      const queenBonus = coin.type === CoinType.QUEEN ? 15 : 0;

      const confidence = Math.min(
        100,
        Math.max(5, Math.round(angleScore + distanceScore + queenBonus - penalty))
      );

      // Estimated power: 25% minimum + distance and cut angle factor
      const powerFactor = (totalDist / boardDiagonal) * 55 + (cutAngle / 75) * 20;
      const estimatedPower = Math.min(100, Math.max(30, Math.round(powerFactor)));

      // Striker rebound post-collision
      const impactNormal = new Vector2D(coin.x - ghost.x, coin.y - ghost.y).normalize();
      const initialVel = new Vector2D(ghost.x - strikerPos.x, ghost.y - strikerPos.y).normalize();
      const collisionResult = calculateCollisionPostVelocities(
        ghost,
        coin,
        initialVel.mult(10)
      );

      paths.push({
        strikerOrigin: strikerPos,
        strikerImpactPoint: ghost,
        targetCoin: coin,
        targetPocket: pocket,
        strikerReboundVector: collisionResult.strikerVelocity.normalize(),
        coinTrajectoryVector: new Vector2D(pocket.x - coin.x, pocket.y - coin.y).normalize(),
        cutAngleDeg: Math.round(cutAngle * 10) / 10,
        estimatedPower,
        confidence,
        isBankShot: false,
      });
    }
  }

  // Sort paths by confidence descending
  paths.sort((a, b) => b.confidence - a.confidence);
  return paths;
}
