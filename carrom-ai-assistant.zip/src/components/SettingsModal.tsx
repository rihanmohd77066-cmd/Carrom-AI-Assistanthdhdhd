import React from 'react';
import { X, Sliders, Shield, Zap, Sparkles } from 'lucide-react';

interface SettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
  enableBankShots: boolean;
  setEnableBankShots: (val: boolean) => void;
  prioritizeQueen: boolean;
  setPrioritizeQueen: (val: boolean) => void;
  minConfidence: number;
  setMinConfidence: (val: number) => void;
  targetFps: number;
  setTargetFps: (val: number) => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  isOpen,
  onClose,
  enableBankShots,
  setEnableBankShots,
  prioritizeQueen,
  setPrioritizeQueen,
  minConfidence,
  setMinConfidence,
  targetFps,
  setTargetFps,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/75 backdrop-blur-sm animate-fade-in">
      <div className="bg-[#131B2E] border border-cyan-500/30 rounded-2xl max-w-md w-full p-5 shadow-2xl text-slate-100">
        <div className="flex items-center justify-between pb-3 border-b border-slate-700/60 mb-4">
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-bold text-white">Assistant & Physics Engine Settings</h3>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="space-y-4">
          {/* Bank Shots Toggle */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <div>
              <div className="text-xs font-semibold text-slate-200">Cushion Bank Reflections</div>
              <div className="text-[11px] text-slate-400">Calculate 1-bounce bank shots off wooden rails</div>
            </div>
            <input
              type="checkbox"
              checked={enableBankShots}
              onChange={e => setEnableBankShots(e.target.checked)}
              className="w-4 h-4 accent-cyan-400 cursor-pointer"
            />
          </div>

          {/* Queen Priority Bonus */}
          <div className="flex items-center justify-between p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <div>
              <div className="text-xs font-semibold text-slate-200">Prioritize Red Queen (3-Pt Bonus)</div>
              <div className="text-[11px] text-slate-400">+15 confidence score boost for red queen shots</div>
            </div>
            <input
              type="checkbox"
              checked={prioritizeQueen}
              onChange={e => setPrioritizeQueen(e.target.checked)}
              className="w-4 h-4 accent-rose-500 cursor-pointer"
            />
          </div>

          {/* Minimum Confidence Slider */}
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="flex items-center justify-between text-xs mb-2">
              <span className="font-semibold text-slate-200">Minimum Shot Confidence Filter</span>
              <span className="text-cyan-400 font-mono font-bold">{minConfidence}%</span>
            </div>
            <input
              type="range"
              min="10"
              max="70"
              step="5"
              value={minConfidence}
              onChange={e => setMinConfidence(Number(e.target.value))}
              className="w-full accent-cyan-400 cursor-pointer"
            />
            <div className="flex justify-between text-[10px] text-slate-500 mt-1">
              <span>Show all (10%)</span>
              <span>Strict high-odds only (70%)</span>
            </div>
          </div>

          {/* Target Frame Rate Throttler */}
          <div className="p-3 rounded-xl bg-slate-900/80 border border-slate-800">
            <div className="text-xs font-semibold text-slate-200 mb-2">
              Snapdragon 695 Adaptive CV Rate
            </div>
            <div className="grid grid-cols-3 gap-2">
              {[30, 45, 60].map(fps => (
                <button
                  key={fps}
                  onClick={() => setTargetFps(fps)}
                  className={`py-2 rounded-lg text-xs font-mono font-bold transition-all ${
                    targetFps === fps
                      ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-950/40'
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                  }`}
                >
                  {fps} FPS {fps === 30 ? '(Eco)' : fps === 45 ? '(Bal)' : '(Max)'}
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="mt-5 pt-3 border-t border-slate-700/60 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold text-xs shadow-md transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
