import React from 'react';
import { Wifi, BatteryMedium, SignalHigh } from 'lucide-react';

interface PhoneSimulatorProps {
  children: React.ReactNode;
}

export const PhoneSimulator: React.FC<PhoneSimulatorProps> = ({ children }) => {
  return (
    <div className="relative mx-auto flex items-center justify-center p-2">
      {/* Physical Phone Outer Chassis (OnePlus Nord CE 3 Lite 5G Pastel Lime / Chromatic Gray) */}
      <div className="relative w-full max-w-[420px] h-[840px] bg-[#121620] rounded-[48px] p-3 shadow-[0_25px_70px_rgba(0,0,0,0.85)] border-[4px] border-[#222938] ring-1 ring-cyan-500/20 flex flex-col overflow-hidden">
        
        {/* Left Side Volume Rocker simulation */}
        <div className="absolute -left-[7px] top-[140px] w-[3px] h-[70px] bg-slate-700 rounded-l" />
        {/* Right Side Power Key simulation */}
        <div className="absolute -right-[7px] top-[160px] w-[3px] h-[45px] bg-slate-700 rounded-r" />

        {/* Screen Bezel (Gorilla Glass) */}
        <div className="relative w-full h-full bg-[#0B0F19] rounded-[38px] overflow-hidden flex flex-col border border-slate-800/80">
          
          {/* Top Status Bar with Punch Hole Camera */}
          <div className="h-8 bg-[#0B0F19]/90 backdrop-blur-sm px-6 flex items-center justify-between text-slate-300 text-[11px] font-medium z-50 select-none">
            {/* Left Clock */}
            <span className="font-semibold text-slate-200">09:42</span>

            {/* Front Camera Center Punch Hole */}
            <div className="w-3.5 h-3.5 rounded-full bg-slate-950 border border-slate-800 shadow-inner flex items-center justify-center">
              <div className="w-1.5 h-1.5 rounded-full bg-cyan-950/80" />
            </div>

            {/* Right Status Icons (5G, Wi-Fi, Battery) */}
            <div className="flex items-center gap-1.5 text-slate-300">
              <span className="text-[10px] font-bold text-cyan-400">5G</span>
              <SignalHigh className="w-3.5 h-3.5" />
              <Wifi className="w-3.5 h-3.5" />
              <BatteryMedium className="w-4 h-4 text-emerald-400" />
            </div>
          </div>

          {/* Screen Content Viewport */}
          <div className="flex-1 overflow-hidden relative">
            {children}
          </div>

          {/* Android 15 Gesture Navigation Bar */}
          <div className="h-4 bg-[#0B0F19] flex items-center justify-center select-none pb-1">
            <div className="w-28 h-1 bg-slate-600/70 rounded-full" />
          </div>
        </div>
      </div>
    </div>
  );
};
