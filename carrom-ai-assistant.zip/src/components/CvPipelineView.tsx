import React, { useState } from 'react';
import {
  Sliders,
  Sparkles,
  Camera,
  Layers,
  CircleDot,
  CheckCircle2,
  Cpu,
  RefreshCw
} from 'lucide-react';

export const CvPipelineView: React.FC = () => {
  const [activeStage, setActiveStage] = useState<number>(4);
  const [hsvHMin, setHsvHMin] = useState(165);
  const [hsvHMax, setHsvHMax] = useState(180);
  const [houghAccumulator, setHoughAccumulator] = useState(32);
  const [minRadius, setMinRadius] = useState(12);
  const [maxRadius, setMaxRadius] = useState(26);

  const stages = [
    {
      id: 1,
      title: '1. MediaProjection Capture',
      desc: 'Acquires raw 1080x2400 screen frame buffer from Android VirtualDisplay via ImageReader.',
      icon: Camera,
      tag: 'PixelFormat.RGBA_8888',
      perf: '1.2 ms'
    },
    {
      id: 2,
      title: '2. Board ROI Cropping',
      desc: 'Detects outer wooden frame and crops playing field (600x600 px). Reduces memory and Adreno GPU load by 72%.',
      icon: Layers,
      tag: 'Zero-Copy Submat',
      perf: '2.1 ms'
    },
    {
      id: 3,
      title: '3. Grayscale & Gaussian Filter',
      desc: 'Converts RGBA to Gray, then applies a 9x9 Gaussian blur (sigma = 2.0) to eliminate wood grain texture noise.',
      icon: Sparkles,
      tag: 'Imgproc.GaussianBlur',
      perf: '3.4 ms'
    },
    {
      id: 4,
      title: '4. HSV Color Space Segmentation',
      desc: 'Segments Queen (Dual Hue: 0-15 & 165-180), White pieces (High Value + Low Sat), Black pieces (Value < 75).',
      icon: Sliders,
      tag: 'Core.inRange & mean()',
      perf: '4.6 ms'
    },
    {
      id: 5,
      title: '5. Circular Hough Transform',
      desc: 'Locates coin centers using gradient-based 2D Hough accumulation (dp = 1.2, minRadius = 12px, maxRadius = 26px).',
      icon: CircleDot,
      tag: 'Imgproc.HoughCircles',
      perf: '4.8 ms'
    },
    {
      id: 6,
      title: '6. Temporal Position Tracking',
      desc: 'Applies temporal Euclidean distance filtering across frames to damp jitter and output pristine trajectories.',
      icon: CheckCircle2,
      tag: 'Alpha 0.65 Smoothing',
      perf: '0.6 ms'
    }
  ];

  return (
    <div className="flex flex-col h-full bg-[#0B0F19] text-slate-100 overflow-y-auto select-none p-4 pb-20">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            OpenCV 4.10 Computer Vision Engine
          </h2>
          <p className="text-xs text-slate-400">
            Real-time frame pipeline optimized for Snapdragon 695 Kryo 660
          </p>
        </div>
        <div className="flex items-center gap-1.5 px-2 py-1 bg-cyan-950/40 border border-cyan-500/30 rounded-lg text-cyan-400 text-xs font-mono">
          <Cpu className="w-3.5 h-3.5" />
          16.7 ms Total Pipeline
        </div>
      </div>

      {/* Pipeline Stages Stepper */}
      <div className="grid grid-cols-6 gap-1 mb-4">
        {stages.map(stage => {
          const isActive = stage.id === activeStage;
          return (
            <button
              key={stage.id}
              onClick={() => setActiveStage(stage.id)}
              className={`p-2 rounded-xl text-center border transition-all ${
                isActive
                  ? 'bg-cyan-500/20 border-cyan-500 text-cyan-300 font-bold'
                  : 'bg-slate-900 border-slate-800 text-slate-400 hover:bg-slate-800'
              }`}
            >
              <div className="text-[10px] font-mono">Stage {stage.id}</div>
              <div className="text-[11px] truncate">{stage.tag.split(' ')[0]}</div>
            </button>
          );
        })}
      </div>

      {/* Selected Stage Detail Card */}
      {(() => {
        const cur = stages[activeStage - 1];
        const Icon = cur.icon;
        return (
          <div className="bg-slate-900/90 border border-slate-800 rounded-2xl p-4 mb-4">
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  <Icon className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">{cur.title}</h3>
                  <span className="text-[10px] font-mono text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                    {cur.tag}
                  </span>
                </div>
              </div>
              <div className="text-right">
                <div className="text-xs font-bold text-emerald-400 font-mono">{cur.perf}</div>
                <div className="text-[10px] text-slate-500">Execution time</div>
              </div>
            </div>
            <p className="text-xs text-slate-300 leading-relaxed">{cur.desc}</p>
          </div>
        );
      })()}

      {/* Visual Simulation of the Vision Pipeline */}
      <div className="bg-slate-950 border border-slate-800 rounded-2xl p-4 mb-4">
        <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3 flex items-center justify-between">
          <span>Stage {activeStage} Output Buffer Preview</span>
          <span className="text-[10px] text-slate-500 font-mono">600x600 Mat</span>
        </div>

        {/* Visual Simulated Canvas according to stage */}
        <div className="relative w-full aspect-square max-w-[320px] mx-auto rounded-xl border border-slate-800 overflow-hidden flex items-center justify-center">
          {activeStage === 1 && (
            <div className="w-full h-full bg-[#1e293b] flex flex-col items-center justify-center p-4 text-center">
              <Camera className="w-10 h-10 text-cyan-400 mb-2 animate-pulse" />
              <div className="text-xs font-bold text-white">Full Screen MediaProjection</div>
              <div className="text-[11px] text-slate-400 font-mono">1080 x 2400 @ 120Hz Display</div>
            </div>
          )}

          {activeStage === 2 && (
            <div className="w-full h-full bg-[#EBD5B3] relative flex items-center justify-center border-4 border-[#78350F]">
              <div className="absolute inset-4 border-2 border-dashed border-cyan-500 rounded flex items-center justify-center">
                <span className="text-xs font-bold text-cyan-900 bg-cyan-200/90 px-2 py-1 rounded">
                  CROPPED BOARD ROI (600x600)
                </span>
              </div>
            </div>
          )}

          {activeStage === 3 && (
            <div className="w-full h-full bg-slate-800 grayscale flex items-center justify-center relative">
              <div className="absolute inset-6 rounded-full border-4 border-slate-400 opacity-60" />
              <div className="absolute w-8 h-8 rounded-full bg-slate-200 shadow-md" />
              <div className="absolute top-12 left-16 w-6 h-6 rounded-full bg-slate-300" />
              <div className="absolute top-24 right-16 w-6 h-6 rounded-full bg-slate-900" />
              <div className="text-[11px] font-mono text-slate-200 bg-black/60 px-2 py-1 rounded absolute bottom-2">
                Gaussian 9x9 Filter (De-noised)
              </div>
            </div>
          )}

          {activeStage === 4 && (
            <div className="w-full h-full bg-black relative flex items-center justify-center">
              {/* Queen segmented in high red */}
              <div className="absolute w-8 h-8 rounded-full bg-rose-500 shadow-lg shadow-rose-500/50 flex items-center justify-center text-[9px] font-bold text-white">
                QUEEN
              </div>
              {/* White coin segmented in cyan */}
              <div className="absolute top-12 left-16 w-6 h-6 rounded-full bg-white shadow-lg shadow-white/40 flex items-center justify-center text-[8px] font-bold text-black">
                W1
              </div>
              {/* Black coin segmented in dark purple */}
              <div className="absolute top-24 right-16 w-6 h-6 rounded-full bg-slate-700 border border-slate-500 flex items-center justify-center text-[8px] font-bold text-white">
                B1
              </div>
              <div className="text-[10px] font-mono text-cyan-300 bg-cyan-950/80 px-2 py-1 rounded absolute bottom-2 border border-cyan-800">
                HSV Threshold Segmentation
              </div>
            </div>
          )}

          {activeStage === 5 && (
            <div className="w-full h-full bg-slate-900 relative flex items-center justify-center">
              {/* Hough Circles overlay */}
              <div className="absolute w-9 h-9 rounded-full border-2 border-emerald-400 bg-emerald-500/20 flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
              </div>
              <div className="absolute top-12 left-16 w-7 h-7 rounded-full border-2 border-cyan-400 bg-cyan-500/20 flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-cyan-400" />
              </div>
              <div className="absolute top-24 right-16 w-7 h-7 rounded-full border-2 border-amber-400 bg-amber-500/20 flex items-center justify-center">
                <div className="w-1.5 h-1.5 rounded-full bg-amber-400" />
              </div>
              <div className="text-[10px] font-mono text-emerald-300 bg-emerald-950/80 px-2 py-1 rounded absolute bottom-2 border border-emerald-800">
                HoughCircles Center Detection
              </div>
            </div>
          )}

          {activeStage === 6 && (
            <div className="w-full h-full bg-[#0B0F19] p-4 flex flex-col justify-center text-xs font-mono space-y-1.5">
              <div className="text-emerald-400 font-bold mb-1">Normalized Coordinates (0.00 - 1.00):</div>
              <div className="bg-slate-900 p-1.5 rounded border border-slate-800 text-slate-300">
                QUEEN: X=0.500, Y=0.500 | R=0.035
              </div>
              <div className="bg-slate-900 p-1.5 rounded border border-slate-800 text-slate-300">
                WHITE_1: X=0.332, Y=0.315 | R=0.032
              </div>
              <div className="bg-slate-900 p-1.5 rounded border border-slate-800 text-slate-300">
                BLACK_1: X=0.685, Y=0.420 | R=0.032
              </div>
              <div className="bg-slate-900 p-1.5 rounded border border-slate-800 text-cyan-400 font-semibold">
                STRIKER: X=0.500, Y=0.840 | R=0.045
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Real-time OpenCV Parameter Tuning Controls */}
      <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-4">
        <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-3">
          OpenCV Native Parameters
        </div>

        <div className="space-y-3">
          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">Queen Upper Red Hue Range</span>
              <span className="text-cyan-400 font-mono">{hsvHMin}° - {hsvHMax}°</span>
            </div>
            <input
              type="range"
              min="140"
              max="175"
              value={hsvHMin}
              onChange={e => setHsvHMin(Number(e.target.value))}
              className="w-full accent-cyan-400"
            />
          </div>

          <div>
            <div className="flex justify-between text-xs mb-1">
              <span className="text-slate-400">Hough Center Accumulator Threshold</span>
              <span className="text-cyan-400 font-mono">{houghAccumulator}</span>
            </div>
            <input
              type="range"
              min="20"
              max="50"
              value={houghAccumulator}
              onChange={e => setHoughAccumulator(Number(e.target.value))}
              className="w-full accent-cyan-400"
            />
          </div>
        </div>
      </div>
    </div>
  );
};
