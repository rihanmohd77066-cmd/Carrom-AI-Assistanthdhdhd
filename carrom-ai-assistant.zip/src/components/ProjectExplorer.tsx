import React, { useState } from 'react';
import { ANDROID_PROJECT_FILES, AndroidFile } from '../data/android-project-files';
import {
  FileCode,
  Folder,
  Download,
  Copy,
  Check,
  FileText,
  Layers,
  Code,
  Sparkles,
  ExternalLink
} from 'lucide-react';
import JSZip from 'jszip';

export const ProjectExplorer: React.FC = () => {
  const [selectedFile, setSelectedFile] = useState<AndroidFile>(ANDROID_PROJECT_FILES[3]); // MainActivity.kt default
  const [copied, setCopied] = useState(false);
  const [isExporting, setIsExporting] = useState(false);

  const handleCopy = () => {
    navigator.clipboard.writeText(selectedFile.content);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleExportZip = async () => {
    setIsExporting(true);
    try {
      const zip = new JSZip();

      // Add all project files into zip
      for (const file of ANDROID_PROJECT_FILES) {
        zip.file(file.path, file.content);
      }

      // Add additional gradle wrapper & readme
      zip.file(
        'android/gradle/wrapper/gradle-wrapper.properties',
        `distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\\://services.gradle.org/distributions/gradle-8.9-bin.zip
networkTimeout=10000
validateDistributionUrl=true`
      );

      zip.file(
        'android/README.md',
        `# Carrom AI Assistant (Android 15 Native Project)

## Target Device:
- Model: OnePlus Nord CE 3 Lite 5G
- Chipset: Qualcomm Snapdragon 695 5G
- Architecture: arm64-v8a
- OS: Android 15 (compileSdk 35, targetSdk 35, minSdk 26)

## How to build in Android Studio:
1. Open Android Studio (Ladybug or newer).
2. Click "Open" and select the root 'android' folder.
3. Wait for Gradle Sync to complete.
4. Plug in your OnePlus Nord CE 3 Lite 5G via USB with Developer Mode & USB Debugging enabled.
5. Click 'Run' (Shift + F10).
`
      );

      const content = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(content);
      const link = document.createElement('a');
      link.href = url;
      link.download = 'CarromAIAssistant-AndroidStudio.zip';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      URL.revokeObjectURL(url);
    } catch (err) {
      console.error('ZIP generation failed', err);
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="flex flex-col h-full bg-[#0B0F19] text-slate-100 overflow-hidden select-none">
      {/* Top Bar with Export Action */}
      <div className="flex items-center justify-between p-3.5 border-b border-slate-800 bg-[#101726]">
        <div>
          <h2 className="text-sm font-bold text-white flex items-center gap-2">
            <FileCode className="w-4 h-4 text-cyan-400" />
            Android Studio Project Workspace
          </h2>
          <p className="text-[11px] text-slate-400">
            Native Kotlin • API 35 (Android 15) • Snapdragon 695 • OpenCV 4.10
          </p>
        </div>

        <button
          onClick={handleExportZip}
          disabled={isExporting}
          className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-emerald-400 hover:from-cyan-400 hover:to-emerald-300 text-slate-950 font-bold text-xs flex items-center gap-1.5 shadow-md shadow-cyan-950/40 transition-all disabled:opacity-50"
        >
          <Download className="w-3.5 h-3.5" />
          {isExporting ? 'Packaging...' : 'Export Complete Project (.ZIP)'}
        </button>
      </div>

      {/* Main Split View: File Tree on left, Code Viewer on right */}
      <div className="grid grid-cols-1 md:grid-cols-12 flex-1 overflow-hidden">
        {/* Left File Tree (4 cols) */}
        <div className="md:col-span-4 border-r border-slate-800 bg-[#0E1424] overflow-y-auto p-2.5">
          <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-2 px-1">
            Project Files ({ANDROID_PROJECT_FILES.length})
          </div>

          <div className="space-y-1 font-mono text-xs">
            {ANDROID_PROJECT_FILES.map(file => {
              const isSelected = file.path === selectedFile.path;
              return (
                <button
                  key={file.path}
                  onClick={() => setSelectedFile(file)}
                  className={`w-full text-left px-2.5 py-1.5 rounded-lg flex items-center gap-2 transition-all ${
                    isSelected
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-semibold shadow-sm'
                      : 'text-slate-400 hover:bg-slate-800/80 hover:text-slate-200'
                  }`}
                >
                  <FileText className={`w-3.5 h-3.5 flex-shrink-0 ${
                    file.language === 'kotlin'
                      ? 'text-purple-400'
                      : file.language === 'xml'
                      ? 'text-amber-400'
                      : 'text-cyan-400'
                  }`} />
                  <span className="truncate text-[11px]">{file.name}</span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Right Code & Purpose View (8 cols) */}
        <div className="md:col-span-8 flex flex-col h-full bg-[#080B12] overflow-hidden">
          {/* File Header & Purpose */}
          <div className="p-3 border-b border-slate-800/80 bg-[#0C101A] flex flex-col gap-1.5">
            <div className="flex items-center justify-between">
              <span className="font-mono text-xs font-bold text-cyan-300 truncate">
                {selectedFile.path}
              </span>
              <button
                onClick={handleCopy}
                className="px-2.5 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 text-[11px] font-medium flex items-center gap-1 transition-colors border border-slate-700/60"
              >
                {copied ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copied ? 'Copied' : 'Copy'}
              </button>
            </div>
            <p className="text-[11px] text-slate-300 leading-snug">
              <strong>Purpose:</strong> {selectedFile.description || 'Native Android implementation source file.'}
            </p>
          </div>

          {/* Syntax-Highlighted Code Editor Box */}
          <div className="flex-1 overflow-auto p-3 font-mono text-xs leading-relaxed text-slate-300 bg-[#06080E]">
            <pre className="whitespace-pre font-mono text-[11px] text-slate-300">
              {selectedFile.content.split('\n').map((line, idx) => (
                <div key={idx} className="table-row">
                  <span className="table-cell select-none pr-4 text-right text-slate-600 text-[10px]">
                    {idx + 1}
                  </span>
                  <span className="table-cell">{line}</span>
                </div>
              ))}
            </pre>
          </div>
        </div>
      </div>
    </div>
  );
};
