import React from 'react';
import {
  ArrowLeft,
  Sliders,
  Shield,
  Zap,
  RotateCcw,
  Sparkles,
  CheckCircle,
  BatteryCharging
} from 'lucide-react';

interface SettingsScreenViewProps {
  onBack: () => void;
  enableBankShots: boolean;
  setEnableBankShots: (val: boolean) => void;
  enableGlow: boolean;
  setEnableGlow: (val: boolean) => void;
  showGhostStriker: boolean;
  setShowGhostStriker: (val: boolean) => void;
  guideThickness: number;
  setGuideThickness: (val: number) => void;
  prioritizeQueen: boolean;
  setPrioritizeQueen: (val: boolean) => void;
  minConfidence: number;
  setMinConfidence: (val: number) => void;
  targetCoinFilter: 'ALL' | 'WHITE' | 'BLACK';
  setTargetCoinFilter: (val: 'ALL' | 'WHITE' | 'BLACK') => void;
  targetFps: number;
  setTargetFps: (val: number) => void;
  onResetDefaults: () => void;
}

export const SettingsScreenView: React.FC<SettingsScreenViewProps> = ({
  onBack,
  enableBankShots,
  setEnableBankShots,
  enableGlow,
  setEnableGlow,
  showGhostStriker,
  setShowGhostStriker,
  guideThickness,
  setGuideThickness,
  prioritizeQueen,
  setPrioritizeQueen,
  minConfidence,
  setMinConfidence,
  targetCoinFilter,
  setTargetCoinFilter,
  targetFps,
  setTargetFps,
  onResetDefaults,
}) => {
  return (
    <div className="flex flex-col h-full bg-[#0B0F19] text-slate-100 overflow-y-auto select-none p-4 pb-20">
      {/* Top App Bar */}
      <div className="flex items-center gap-3 mb-4 pb-3 border-b border-slate-800">
        <button
          onClick={onBack}
          className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-200 transition-colors border border-slate-700"
          title="Back to Home"
          aria-label="Back to Home"
        >
          <ArrowLeft className="w-4 h-4" />
        </button>
        <div>
          <h2 className="text-base font-bold text-white">Assistant Settings</h2>
          <p className="text-[11px] text-slate-400">SettingsActivity.kt • Android 15</p>
        </div>
      </div>

      <div className="space-y-4">
        {/* Section 1: Trajectory & Visuals */}
        <div>
          <div className="text-[11px] font-bold text-cyan-400 uppercase tracking-wider mb-2">
            Trajectory &amp; Visuals
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3.5 space-y-3.5">
            {/* Cushion Bank Reflections */}
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-semibold text-slate-200">Cushion Bank Reflections</div>
                <div className="text-[10px] text-slate-400">Calculates indirect rebound trajectories off wooden rails</div>
              </div>
              <input
                type="checkbox"
                checked={enableBankShots}
                onChange={e => setEnableBankShots(e.target.checked)}
                className="w-4 h-4 accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* High Contrast Glow */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <div>
                <div className="text-xs font-semibold text-slate-200">High-Contrast Trajectory Glow</div>
                <div className="text-[10px] text-slate-400">Enhances trajectory lines against busy board surfaces</div>
              </div>
              <input
                type="checkbox"
                checked={enableGlow}
                onChange={e => setEnableGlow(e.target.checked)}
                className="w-4 h-4 accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* Ghost Striker Impact Circle */}
            <div className="flex items-center justify-between pt-2 border-t border-slate-800">
              <div>
                <div className="text-xs font-semibold text-slate-200">Show Ghost Striker Impact Circle</div>
                <div className="text-[10px] text-slate-400">Renders predicted striker center at point of impact</div>
              </div>
              <input
                type="checkbox"
                checked={showGhostStriker}
                onChange={e => setShowGhostStriker(e.target.checked)}
                className="w-4 h-4 accent-cyan-400 cursor-pointer"
              />
            </div>

            {/* Guide Line Thickness */}
            <div className="pt-2 border-t border-slate-800">
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-200">Guide Line Thickness</span>
                <span className="text-cyan-400 font-mono font-bold">{guideThickness.toFixed(1)} dp</span>
              </div>
              <input
                type="range"
                min="2.0"
                max="8.0"
                step="0.5"
                value={guideThickness}
                onChange={e => setGuideThickness(Number(e.target.value))}
                className="w-full accent-cyan-400 cursor-pointer"
              />
            </div>
          </div>
        </div>

        {/* Section 2: Shot Priorities & Filters */}
        <div>
          <div className="text-[11px] font-bold text-emerald-400 uppercase tracking-wider mb-2">
            Shot Priorities &amp; Filters
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3.5 space-y-3.5">
            {/* Queen Priority */}
            <div className="flex items-center justify-between">
              <div>
                <div className="text-xs font-semibold text-slate-200">Prioritize Red Queen (3-Pt Bonus)</div>
                <div className="text-[10px] text-slate-400">+15 confidence score boost to pocket Queen</div>
              </div>
              <input
                type="checkbox"
                checked={prioritizeQueen}
                onChange={e => setPrioritizeQueen(e.target.checked)}
                className="w-4 h-4 accent-rose-500 cursor-pointer"
              />
            </div>

            {/* Minimum Confidence Slider */}
            <div className="pt-2 border-t border-slate-800">
              <div className="flex justify-between text-xs mb-1">
                <span className="font-semibold text-slate-200">Minimum Shot Confidence Filter</span>
                <span className="text-emerald-400 font-mono font-bold">{minConfidence}%</span>
              </div>
              <input
                type="range"
                min="10"
                max="75"
                step="5"
                value={minConfidence}
                onChange={e => setMinConfidence(Number(e.target.value))}
                className="w-full accent-emerald-400 cursor-pointer"
              />
            </div>

            {/* Target Coin Filter */}
            <div className="pt-2 border-t border-slate-800">
              <div className="text-xs font-semibold text-slate-200 mb-1.5">Target Coin Filter</div>
              <div className="grid grid-cols-3 gap-1.5">
                {(['ALL', 'WHITE', 'BLACK'] as const).map(type => (
                  <button
                    key={type}
                    onClick={() => setTargetCoinFilter(type)}
                    className={`py-1.5 rounded-lg text-xs font-medium transition-colors ${
                      targetCoinFilter === type
                        ? 'bg-cyan-500 text-slate-950 font-bold'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                    }`}
                  >
                    {type}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Section 3: Snapdragon 695 Optimization */}
        <div>
          <div className="text-[11px] font-bold text-amber-400 uppercase tracking-wider mb-2">
            Snapdragon 695 Engine Rate
          </div>

          <div className="bg-slate-900/80 border border-slate-800 rounded-2xl p-3.5 space-y-3">
            <div className="grid grid-cols-3 gap-2">
              {[30, 45, 60].map(fps => (
                <button
                  key={fps}
                  onClick={() => setTargetFps(fps)}
                  className={`py-2 rounded-xl text-xs font-mono font-bold transition-all ${
                    targetFps === fps
                      ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-950/40'
                      : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                  }`}
                >
                  {fps} FPS {fps === 30 ? '(Eco)' : fps === 45 ? '(Bal)' : '(Max)'}
                </button>
              ))}
            </div>

            <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 flex items-center gap-2 text-[11px] text-slate-300">
              <BatteryCharging className="w-4 h-4 text-emerald-400 flex-shrink-0" />
              <span>OxygenOS battery saver exemption active (prevents background killer)</span>
            </div>
          </div>
        </div>

        {/* Reset Defaults Button */}
        <button
          onClick={onResetDefaults}
          className="w-full py-2.5 rounded-xl border border-rose-500/40 hover:bg-rose-500/10 text-rose-400 text-xs font-bold transition-colors flex items-center justify-center gap-1.5"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          Reset to Recommended Defaults
        </button>
      </div>
    </div>
  );
};
