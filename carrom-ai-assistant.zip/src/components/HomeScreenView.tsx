import React, { useState, useEffect, useRef } from 'react';
import {
  ShieldCheck,
  Layers,
  Video,
  Bell,
  Play,
  Pause,
  Settings,
  Cpu,
  Gamepad2,
  BatteryCharging,
  Camera,
  Activity,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

interface HomeScreenViewProps {
  hasOverlayPerm: boolean;
  setHasOverlayPerm: (val: boolean) => void;
  hasCapturePerm: boolean;
  setHasCapturePerm: (val: boolean) => void;
  hasNotificationPerm: boolean;
  setHasNotificationPerm: (val: boolean) => void;
  hasBatteryExemption: boolean;
  setHasBatteryExemption: (val: boolean) => void;
  isGameInstalled: boolean;
  setIsGameInstalled: (val: boolean) => void;
  isAssistantRunning: boolean;
  onToggleAssistant: () => void;
  onLaunchGame: () => void;
  onOpenSettings: () => void;
  cvFps: number;
  cvLatency: number;
}

export const HomeScreenView: React.FC<HomeScreenViewProps> = ({
  hasOverlayPerm,
  setHasOverlayPerm,
  hasCapturePerm,
  setHasCapturePerm,
  hasNotificationPerm,
  setHasNotificationPerm,
  hasBatteryExemption,
  setHasBatteryExemption,
  isGameInstalled,
  setIsGameInstalled,
  isAssistantRunning,
  onToggleAssistant,
  onLaunchGame,
  onOpenSettings,
  cvFps,
  cvLatency
}) => {
  const [isCapturePaused, setIsCapturePaused] = useState(false);
  const previewCanvasRef = useRef<HTMLCanvasElement | null>(null);

  // Render a live scaled Carrom board simulation inside the MediaProjection preview
  useEffect(() => {
    const canvas = previewCanvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animId: number;
    let angle = 0;

    const drawPreview = () => {
      const w = canvas.width;
      const h = canvas.height;

      ctx.clearRect(0, 0, w, h);

      // Dark board ply
      ctx.fillStyle = '#18130E';
      ctx.fillRect(0, 0, w, h);

      // Board play area
      const boardSize = Math.min(w * 0.9, h * 0.85);
      const bx = (w - boardSize) / 2;
      const by = (h - boardSize) / 2;

      ctx.fillStyle = '#E6CCA8';
      ctx.fillRect(bx, by, boardSize, boardSize);

      // Cushion border
      ctx.strokeStyle = '#5B2C0E';
      ctx.lineWidth = 3;
      ctx.strokeRect(bx, by, boardSize, boardSize);

      // Center ring
      const cx = bx + boardSize / 2;
      const cy = by + boardSize / 2;
      ctx.beginPath();
      ctx.arc(cx, cy, boardSize * 0.12, 0, Math.PI * 2);
      ctx.strokeStyle = '#9A3412';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      // Pockets
      const pocketRadius = boardSize * 0.06;
      const pocketOffsets = [
        [bx + pocketRadius + 2, by + pocketRadius + 2],
        [bx + boardSize - pocketRadius - 2, by + pocketRadius + 2],
        [bx + pocketRadius + 2, by + boardSize - pocketRadius - 2],
        [bx + boardSize - pocketRadius - 2, by + boardSize - pocketRadius - 2],
      ];

      for (const [px, py] of pocketOffsets) {
        ctx.beginPath();
        ctx.arc(px, py, pocketRadius, 0, Math.PI * 2);
        ctx.fillStyle = '#0F0E0D';
        ctx.fill();
        ctx.strokeStyle = '#D97706';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }

      // If active and not paused, draw sample detected coins and trajectory
      if (isAssistantRunning && !isCapturePaused) {
        // Red Queen in center
        ctx.beginPath();
        ctx.arc(cx, cy, 5.5, 0, Math.PI * 2);
        ctx.fillStyle = '#DC2626';
        ctx.fill();

        // White and Black coins around center
        const coinOffsets = [
          { x: cx + 16, y: cy - 8, type: 'W' },
          { x: cx - 18, y: cy + 10, type: 'W' },
          { x: cx - 12, y: cy - 14, type: 'B' },
          { x: cx + 14, y: cy + 16, type: 'B' },
        ];

        for (const coin of coinOffsets) {
          ctx.beginPath();
          ctx.arc(coin.x, coin.y, 4.5, 0, Math.PI * 2);
          ctx.fillStyle = coin.type === 'W' ? '#FFFFFF' : '#1E293B';
          ctx.fill();
          ctx.strokeStyle = coin.type === 'W' ? '#94A3B8' : '#475569';
          ctx.lineWidth = 1;
          ctx.stroke();
        }

        // Striker along baseline with oscillating position
        const strikerBaseY = by + boardSize - 18;
        const strikerX = cx + Math.sin(angle) * (boardSize * 0.25);

        ctx.beginPath();
        ctx.arc(strikerX, strikerBaseY, 7, 0, Math.PI * 2);
        ctx.fillStyle = '#0891B2';
        ctx.fill();
        ctx.strokeStyle = '#67E8F9';
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Trajectory line to Queen
        ctx.beginPath();
        ctx.moveTo(strikerX, strikerBaseY);
        ctx.lineTo(cx, cy);
        ctx.strokeStyle = '#06B6D4';
        ctx.lineWidth = 1.8;
        ctx.stroke();

        // Queen into top-right pocket
        ctx.beginPath();
        ctx.setLineDash([3, 2]);
        ctx.moveTo(cx, cy);
        ctx.lineTo(pocketOffsets[1][0], pocketOffsets[1][1]);
        ctx.strokeStyle = '#10B981';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.setLineDash([]);
      }

      angle += 0.02;
      animId = requestAnimationFrame(drawPreview);
    };

    drawPreview();
    return () => cancelAnimationFrame(animId);
  }, [isAssistantRunning, isCapturePaused]);

  return (
    <div className="flex flex-col h-full bg-[#0B0F19] text-slate-100 overflow-y-auto select-none p-4 pb-20">
      {/* Header */}
      <div className="flex items-center justify-between mb-3.5 pt-1">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-tr from-cyan-600 to-emerald-500 flex items-center justify-center shadow-lg shadow-cyan-900/30">
            <Gamepad2 className="w-6 h-6 text-slate-950" />
          </div>
          <div>
            <h1 className="text-base font-bold tracking-tight text-white flex items-center gap-2">
              Carrom AI Assistant
              <span className="text-[10px] font-semibold uppercase px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                Phase 3 Active
              </span>
            </h1>
            <p className="text-xs text-slate-400">Offline Vision &amp; Physics Engine</p>
          </div>
        </div>

        <button
          onClick={onOpenSettings}
          className="p-2.5 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 transition-colors border border-slate-700/60 shadow-sm"
          title="Assistant Settings"
          aria-label="Assistant Settings"
        >
          <Settings className="w-4 h-4" />
        </button>
      </div>

      {/* Target Device Spec Card */}
      <div className="bg-gradient-to-br from-[#131B2E] to-[#1E293B] border border-cyan-500/20 rounded-2xl p-3.5 mb-3 shadow-xl">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-[11px] font-bold text-cyan-400 tracking-wider flex items-center gap-1.5 uppercase">
            <Cpu className="w-3.5 h-3.5 text-cyan-400" />
            OnePlus Nord CE 3 Lite 5G
          </span>
          <span className="text-[10px] font-semibold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-full border border-emerald-500/20">
            Snapdragon 695
          </span>
        </div>
        <p className="text-[11px] text-slate-300 mb-2 leading-relaxed">
          Kryo 660 8-core CPU • Adreno 619 GPU • 8GB LPDDR4X • 120Hz display
        </p>

        <div className="grid grid-cols-3 gap-2 pt-2 border-t border-slate-700/50">
          <div className="bg-slate-900/60 p-1.5 rounded-xl text-center border border-slate-800">
            <div className="text-[9px] text-slate-400 uppercase font-medium">CV Latency</div>
            <div className="text-xs font-bold text-emerald-400 font-mono">{cvLatency} ms</div>
          </div>
          <div className="bg-slate-900/60 p-1.5 rounded-xl text-center border border-slate-800">
            <div className="text-[9px] text-slate-400 uppercase font-medium">Adaptive FPS</div>
            <div className="text-xs font-bold text-cyan-400 font-mono">{Math.round(isCapturePaused ? 0 : cvFps)} FPS</div>
          </div>
          <div className="bg-slate-900/60 p-1.5 rounded-xl text-center border border-slate-800">
            <div className="text-[9px] text-slate-400 uppercase font-medium">RAM Alloc</div>
            <div className="text-xs font-bold text-amber-400 font-mono">&lt; 34 MB</div>
          </div>
        </div>
      </div>

      {/* PHASE 3 REQUIREMENT 10: MediaProjection Live Preview Card */}
      <div className="bg-[#111728] border border-cyan-500/30 rounded-2xl p-3 mb-3 shadow-xl">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-2">
            <Camera className="w-4 h-4 text-cyan-400" />
            <span className="text-xs font-bold text-white">MediaProjection Live Preview</span>
          </div>

          <span
            className={`text-[9px] font-mono px-2 py-0.5 rounded font-bold ${
              !isAssistantRunning
                ? 'bg-slate-800 text-slate-400'
                : isCapturePaused
                ? 'bg-amber-500/20 text-amber-300 border border-amber-500/30'
                : 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 animate-pulse'
            }`}
          >
            {!isAssistantRunning ? 'STANDBY' : isCapturePaused ? 'PAUSED' : 'STREAMING'}
          </span>
        </div>

        {/* Live Thumbnail Frame */}
        <div className="relative rounded-xl overflow-hidden bg-slate-950 border border-slate-800/80 mb-2">
          <canvas
            ref={previewCanvasRef}
            width={320}
            height={160}
            className="w-full h-36 object-cover block"
          />

          {!isAssistantRunning && (
            <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex flex-col items-center justify-center text-center p-3">
              <Camera className="w-6 h-6 text-slate-500 mb-1" />
              <div className="text-xs font-semibold text-slate-300">Screen Capture Inactive</div>
              <div className="text-[10px] text-slate-500">Tap Start Assistant below to authorize stream</div>
            </div>
          )}

          {/* Telemetry overlay bar */}
          <div className="absolute bottom-0 inset-x-0 bg-slate-950/85 backdrop-blur-xs px-2.5 py-1 flex items-center justify-between text-[10px] font-mono border-t border-slate-800">
            <span className="text-emerald-400 font-bold">
              {isAssistantRunning && !isCapturePaused ? `${cvFps} FPS • ${cvLatency} ms` : '0.0 FPS • 0 ms'}
            </span>
            <span className="text-cyan-400">1080×2400 RGBA_8888</span>
          </div>
        </div>

        {/* Stream control strip */}
        <div className="flex items-center justify-between gap-2 pt-0.5">
          <div className="text-[10px] text-slate-400 truncate">
            {isAssistantRunning
              ? isCapturePaused
                ? 'Stream paused (Conserving battery)'
                : 'Offline OpenCV Mat pipeline: 8 coins'
              : 'ImageReader RGBA_8888 buffer pool ready'}
          </div>

          <button
            onClick={() => setIsCapturePaused(!isCapturePaused)}
            disabled={!isAssistantRunning}
            className={`px-2.5 py-1 rounded-lg text-[10px] font-bold flex items-center gap-1 transition-colors ${
              !isAssistantRunning
                ? 'bg-slate-800 text-slate-600 cursor-not-allowed'
                : isCapturePaused
                ? 'bg-emerald-500 text-slate-950'
                : 'bg-slate-800 hover:bg-slate-700 text-slate-300'
            }`}
          >
            {isCapturePaused ? <Play className="w-3 h-3 fill-current" /> : <Pause className="w-3 h-3" />}
            {isCapturePaused ? 'Resume' : 'Pause'}
          </button>
        </div>
      </div>

      {/* Permissions Section (Requirement 8 & 14) */}
      <div className="mb-3">
        <div className="flex items-center justify-between mb-2">
          <span className="text-xs font-bold text-slate-300 uppercase tracking-wider">
            Android 15 Permissions Status
          </span>
          <span className="text-[10px] text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
            Local Only
          </span>
        </div>

        <div className="space-y-2">
          {/* 1. Overlay Permission */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className={`p-1.5 rounded-lg ${hasOverlayPerm ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                <Layers className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-200">Floating Overlay Window</div>
                <div className="text-[10px] text-slate-400">Renders trajectory paths above Carrom Pool</div>
              </div>
            </div>
            <button
              onClick={() => setHasOverlayPerm(!hasOverlayPerm)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                hasOverlayPerm
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                  : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold'
              }`}
            >
              {hasOverlayPerm ? 'Granted' : 'Grant'}
            </button>
          </div>

          {/* 2. Screen Capture MediaProjection */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className={`p-1.5 rounded-lg ${hasCapturePerm ? 'bg-emerald-500/10 text-emerald-400' : 'bg-amber-500/10 text-amber-400'}`}>
                <Video className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-200">MediaProjection Capture</div>
                <div className="text-[10px] text-slate-400">Offline screen frame stream for OpenCV</div>
              </div>
            </div>
            <button
              onClick={() => setHasCapturePerm(!hasCapturePerm)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                hasCapturePerm
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                  : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold'
              }`}
            >
              {hasCapturePerm ? 'Authorized' : 'Authorize'}
            </button>
          </div>

          {/* 3. Foreground Notification */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className={`p-1.5 rounded-lg ${hasNotificationPerm ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-700/50 text-slate-400'}`}>
                <Bell className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-200">Notification Permission</div>
                <div className="text-[10px] text-slate-400">Required by Android 15 background service</div>
              </div>
            </div>
            <button
              onClick={() => setHasNotificationPerm(!hasNotificationPerm)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                hasNotificationPerm
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                  : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold'
              }`}
            >
              {hasNotificationPerm ? 'Allowed' : 'Allow'}
            </button>
          </div>

          {/* 4. OxygenOS Battery Whitelist */}
          <div className="bg-slate-900/80 border border-slate-800 rounded-xl p-2.5 flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className={`p-1.5 rounded-lg ${hasBatteryExemption ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-700/50 text-slate-400'}`}>
                <BatteryCharging className="w-4 h-4" />
              </div>
              <div>
                <div className="text-xs font-semibold text-slate-200">OxygenOS Battery Whitelist</div>
                <div className="text-[10px] text-slate-400">Prevents background killer from stopping overlay</div>
              </div>
            </div>
            <button
              onClick={() => setHasBatteryExemption(!hasBatteryExemption)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                hasBatteryExemption
                  ? 'bg-emerald-500/15 text-emerald-400 border border-emerald-500/30'
                  : 'bg-cyan-500 text-slate-950 hover:bg-cyan-400 font-bold'
              }`}
            >
              {hasBatteryExemption ? 'Exempt' : 'Exempt'}
            </button>
          </div>
        </div>
      </div>

      {/* Primary Action Buttons */}
      <div className="space-y-2 mt-auto pt-1">
        {/* Assistant Toggle Button */}
        <button
          onClick={onToggleAssistant}
          className={`w-full py-3.5 px-4 rounded-xl font-bold text-sm flex items-center justify-center gap-2 shadow-lg transition-all ${
            isAssistantRunning
              ? 'bg-rose-600 hover:bg-rose-500 text-white shadow-rose-900/30'
              : 'bg-gradient-to-r from-cyan-500 to-emerald-400 hover:from-cyan-400 hover:to-emerald-300 text-slate-950 shadow-cyan-950/40'
          }`}
        >
          <Play className={`w-4 h-4 ${isAssistantRunning ? 'fill-current' : ''}`} />
          {isAssistantRunning ? 'Stop Assistant Service' : 'Start Assistant (Launch Overlay)'}
        </button>

        {/* Carrom Pool Launcher Button (Requirement 6) */}
        <div className="flex items-center gap-2">
          <button
            onClick={onLaunchGame}
            className="flex-1 py-3 px-3.5 rounded-xl font-semibold text-xs flex items-center justify-center gap-2 bg-slate-800/90 hover:bg-slate-700 text-slate-200 border border-slate-700 transition-colors"
          >
            <Gamepad2 className="w-4 h-4 text-cyan-400" />
            {isGameInstalled ? 'Launch Carrom Pool (Installed)' : 'Get Carrom Pool (Google Play)'}
          </button>

          {/* Toggle Installed Test state */}
          <button
            onClick={() => setIsGameInstalled(!isGameInstalled)}
            title="Toggle installed check simulation"
            className="p-3 rounded-xl bg-slate-800/60 hover:bg-slate-700 text-slate-400 border border-slate-700 text-xs"
          >
            {isGameInstalled ? '✓' : '!'}
          </button>
        </div>
      </div>

      {/* Privacy Guarantee Footer */}
      <div className="mt-3 text-center">
        <div className="inline-flex items-center gap-1.5 text-[10px] text-slate-400 bg-slate-900/50 px-3 py-1 rounded-full border border-slate-800">
          <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
          100% On-Device Processing • Zero Network Transmission
        </div>
      </div>
    </div>
  );
};
