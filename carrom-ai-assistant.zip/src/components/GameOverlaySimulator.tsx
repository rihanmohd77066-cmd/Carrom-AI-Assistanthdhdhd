import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  CarromCoin,
  CoinType,
  Pocket,
  findBestCarromShots,
  TrajectoryPath
} from '../physics/carrom-physics';
import {
  Eye,
  EyeOff,
  Move,
  Play,
  Pause,
  Video,
  X,
  Minimize2,
  Maximize2,
  Target,
  Zap,
  Info
} from 'lucide-react';

interface GameOverlaySimulatorProps {
  onBackToHome: () => void;
  enableBankShots: boolean;
  prioritizeQueen: boolean;
  minConfidence: number;
}

export const GameOverlaySimulator: React.FC<GameOverlaySimulatorProps> = ({
  onBackToHome,
  enableBankShots,
  prioritizeQueen,
  minConfidence
}) => {
  // Canvas dimensions
  const BOARD_SIZE = 480;
  const PADDING = 30; // Cushion border
  const PLAY_SIZE = BOARD_SIZE - PADDING * 2;

  // Board boundary coordinates
  const bounds = {
    minX: PADDING,
    minY: PADDING,
    maxX: BOARD_SIZE - PADDING,
    maxY: BOARD_SIZE - PADDING
  };

  const pockets: Pocket[] = [
    { id: 'TL', name: 'Top-Left', x: PADDING + 12, y: PADDING + 12, radius: 20 },
    { id: 'TR', name: 'Top-Right', x: BOARD_SIZE - PADDING - 12, y: PADDING + 12, radius: 20 },
    { id: 'BL', name: 'Bottom-Left', x: PADDING + 12, y: BOARD_SIZE - PADDING - 12, radius: 20 },
    { id: 'BR', name: 'Bottom-Right', x: BOARD_SIZE - PADDING - 12, y: BOARD_SIZE - PADDING - 12, radius: 20 },
  ];

  // Baseline Y for player striker
  const BASELINE_Y = BOARD_SIZE - PADDING - 60;
  const BASELINE_MIN_X = PADDING + 50;
  const BASELINE_MAX_X = BOARD_SIZE - PADDING - 50;

  // State
  const [strikerX, setStrikerX] = useState<number>(BOARD_SIZE / 2);
  const [coins, setCoins] = useState<CarromCoin[]>([
    { id: 'queen', type: CoinType.QUEEN, x: BOARD_SIZE / 2, y: BOARD_SIZE / 2, radius: 14 },
    { id: 'w1', type: CoinType.WHITE, x: BOARD_SIZE / 2 + 30, y: BOARD_SIZE / 2 - 25, radius: 14 },
    { id: 'w2', type: CoinType.WHITE, x: BOARD_SIZE / 2 - 40, y: BOARD_SIZE / 2 + 10, radius: 14 },
    { id: 'w3', type: CoinType.WHITE, x: 160, y: 160, radius: 14 },
    { id: 'b1', type: CoinType.BLACK, x: BOARD_SIZE / 2 - 25, y: BOARD_SIZE / 2 - 35, radius: 14 },
    { id: 'b2', type: CoinType.BLACK, x: BOARD_SIZE / 2 + 35, y: BOARD_SIZE / 2 + 25, radius: 14 },
    { id: 'b3', type: CoinType.BLACK, x: 330, y: 190, radius: 14 },
  ]);

  // Selected coin for drag
  const [draggedCoinId, setDraggedCoinId] = useState<string | null>(null);
  const [isDraggingStriker, setIsDraggingStriker] = useState(false);

  // Phase 2 & 3 Floating Overlay State:
  // - Small movable floating button
  // - Expandable compact dark control panel
  // - Capture & CV actions: Start/Stop Capture, Start/Stop Analysis, Show/Hide Trajectory, Minimize, Close
  const [isCaptureActive, setIsCaptureActive] = useState(true);
  const [isAnalysisActive, setIsAnalysisActive] = useState(true);
  const [isTrajectoryVisible, setIsTrajectoryVisible] = useState(true);
  const [isPanelExpanded, setIsPanelExpanded] = useState(false);

  // Draggable position of the floating bubble / panel
  const [overlayPos, setOverlayPos] = useState<{ x: number; y: number }>({ x: 20, y: 70 });
  const [isDraggingOverlay, setIsDraggingOverlay] = useState(false);
  const [dragStartPos, setDragStartPos] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [hasMovedDuringDrag, setHasMovedDuringDrag] = useState(false);

  const [targetFilter, setTargetFilter] = useState<'ALL' | 'QUEEN' | 'WHITE' | 'BLACK'>('ALL');
  const [selectedShotIndex, setSelectedShotIndex] = useState(0);

  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  // Calculate trajectories
  const strikerPos = { x: strikerX, y: BASELINE_Y };
  const filteredCoins = coins.filter(c => {
    if (targetFilter === 'ALL') return true;
    return c.type === targetFilter;
  });

  const trajectories = isAnalysisActive && isCaptureActive
    ? findBestCarromShots(
        strikerPos,
        filteredCoins,
        pockets,
        bounds,
        20,
        enableBankShots
      ).filter(t => t.confidence >= minConfidence)
    : [];

  const activeShot: TrajectoryPath | undefined = trajectories[selectedShotIndex] || trajectories[0];

  // Draw board and overlay onto Canvas
  const renderBoard = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    ctx.clearRect(0, 0, BOARD_SIZE, BOARD_SIZE);

    // 1. Board Outer Wooden Frame
    ctx.fillStyle = '#26180E';
    ctx.fillRect(0, 0, BOARD_SIZE, BOARD_SIZE);

    // Outer border bevel
    ctx.strokeStyle = '#4A321E';
    ctx.lineWidth = 4;
    ctx.strokeRect(4, 4, BOARD_SIZE - 8, BOARD_SIZE - 8);

    // 2. Playing Surface (Classic Carrom Beige Ply)
    ctx.fillStyle = '#EBD5B3';
    ctx.fillRect(PADDING, PADDING, PLAY_SIZE, PLAY_SIZE);

    // Cushion Inner Border Line
    ctx.strokeStyle = '#78350F';
    ctx.lineWidth = 2;
    ctx.strokeRect(PADDING, PADDING, PLAY_SIZE, PLAY_SIZE);

    // 3. Pockets (4 corners)
    for (const p of pockets) {
      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fillStyle = '#0F0E0D';
      ctx.fill();
      ctx.strokeStyle = '#D97706';
      ctx.lineWidth = 2.5;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius * 0.7, 0, Math.PI * 2);
      ctx.strokeStyle = '#33291E';
      ctx.lineWidth = 1;
      ctx.stroke();
    }

    // 4. Center Circle & Decorative Pattern
    const cx = BOARD_SIZE / 2;
    const cy = BOARD_SIZE / 2;

    ctx.beginPath();
    ctx.arc(cx, cy, 55, 0, Math.PI * 2);
    ctx.strokeStyle = '#92400E';
    ctx.lineWidth = 1.5;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(cx, cy, 22, 0, Math.PI * 2);
    ctx.fillStyle = '#C2410C';
    ctx.fill();
    ctx.strokeStyle = '#7C2D12';
    ctx.lineWidth = 2;
    ctx.stroke();

    // 5. Baselines
    const drawBaseline = (x1: number, y1: number, x2: number, y2: number) => {
      ctx.beginPath();
      ctx.moveTo(x1, y1);
      ctx.lineTo(x2, y2);
      ctx.strokeStyle = '#92400E';
      ctx.lineWidth = 1.5;
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(x1, y1, 10, 0, Math.PI * 2);
      ctx.arc(x2, y2, 10, 0, Math.PI * 2);
      ctx.fillStyle = '#EF4444';
      ctx.fill();
      ctx.stroke();
    };

    drawBaseline(BASELINE_MIN_X, BASELINE_Y, BASELINE_MAX_X, BASELINE_Y);
    ctx.beginPath();
    ctx.moveTo(BASELINE_MIN_X, BASELINE_Y - 12);
    ctx.lineTo(BASELINE_MAX_X, BASELINE_Y - 12);
    ctx.strokeStyle = '#B45309';
    ctx.lineWidth = 1;
    ctx.stroke();

    drawBaseline(BASELINE_MIN_X, PADDING + 60, BASELINE_MAX_X, PADDING + 60);

    // 6. Draw Carrom Coins
    for (const coin of coins) {
      ctx.save();
      ctx.beginPath();
      ctx.arc(coin.x, coin.y, coin.radius, 0, Math.PI * 2);
      ctx.shadowColor = 'rgba(0,0,0,0.35)';
      ctx.shadowBlur = 4;
      ctx.shadowOffsetY = 2;

      if (coin.type === CoinType.QUEEN) {
        ctx.fillStyle = '#DC2626';
        ctx.fill();
        ctx.strokeStyle = '#FEE2E2';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(coin.x, coin.y, coin.radius * 0.45, 0, Math.PI * 2);
        ctx.strokeStyle = '#FDE047';
        ctx.lineWidth = 2;
        ctx.stroke();
      } else if (coin.type === CoinType.WHITE) {
        ctx.fillStyle = '#F8FAFC';
        ctx.fill();
        ctx.strokeStyle = '#CBD5E1';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(coin.x, coin.y, coin.radius * 0.5, 0, Math.PI * 2);
        ctx.strokeStyle = '#94A3B8';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      } else {
        ctx.fillStyle = '#1E1B18';
        ctx.fill();
        ctx.strokeStyle = '#475569';
        ctx.lineWidth = 2;
        ctx.stroke();

        ctx.beginPath();
        ctx.arc(coin.x, coin.y, coin.radius * 0.5, 0, Math.PI * 2);
        ctx.strokeStyle = '#334155';
        ctx.lineWidth = 1.5;
        ctx.stroke();
      }
      ctx.restore();
    }

    // 7. Draw Striker
    ctx.save();
    ctx.beginPath();
    ctx.arc(strikerX, BASELINE_Y, 20, 0, Math.PI * 2);
    ctx.shadowColor = 'rgba(6, 182, 212, 0.6)';
    ctx.shadowBlur = 10;
    ctx.fillStyle = '#0891B2';
    ctx.fill();
    ctx.strokeStyle = '#E0F2FE';
    ctx.lineWidth = 3;
    ctx.stroke();

    ctx.beginPath();
    ctx.arc(strikerX, BASELINE_Y, 9, 0, Math.PI * 2);
    ctx.fillStyle = '#F0FDFA';
    ctx.fill();
    ctx.restore();

    // 8. RENDER OVERLAY TRAJECTORY (If Analysis is active and Trajectory is shown)
    if (isAnalysisActive && isTrajectoryVisible && activeShot) {
      const confColor =
        activeShot.confidence >= 75
          ? '#10B981'
          : activeShot.confidence >= 50
          ? '#F59E0B'
          : '#EF4444';

      // Striker Line to Ghost Impact Point
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(strikerPos.x, strikerPos.y);
      ctx.lineTo(activeShot.strikerImpactPoint.x, activeShot.strikerImpactPoint.y);
      ctx.strokeStyle = '#06B6D4';
      ctx.lineWidth = 3.5;
      ctx.shadowColor = '#06B6D4';
      ctx.shadowBlur = 8;
      ctx.stroke();
      ctx.restore();

      // Ghost Striker Circle
      ctx.save();
      ctx.beginPath();
      ctx.arc(activeShot.strikerImpactPoint.x, activeShot.strikerImpactPoint.y, 20, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(6, 182, 212, 0.2)';
      ctx.fill();
      ctx.strokeStyle = '#38BDF8';
      ctx.lineWidth = 2;
      ctx.setLineDash([4, 4]);
      ctx.stroke();

      ctx.beginPath();
      ctx.arc(activeShot.strikerImpactPoint.x, activeShot.strikerImpactPoint.y, 3.5, 0, Math.PI * 2);
      ctx.fillStyle = '#FFFFFF';
      ctx.fill();
      ctx.restore();

      // Target Coin Line into Pocket
      ctx.save();
      ctx.beginPath();
      ctx.moveTo(activeShot.targetCoin.x, activeShot.targetCoin.y);
      ctx.lineTo(activeShot.targetPocket.x, activeShot.targetPocket.y);
      ctx.strokeStyle = confColor;
      ctx.lineWidth = 4;
      ctx.setLineDash([8, 5]);
      ctx.shadowColor = confColor;
      ctx.shadowBlur = 10;
      ctx.stroke();
      ctx.restore();

      // Target Pocket Ring
      ctx.save();
      ctx.beginPath();
      ctx.arc(activeShot.targetPocket.x, activeShot.targetPocket.y, activeShot.targetPocket.radius + 3, 0, Math.PI * 2);
      ctx.strokeStyle = confColor;
      ctx.lineWidth = 3.5;
      ctx.stroke();
      ctx.restore();

      // HUD Badge
      ctx.save();
      const badgeX = activeShot.strikerImpactPoint.x;
      const badgeY = activeShot.strikerImpactPoint.y - 32;

      ctx.font = 'bold 11px JetBrains Mono, monospace';
      const text = `${activeShot.confidence}% • ${activeShot.cutAngleDeg}° CUT`;
      const textWidth = ctx.measureText(text).width;

      ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
      ctx.roundRect(badgeX - textWidth / 2 - 8, badgeY - 14, textWidth + 16, 20, 6);
      ctx.fill();
      ctx.strokeStyle = confColor;
      ctx.lineWidth = 1.2;
      ctx.stroke();

      ctx.fillStyle = '#F8FAFC';
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';
      ctx.fillText(text, badgeX, badgeY - 4);
      ctx.restore();
    }
  }, [
    coins,
    strikerX,
    isAnalysisActive,
    isTrajectoryVisible,
    activeShot,
    BASELINE_Y,
    BASELINE_MIN_X,
    BASELINE_MAX_X,
    BOARD_SIZE,
    PADDING,
    PLAY_SIZE,
    pockets
  ]);

  useEffect(() => {
    renderBoard();
  }, [renderBoard]);

  // Pointer interactions on Canvas (draggable striker and coins)
  const handleCanvasMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const distToStriker = Math.hypot(x - strikerX, y - BASELINE_Y);
    if (distToStriker <= 26 || Math.abs(y - BASELINE_Y) < 22) {
      setIsDraggingStriker(true);
      const clampedX = Math.max(BASELINE_MIN_X, Math.min(BASELINE_MAX_X, x));
      setStrikerX(clampedX);
      return;
    }

    for (const coin of coins) {
      if (Math.hypot(x - coin.x, y - coin.y) <= coin.radius + 6) {
        setDraggedCoinId(coin.id);
        return;
      }
    }
  };

  const handleCanvasMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (isDraggingStriker) {
      const clampedX = Math.max(BASELINE_MIN_X, Math.min(BASELINE_MAX_X, x));
      setStrikerX(clampedX);
    } else if (draggedCoinId) {
      const clampedX = Math.max(bounds.minX + 16, Math.min(bounds.maxX - 16, x));
      const clampedY = Math.max(bounds.minY + 16, Math.min(bounds.maxY - 16, y));

      setCoins(prev =>
        prev.map(c => (c.id === draggedCoinId ? { ...c, x: clampedX, y: clampedY } : c))
      );
    }
  };

  const handleCanvasMouseUp = () => {
    setIsDraggingStriker(false);
    setDraggedCoinId(null);
  };

  // Dragging the Floating Overlay (Bubble / Expanded Panel)
  const handleOverlayMouseDown = (e: React.MouseEvent) => {
    setIsDraggingOverlay(true);
    setHasMovedDuringDrag(false);
    setDragStartPos({
      x: e.clientX - overlayPos.x,
      y: e.clientY - overlayPos.y
    });
  };

  const handleContainerMouseMove = (e: React.MouseEvent) => {
    if (isDraggingOverlay) {
      setHasMovedDuringDrag(true);
      setOverlayPos({
        x: Math.max(10, Math.min(BOARD_SIZE - (isPanelExpanded ? 240 : 140), e.clientX - dragStartPos.x)),
        y: Math.max(10, Math.min(BOARD_SIZE - (isPanelExpanded ? 220 : 60), e.clientY - dragStartPos.y))
      });
    }
  };

  const handleContainerMouseUp = () => {
    if (isDraggingOverlay) {
      setIsDraggingOverlay(false);
      // Snap to edge when dragging ends (Requirement 4 & 6)
      if (hasMovedDuringDrag) {
        const midX = BOARD_SIZE / 2;
        const targetX = overlayPos.x < midX ? 15 : (BOARD_SIZE - (isPanelExpanded ? 245 : 145));
        setOverlayPos(prev => ({ ...prev, x: targetX }));
      }
    }
  };

  const handleBubbleClick = () => {
    if (!hasMovedDuringDrag) {
      setIsPanelExpanded(true);
    }
  };

  return (
    <div
      className="flex flex-col h-full bg-[#0B0F19] text-slate-100 overflow-y-auto select-none p-3 pb-16"
      onMouseMove={handleContainerMouseMove}
      onMouseUp={handleContainerMouseUp}
    >
      {/* Top Navigation Bar */}
      <div className="flex items-center justify-between mb-2.5">
        <div className="flex items-center gap-2">
          <button
            onClick={onBackToHome}
            className="text-xs px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 font-medium transition-colors"
          >
            ← Home
          </button>
          <span className="text-xs font-bold text-white flex items-center gap-1.5">
            <span className={`w-2 h-2 rounded-full ${isAnalysisActive ? 'bg-emerald-400 animate-pulse' : 'bg-rose-500'}`} />
            Phase 2: Floating Overlay Active
          </span>
        </div>

        <div className="flex items-center gap-1 text-[11px] text-slate-400 font-mono">
          <span className="px-1.5 py-0.5 rounded bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
            {isAnalysisActive ? '45 FPS' : 'PAUSED'}
          </span>
          <span className="px-1.5 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
            16ms
          </span>
        </div>
      </div>

      {/* Main Interactive Canvas Container */}
      <div className="relative mx-auto bg-slate-950 rounded-2xl p-2 border border-slate-800 shadow-2xl overflow-hidden">
        <canvas
          ref={canvasRef}
          width={BOARD_SIZE}
          height={BOARD_SIZE}
          onMouseDown={handleCanvasMouseDown}
          onMouseMove={handleCanvasMouseMove}
          onMouseUp={handleCanvasMouseUp}
          className="rounded-xl cursor-crosshair block shadow-inner"
          title="Drag coins or slide striker along baseline"
        />

        {/* PHASE 2: MOVABLE FLOATING OVERLAY (TYPE_APPLICATION_OVERLAY) */}
        <div
          style={{
            position: 'absolute',
            left: `${overlayPos.x}px`,
            top: `${overlayPos.y}px`,
            zIndex: 40
          }}
          className="shadow-2xl transition-all"
        >
          {/* A. Small Movable Floating AI Button (Minimized) */}
          {!isPanelExpanded ? (
            <div
              onMouseDown={handleOverlayMouseDown}
              onClick={handleBubbleClick}
              className="bg-[#131B2EF2] backdrop-blur-md border border-cyan-500/40 rounded-2xl p-1.5 flex items-center gap-2 shadow-xl shadow-cyan-950/50 cursor-pointer hover:border-cyan-400 transition-all"
              title="Drag or tap to expand control panel"
            >
              <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-emerald-400 flex items-center justify-center text-slate-950 shadow-md">
                <Move className="w-4 h-4" />
              </div>

              <div className="pr-2 font-mono text-left">
                <div className="text-[10px] font-bold text-white flex items-center gap-1">
                  <span>CARROM AI</span>
                  <span className={`w-1.5 h-1.5 rounded-full ${isAnalysisActive ? 'bg-emerald-400' : 'bg-rose-500'}`} />
                </div>
                <div className="text-[9px] text-cyan-400 font-semibold">
                  {isAnalysisActive ? (activeShot ? `${activeShot.confidence}% CONF` : '45 FPS ACTIVE') : 'PAUSED'}
                </div>
              </div>
            </div>
          ) : (
            /* B. Expanded Compact Dark Control Panel (6 Required Actions) */
            <div className="w-56 bg-[#131B2EF5] backdrop-blur-md border border-slate-700/80 rounded-2xl p-3 shadow-2xl text-slate-100 animate-in fade-in zoom-in-95 duration-150">
              {/* Header with Drag Handle */}
              <div
                onMouseDown={handleOverlayMouseDown}
                className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800 cursor-grab active:cursor-grabbing"
              >
                <div className="flex items-center gap-1.5">
                  <div className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse" />
                  <span className="text-xs font-bold text-white tracking-tight">Assistant Panel</span>
                </div>
                <button
                  onClick={() => setIsPanelExpanded(false)}
                  className="p-1 rounded-md text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
                  title="Minimize Panel"
                >
                  <Minimize2 className="w-3.5 h-3.5" />
                </button>
              </div>

              {/* Status readout */}
              <div className="bg-slate-950/70 p-2 rounded-xl border border-slate-800/80 mb-2 text-[10px] font-mono flex items-center justify-between">
                <span className={isCaptureActive && isAnalysisActive ? 'text-emerald-400 font-bold' : 'text-amber-400 font-bold'}>
                  {isCaptureActive ? '● Capture: 25 FPS' : '○ Capture: Paused'}
                </span>
                <span className="text-cyan-400 font-semibold">
                  {isTrajectoryVisible ? 'LINES ON' : 'LINES OFF'}
                </span>
              </div>

              {/* Action Buttons (Requirement 9) */}
              <div className="space-y-1.5">
                {/* Screen Capture: Start Capture & Stop Capture */}
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => setIsCaptureActive(true)}
                    className={`py-1.5 px-2 rounded-lg text-[10px] font-bold flex items-center justify-center gap-1 transition-all ${
                      isCaptureActive
                        ? 'bg-cyan-500 text-slate-950 shadow-sm'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                    }`}
                  >
                    <Video className="w-3 h-3" />
                    Start Capture
                  </button>
                  <button
                    onClick={() => setIsCaptureActive(false)}
                    className={`py-1.5 px-2 rounded-lg text-[10px] font-bold flex items-center justify-center gap-1 transition-all ${
                      !isCaptureActive
                        ? 'bg-slate-700 text-amber-300 shadow-sm'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                    }`}
                  >
                    <Pause className="w-3 h-3" />
                    Stop Capture
                  </button>
                </div>

                {/* 1. Start Analysis & 2. Stop Analysis */}
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => setIsAnalysisActive(true)}
                    className={`py-1.5 px-2 rounded-lg text-[10px] font-bold flex items-center justify-center gap-1 transition-all ${
                      isAnalysisActive
                        ? 'bg-emerald-500 text-slate-950 shadow-sm'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                    }`}
                  >
                    <Play className="w-3 h-3 fill-current" />
                    Start CV
                  </button>
                  <button
                    onClick={() => setIsAnalysisActive(false)}
                    className={`py-1.5 px-2 rounded-lg text-[10px] font-bold flex items-center justify-center gap-1 transition-all ${
                      !isAnalysisActive
                        ? 'bg-rose-500 text-white shadow-sm'
                        : 'bg-slate-800 text-slate-300 hover:bg-slate-750'
                    }`}
                  >
                    <Pause className="w-3 h-3 fill-current" />
                    Stop CV
                  </button>
                </div>

                {/* 3. Show Trajectory & 4. Hide Trajectory */}
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    onClick={() => setIsTrajectoryVisible(true)}
                    className={`py-1.5 px-2 rounded-lg text-[10px] font-semibold flex items-center justify-center gap-1 transition-all ${
                      isTrajectoryVisible
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                    }`}
                  >
                    <Eye className="w-3 h-3" />
                    Show Lines
                  </button>
                  <button
                    onClick={() => setIsTrajectoryVisible(false)}
                    className={`py-1.5 px-2 rounded-lg text-[10px] font-semibold flex items-center justify-center gap-1 transition-all ${
                      !isTrajectoryVisible
                        ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                        : 'bg-slate-800 text-slate-400 hover:bg-slate-750'
                    }`}
                  >
                    <EyeOff className="w-3 h-3" />
                    Hide Lines
                  </button>
                </div>

                {/* 5. Minimize Panel & 6. Close Assistant */}
                <div className="grid grid-cols-2 gap-1.5 pt-1 border-t border-slate-800/80">
                  <button
                    onClick={() => setIsPanelExpanded(false)}
                    className="py-1.5 px-2 rounded-lg text-[10px] font-medium bg-slate-800 hover:bg-slate-750 text-slate-300 flex items-center justify-center gap-1"
                  >
                    <Minimize2 className="w-3 h-3" />
                    Minimize
                  </button>
                  <button
                    onClick={onBackToHome}
                    className="py-1.5 px-2 rounded-lg text-[10px] font-bold border border-rose-500/50 hover:bg-rose-500/10 text-rose-400 flex items-center justify-center gap-1"
                  >
                    <X className="w-3 h-3" />
                    Close
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Touch Pass-Through Indicator */}
        <div className="absolute bottom-3 left-3 pointer-events-none bg-slate-950/85 backdrop-blur-sm border border-slate-800 rounded-lg px-2 py-0.5 text-[9px] text-slate-400 flex items-center gap-1">
          <Zap className="w-2.5 h-2.5 text-cyan-400" />
          <span>FLAG_NOT_TOUCHABLE active on Canvas</span>
        </div>
      </div>

      {/* Trajectories Carousel */}
      <div className="mt-2.5">
        <div className="flex items-center justify-between mb-1.5">
          <span className="text-xs font-bold text-slate-300 uppercase tracking-wider flex items-center gap-1.5">
            <Target className="w-3.5 h-3.5 text-cyan-400" />
            Detected Shots ({trajectories.length})
          </span>
          <div className="flex items-center gap-1">
            {(['ALL', 'QUEEN', 'WHITE', 'BLACK'] as const).map(type => (
              <button
                key={type}
                onClick={() => {
                  setTargetFilter(type);
                  setSelectedShotIndex(0);
                }}
                className={`text-[10px] px-2 py-0.5 rounded font-medium transition-colors ${
                  targetFilter === type
                    ? 'bg-cyan-500 text-slate-950 font-bold'
                    : 'bg-slate-800 text-slate-400 hover:bg-slate-700'
                }`}
              >
                {type}
              </button>
            ))}
          </div>
        </div>

        {trajectories.length === 0 ? (
          <div className="bg-slate-900/60 border border-slate-800 rounded-xl p-2.5 text-center text-xs text-slate-400">
            {isAnalysisActive ? 'No viable shots found. Try sliding the striker along the baseline.' : 'Analysis paused from control panel.'}
          </div>
        ) : (
          <div className="space-y-1 max-h-32 overflow-y-auto pr-1">
            {trajectories.slice(0, 3).map((shot, idx) => {
              const isSelected = idx === selectedShotIndex;
              return (
                <div
                  key={idx}
                  onClick={() => setSelectedShotIndex(idx)}
                  className={`p-2 rounded-xl border cursor-pointer transition-all flex items-center justify-between ${
                    isSelected
                      ? 'bg-cyan-950/40 border-cyan-500/60 shadow-md'
                      : 'bg-slate-900/60 border-slate-800/80 hover:bg-slate-850'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <div
                      className={`w-3 h-3 rounded-full ${
                        shot.targetCoin.type === CoinType.QUEEN
                          ? 'bg-rose-500'
                          : shot.targetCoin.type === CoinType.WHITE
                          ? 'bg-white'
                          : 'bg-slate-700'
                      }`}
                    />
                    <div>
                      <div className="text-xs font-bold text-white flex items-center gap-1.5">
                        {shot.targetCoin.type} → Pocket {shot.targetPocket.id}
                        {shot.targetCoin.type === CoinType.QUEEN && (
                          <span className="text-[9px] px-1 bg-rose-500/20 text-rose-300 rounded">
                            +15 Queen
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] text-slate-400 font-mono">
                        Cut: {shot.cutAngleDeg}° • Power: {shot.estimatedPower}%
                      </div>
                    </div>
                  </div>

                  <div className="text-right font-mono">
                    <div
                      className={`text-xs font-bold ${
                        shot.confidence >= 75
                          ? 'text-emerald-400'
                          : shot.confidence >= 50
                          ? 'text-amber-400'
                          : 'text-rose-400'
                      }`}
                    >
                      {shot.confidence}%
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
