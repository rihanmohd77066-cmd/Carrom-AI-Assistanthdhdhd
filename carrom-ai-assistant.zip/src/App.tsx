import React, { useState } from 'react';
import { PhoneSimulator } from './components/PhoneSimulator';
import { HomeScreenView } from './components/HomeScreenView';
import { SettingsScreenView } from './components/SettingsScreenView';
import { GameOverlaySimulator } from './components/GameOverlaySimulator';
import { CvPipelineView } from './components/CvPipelineView';
import { SnapdragonProfilerCard } from './components/SnapdragonProfilerCard';
import { ProjectExplorer } from './components/ProjectExplorer';
import {
  Smartphone,
  Scan,
  Cpu,
  FileCode,
  ShieldCheck,
  Zap,
  CheckCircle2,
  ExternalLink
} from 'lucide-react';

export default function App() {
  // Navigation tabs
  const [activeTab, setActiveTab] = useState<'simulator' | 'cv' | 'profiler' | 'project'>('simulator');
  const [simulatorView, setSimulatorView] = useState<'home' | 'settings' | 'game'>('home');

  // Permissions state (Requirement 8)
  const [hasOverlayPerm, setHasOverlayPerm] = useState(true);
  const [hasCapturePerm, setHasCapturePerm] = useState(true);
  const [hasNotificationPerm, setHasNotificationPerm] = useState(true);
  const [hasBatteryExemption, setHasBatteryExemption] = useState(true);
  const [isGameInstalled, setIsGameInstalled] = useState(true);
  const [isAssistantRunning, setIsAssistantRunning] = useState(false);

  // Assistant Settings (Requirement 7)
  const [enableBankShots, setEnableBankShots] = useState(true);
  const [enableGlow, setEnableGlow] = useState(true);
  const [showGhostStriker, setShowGhostStriker] = useState(true);
  const [guideThickness, setGuideThickness] = useState(4.0);
  const [prioritizeQueen, setPrioritizeQueen] = useState(true);
  const [minConfidence, setMinConfidence] = useState(35);
  const [targetCoinFilter, setTargetCoinFilter] = useState<'ALL' | 'WHITE' | 'BLACK'>('ALL');
  const [targetFps, setTargetFps] = useState(45);

  const handleResetDefaults = () => {
    setEnableBankShots(true);
    setEnableGlow(true);
    setShowGhostStriker(true);
    setGuideThickness(4.0);
    setPrioritizeQueen(true);
    setMinConfidence(35);
    setTargetCoinFilter('ALL');
    setTargetFps(45);
  };

  const handleToggleAssistant = () => {
    if (!hasOverlayPerm || !hasCapturePerm) {
      alert('Please grant Floating Overlay and Screen Capture permissions to start the assistant.');
      return;
    }
    const nextState = !isAssistantRunning;
    setIsAssistantRunning(nextState);
    if (nextState) {
      setSimulatorView('game');
    }
  };

  const handleLaunchGame = () => {
    setSimulatorView('game');
  };

  return (
    <div className="min-h-screen bg-[#070A12] text-slate-100 flex flex-col font-sans">
      {/* Top Application Header */}
      <header className="border-b border-slate-800 bg-[#0B0F19]/90 backdrop-blur-md sticky top-0 z-40 px-4 py-2.5">
        <div className="max-w-7xl mx-auto flex flex-col md:flex-row items-center justify-between gap-3">
          {/* Logo & Hardware Title */}
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-tr from-cyan-500 to-emerald-400 flex items-center justify-center shadow-lg shadow-cyan-950/50">
              <span className="text-slate-950 font-black text-base">C</span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-sm font-extrabold text-white tracking-tight">
                  Carrom AI Assistant
                </h1>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-cyan-500/10 text-cyan-400 border border-cyan-500/20">
                  Phase 3 Complete • Screen Capture Engine
                </span>
              </div>
              <p className="text-[11px] text-slate-400 flex items-center gap-1.5">
                <span>OnePlus Nord CE 3 Lite 5G</span>
                <span>•</span>
                <span className="text-emerald-400">Snapdragon 695 (Kryo 660 / Adreno 619)</span>
              </p>
            </div>
          </div>

          {/* Workbench Tabs */}
          <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800 shadow-inner">
            <button
              onClick={() => setActiveTab('simulator')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'simulator'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-950/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              Device Simulator
            </button>

            <button
              onClick={() => setActiveTab('cv')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'cv'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-950/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Scan className="w-3.5 h-3.5" />
              CV Pipeline
            </button>

            <button
              onClick={() => setActiveTab('profiler')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'profiler'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-950/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <Cpu className="w-3.5 h-3.5" />
              Snapdragon 695
            </button>

            <button
              onClick={() => setActiveTab('project')}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition-all ${
                activeTab === 'project'
                  ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-950/40'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              <FileCode className="w-3.5 h-3.5" />
              Android Studio Project
            </button>
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <main className="flex-1 max-w-7xl mx-auto w-full p-4 flex flex-col justify-center">
        {activeTab === 'simulator' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
            {/* Left Phone Simulator (5 cols) */}
            <div className="lg:col-span-5 flex flex-col items-center">
              {/* Simulator Screen Switcher Pill */}
              <div className="flex items-center gap-1 bg-slate-900 border border-slate-800 rounded-full p-1 mb-3 text-[11px] font-bold">
                <button
                  onClick={() => setSimulatorView('home')}
                  className={`px-3 py-1 rounded-full transition-colors ${
                    simulatorView === 'home'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Home Screen
                </button>
                <button
                  onClick={() => setSimulatorView('settings')}
                  className={`px-3 py-1 rounded-full transition-colors ${
                    simulatorView === 'settings'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Assistant Settings
                </button>
                <button
                  onClick={() => setSimulatorView('game')}
                  className={`px-3 py-1 rounded-full transition-colors ${
                    simulatorView === 'game'
                      ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                >
                  Carrom Pool Overlay
                </button>
              </div>

              {/* OnePlus Physical Device Frame */}
              <PhoneSimulator>
                {simulatorView === 'home' && (
                  <HomeScreenView
                    hasOverlayPerm={hasOverlayPerm}
                    setHasOverlayPerm={setHasOverlayPerm}
                    hasCapturePerm={hasCapturePerm}
                    setHasCapturePerm={setHasCapturePerm}
                    hasNotificationPerm={hasNotificationPerm}
                    setHasNotificationPerm={setHasNotificationPerm}
                    hasBatteryExemption={hasBatteryExemption}
                    setHasBatteryExemption={setHasBatteryExemption}
                    isGameInstalled={isGameInstalled}
                    setIsGameInstalled={setIsGameInstalled}
                    isAssistantRunning={isAssistantRunning}
                    onToggleAssistant={handleToggleAssistant}
                    onLaunchGame={handleLaunchGame}
                    onOpenSettings={() => setSimulatorView('settings')}
                    cvFps={targetFps}
                    cvLatency={16}
                  />
                )}

                {simulatorView === 'settings' && (
                  <SettingsScreenView
                    onBack={() => setSimulatorView('home')}
                    enableBankShots={enableBankShots}
                    setEnableBankShots={setEnableBankShots}
                    enableGlow={enableGlow}
                    setEnableGlow={setEnableGlow}
                    showGhostStriker={showGhostStriker}
                    setShowGhostStriker={setShowGhostStriker}
                    guideThickness={guideThickness}
                    setGuideThickness={setGuideThickness}
                    prioritizeQueen={prioritizeQueen}
                    setPrioritizeQueen={setPrioritizeQueen}
                    minConfidence={minConfidence}
                    setMinConfidence={setMinConfidence}
                    targetCoinFilter={targetCoinFilter}
                    setTargetCoinFilter={setTargetCoinFilter}
                    targetFps={targetFps}
                    setTargetFps={setTargetFps}
                    onResetDefaults={handleResetDefaults}
                  />
                )}

                {simulatorView === 'game' && (
                  <GameOverlaySimulator
                    onBackToHome={() => setSimulatorView('home')}
                    enableBankShots={enableBankShots}
                    prioritizeQueen={prioritizeQueen}
                    minConfidence={minConfidence}
                  />
                )}
              </PhoneSimulator>
            </div>

            {/* Right Architecture & Live Telemetry Panel (7 cols) */}
            <div className="lg:col-span-7 space-y-4">
              <div className="bg-[#111728] border border-slate-800 rounded-2xl p-5 shadow-xl">
                <div className="flex items-center justify-between mb-3">
                  <h2 className="text-sm font-bold text-white uppercase tracking-wider flex items-center gap-2">
                    <Zap className="w-4 h-4 text-cyan-400" />
                    Phase 3: Screen Capture Engine &amp; OpenCV Pipeline
                  </h2>
                  <span className="text-[11px] font-mono text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/20">
                    Phase 3 Ready
                  </span>
                </div>

                <p className="text-xs text-slate-300 mb-4 leading-relaxed">
                  Phase 3 implements the full Android MediaProjection capture engine with ImageReader (RGBA_8888), zero-copy/reusable buffer OpenCV Mat conversion, adaptive 15-30 FPS thermal regulation, rotation tracking via DisplayListener, Start/Stop Capture controls, and a live in-app preview.
                </p>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3">
                    <div className="text-[11px] font-bold text-cyan-400 mb-1">
                      1. MediaProjection &amp; ImageReader
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Captures full-res 1080×2400 frames with RGBA_8888 double-buffering. Handles Android 15 callback registration and permission revoking gracefully.
                    </div>
                  </div>

                  <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3">
                    <div className="text-[11px] font-bold text-emerald-400 mb-1">
                      2. Adaptive 15-30 FPS Engine
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Dynamically tunes frame interval (33ms to 66ms) based on Snapdragon 695 Kryo execution latency to prevent thermal throttling and battery drain.
                    </div>
                  </div>

                  <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3">
                    <div className="text-[11px] font-bold text-amber-400 mb-1">
                      3. Live In-App Preview Stream
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Dispatches lightweight downscaled preview frames to MainActivity with real-time FPS, latency, and detected coin counts with zero UI thread lag.
                    </div>
                  </div>

                  <div className="bg-slate-900/90 border border-slate-800 rounded-xl p-3">
                    <div className="text-[11px] font-bold text-purple-400 mb-1">
                      4. Zero-Leak Memory Management
                    </div>
                    <div className="text-[11px] text-slate-400">
                      Guaranteed <code className="text-[10px] text-purple-300 font-mono">image.close()</code> in finally blocks, recycled Bitmaps, Mat buffers, and rotation DisplayListener teardown.
                    </div>
                  </div>
                </div>

                <div className="p-3 bg-cyan-950/30 border border-cyan-800/40 rounded-xl flex items-center justify-between text-xs">
                  <span className="text-slate-300">
                    Inspect all Phase 1, 2, and 3 source files in the project workspace
                  </span>
                  <button
                    onClick={() => setActiveTab('project')}
                    className="px-3 py-1.5 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-bold transition-colors shadow-sm"
                  >
                    View Project Files →
                  </button>
                </div>
              </div>

              {/* Hardware Quick Facts */}
              <div className="bg-[#111728] border border-slate-800 rounded-2xl p-4 shadow-xl">
                <div className="text-xs font-bold text-slate-300 uppercase tracking-wider mb-2 flex items-center gap-1.5">
                  <ShieldCheck className="w-4 h-4 text-emerald-400" />
                  Compliance &amp; Privacy Guarantees
                </div>
                <div className="grid grid-cols-3 gap-2 text-center text-xs">
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="text-emerald-400 font-bold">100% Offline</div>
                    <div className="text-[10px] text-slate-500">No INTERNET permission</div>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="text-cyan-400 font-bold">Zero Storage</div>
                    <div className="text-[10px] text-slate-500">Recycled in RAM</div>
                  </div>
                  <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
                    <div className="text-amber-400 font-bold">Visual Only</div>
                    <div className="text-[10px] text-slate-500">No memory injections</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'cv' && (
          <div className="h-[760px] rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
            <CvPipelineView />
          </div>
        )}

        {activeTab === 'profiler' && (
          <div className="h-[760px] rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
            <SnapdragonProfilerCard />
          </div>
        )}

        {activeTab === 'project' && (
          <div className="h-[760px] rounded-2xl overflow-hidden border border-slate-800 shadow-2xl">
            <ProjectExplorer />
          </div>
        )}
      </main>
    </div>
  );
}
